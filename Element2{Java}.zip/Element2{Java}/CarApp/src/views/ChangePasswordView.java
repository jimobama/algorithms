/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package views;
import includes.*;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionListener;
import javax.swing.*;
/**
 *
 * @author hacker
 */

public class ChangePasswordView extends View {

    
    //constant acction commands
    
    final static public String APPLY_CHANGES="Apply changes";
    final static public String EXIT_APPLICATION="Exit";
    //create the class Controlls
    JLabel lblEmployeeID;
    JLabel lblCurrentPassword;
    JLabel lblNewPassword;
    JLabel lblConfirmNewPassword;
    
    //create textfields
    JTextField txtEmployeeID;
    JPasswordField pwdCurrentPassword;
    JPasswordField pwdNewPassword;
    JPasswordField pwdConfirmPassword;
    
    
    //create buttons
    JButton btnCloseWindow;
    JButton btnApplyChanges;
    
    //creating JPanels
    
    JPanel pnlMain;
    JPanel pnlHeader;
    JPanel pnlContent;
    
    
    
  public  ChangePasswordView()
    {
        super();
        this.initGui();
    }
    
    
    private void initFields()
    {
        //init the Label fields
        this.lblCurrentPassword=new JLabel("Current password:");
        this.lblEmployeeID=new JLabel("Employee ID:");
        this.lblNewPassword=new JLabel("New password:");
        this.lblConfirmNewPassword=new JLabel("Confirm Password:");
        
        //init the textfields 
        
        this.txtEmployeeID=new  JTextField(20);
        this.txtEmployeeID.setFont(this.fntTextField);
        this.txtEmployeeID.setEditable(false);
        
        this.pwdConfirmPassword=new JPasswordField(20);
        this.pwdConfirmPassword.setFont(this.fntTextField);
        
        this.pwdCurrentPassword=new JPasswordField(20);
        this.pwdCurrentPassword.setFont(this.fntTextField);
        
        this.pwdNewPassword=new JPasswordField(20);
         this.pwdNewPassword.setFont(this.fntTextField);
        
         //init the Jpanels
         this.pnlMain=new JPanel(new GridBagLayout());
         this.pnlContent=new JPanel(new GridBagLayout());
         this.pnlHeader=new JPanel(new GridBagLayout());
         
         //initialised buttons
         
         this.btnApplyChanges=new JButton(APPLY_CHANGES);
         this.btnApplyChanges.setFont(this.fntButtonText);
         this.btnCloseWindow=new JButton(EXIT_APPLICATION);
         this.btnCloseWindow.setFont(this.fntButtonText);
         
         
         
        
        
    }
    @Override
    protected final void initGui() {
        //initialised the fields by calling the initFields private method
      initFields();
      initHeaderGui();//this layout the controls of the header
      //lay the main layout
      initContentGui();//place the content
      
      GridBagConstraints gc=new GridBagConstraints();
      
      //place the header
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
      this.pnlMain.add(this.pnlHeader,gc);
      
      //place the content
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=1;     
      this.pnlMain.add(this.pnlContent,gc);      
      /// this add the main panel to the view content
      this.add(this.pnlMain);
    }

    
    private void initHeaderGui()
    {
       GridBagConstraints gc=new GridBagConstraints();
      
      //place the employeeID
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
     this.pnlHeader.add(this.lblEmployeeID,gc);  
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
     this.pnlHeader.add(this.txtEmployeeID,gc); 
     
     
       //place the current password
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=1;
      gc.insets.set(5,5, 0, 5);
     this.pnlHeader.add(this.lblCurrentPassword,gc);  
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=1;
      gc.insets.set(5,5, 0, 5);
      this.pnlHeader.add(this.pwdCurrentPassword,gc);  
          
    }    
    
    private void initContentGui()
    {
         GridBagConstraints gc=new GridBagConstraints();
      
      //place the new password
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
     this.pnlContent.add(this.lblNewPassword,gc);  
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
      this.pnlContent.add(this.pwdNewPassword,gc); 
      
      
      //place the confirm new password
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=1;
      gc.insets.set(5,5, 0, 5);
      this.pnlContent.add(this.lblConfirmNewPassword,gc);  
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=1;
      gc.insets.set(5,5, 0, 5);
      this.pnlContent.add(this.pwdConfirmPassword,gc); 
      
      
      //place the buttons
      
      JPanel pnlButtons=new JPanel();
      pnlButtons.add(this.btnApplyChanges);
      pnlButtons.add(this.btnCloseWindow);
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=2;
      gc.insets.set(5,5, 0, 5);
      this.pnlContent.add(pnlButtons,gc); 
      
     
    }
    @Override
    protected void setModel(Model aDataSources) {
       
    }

    @Override
    public void addActionListener(ActionListener listener) {
       this.btnApplyChanges.addActionListener(listener);
       this.btnCloseWindow.addActionListener(listener);       
    }

    @Override
    public void addListSelectionListener(ListSelectionListener listener) {
       
    }

    public void setEmployeeID(String employeeID) {
        this.txtEmployeeID.setText(employeeID.toUpperCase());        
    }

    public String getEmployeeID() {
        return this.txtEmployeeID.getText();
    }

    public String getPassword() {
         try
        {
         String pw=String.valueOf( this.pwdCurrentPassword.getPassword());
        return pw;
        }
        catch(NullPointerException err)
        {
            
        }
        return "";
    }

    public String getNewPassword() {
        try
        {
         String pw=String.valueOf( this.pwdNewPassword.getPassword());
        return pw;
        }
        catch(NullPointerException err)
        {
            
        }
        return "";
    }

    public String getConfirmPassword() {
        try
        {
         String pw=String.valueOf( this.pwdConfirmPassword.getPassword());
        return pw;
        }
        catch(NullPointerException err)
        {
            
        }
        return "";
    }//end method

    public void setChangePasswordForm(String pwdPassword, String newPassword, String cmPassword) {
        this.pwdConfirmPassword.setText(cmPassword);
        this.pwdCurrentPassword.setText(pwdPassword);
        this.pwdNewPassword.setText(newPassword);
    }
    
    
    
}
