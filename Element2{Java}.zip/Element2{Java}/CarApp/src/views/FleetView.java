/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

/**
 *
 * @author hacker
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import includes.*;

public class FleetView extends View {

	// Declare the view Fields where the user can interact with the application

	private static final long serialVersionUID = 1L;
	// My Action Command Constants
	public final static String BUTTON_ADD = "add";
	public final static String BUTTON_DELETE = "delete";
	public final static String BUTTON_DISPLAY_ALL = "display all";
	public final static String BUTTON_FIND = "find...";
	public final static String BUTTON_UPDATE = "update";

	// Creating the view componet fields

	private JTable tblCars;
	// declaring all the panels objects
	private JPanel pnlMain;
	private JPanel pnlSpreadSheet;
	private JPanel pnlCarInfo;
	private JPanel pnlButtons;
	private JPanel pnlImageUploader;
	// grid layout and its constraiants
	private GridBagLayout gbLayout;
	private GridBagConstraints gbConstraints;
	// creating the view element of the forms inputs
	private JTextField txtReg;
	private JLabel lblReg;
	private JTextField txtModel;
	private JLabel lblModel;
	private JTextField txtMileage;
	private JLabel lblMileage;
	// The button declaration section
	private JButton btnAdd;
	private JButton btnDeleteDetails;
	private JButton btnDisplayCarDetails;
	private JButton btnFindCar;
	private JButton btnUpdate;

	// end sections

	public FleetView() {
		super();
                this.initGui();
	}

	// This function initialised all the view componet
	private void initFields() {

		pnlMain = new JPanel(new GridBagLayout());
		pnlButtons = new JPanel(new GridBagLayout());
		pnlSpreadSheet = new JPanel(new GridBagLayout());
		pnlImageUploader = new JPanel(new GridBagLayout());
		// JTable settings
		tblCars = new JTable();
		this.tblCars.setGridColor(Color.white);
		this.tblCars
				.setPreferredScrollableViewportSize(new Dimension(445, 200));
		this.tblCars.setFillsViewportHeight(true);
		this.tblCars.setShowGrid(false);
		// set the cell values to center
		View.setTableAlignment(this.tblCars);

		// Setting the default text value of the form elemets
		lblReg = new JLabel("Enter Reg:");
		txtReg = new JTextField(15);
		txtReg.setFont(txtReg.getFont().deriveFont(20f));
		txtReg.setToolTipText("Enter car registration number uk format like XXNNXXX");
		lblModel = new JLabel("Model Name:");
		txtModel = new JTextField(15);
		txtModel.setFont(txtModel.getFont().deriveFont(20f));
		txtModel.setToolTipText("Enter car model [allow numbers and alphabet]");
		lblMileage = new JLabel("Mileage:");
		txtMileage = new JTextField(5);
		txtMileage.setFont(txtMileage.getFont().deriveFont(20f));
		txtMileage.setToolTipText("Enter car mileage [integer numbers only]");
		pnlCarInfo = new JPanel();
		gbLayout = new GridBagLayout();
		pnlCarInfo.setLayout(gbLayout);
		gbConstraints = new GridBagConstraints();

		// initiables the objects of the JButtons created previiously
		this.btnDeleteDetails = new JButton(FleetView.BUTTON_DELETE);
		this.btnFindCar = new JButton(FleetView.BUTTON_FIND);
		this.btnDisplayCarDetails = new JButton(FleetView.BUTTON_DISPLAY_ALL);
		this.btnAdd = new JButton(FleetView.BUTTON_ADD);
		this.btnUpdate = new JButton(FleetView.BUTTON_UPDATE);

		// getting the button Image and resized them to the desirable size ****

		// the block of codes will set the imageIcon and make the image
		// alignment float right
		// for button btnAdd
		btnAdd.setHorizontalTextPosition(SwingConstants.LEADING);
		btnAdd.setAlignmentX(SwingConstants.RIGHT);

		// the block of codes will set the imageIcon and make the image
		// alignment float right
		// for button btnDeleteDetails
		this.btnDeleteDetails.setHorizontalTextPosition(SwingConstants.LEADING);
		this.btnDeleteDetails.setAlignmentX(SwingConstants.RIGHT);

		// the block of codes will set the imageIcon and make the image
		// alignment float right
		// for button btnFindCar
		this.btnFindCar.setHorizontalTextPosition(SwingConstants.LEADING);
		this.btnFindCar.setAlignmentX(SwingConstants.RIGHT);

		// the block of codes will set the imageIcon and make the image
		// alignment float right
		// for button btnDisplayCarDetails
		this.btnDisplayCarDetails
				.setHorizontalTextPosition(SwingConstants.LEADING);
		this.btnDisplayCarDetails.setAlignmentX(SwingConstants.RIGHT);

	}

	// this function initialised and layout the buttons of the applications

	private void initButtonPanel() {
		// add the buttons panels
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 0;
		pnlButtons.add(btnAdd, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 1;
		gbConstraints.gridy = 0;
		pnlButtons.add(this.btnUpdate, gbConstraints);

		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 2;
		gbConstraints.gridy = 0;
		pnlButtons.add(this.btnFindCar, gbConstraints);

		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 3;
		gbConstraints.gridy = 0;
		pnlButtons.add(this.btnDeleteDetails, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 4;
		gbConstraints.gridy = 0;
		pnlButtons.add(this.btnDisplayCarDetails, gbConstraints);
	}

	// This method initialised the datapanel gui

	private void initDataPanel() {
		Border blackline = BorderFactory.createEtchedBorder(1);
		Border title = BorderFactory.createTitledBorder(blackline,
				"Car details...");
		pnlCarInfo.setBorder(title);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 0;
		gbConstraints.gridwidth = 1;
		gbConstraints.insets = new Insets(2, 0, 0, 0);
		pnlCarInfo.add(lblReg, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 1;
		gbConstraints.gridy = 0;
		gbConstraints.gridwidth = 2;
		pnlCarInfo.add(txtReg, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 1;
		gbConstraints.gridwidth = 1;
		pnlCarInfo.add(lblModel, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 1;
		gbConstraints.gridy = 1;
		gbConstraints.gridwidth = 2;
		pnlCarInfo.add(txtModel, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 2;
		gbConstraints.gridwidth = 1;
		pnlCarInfo.add(lblMileage, gbConstraints);
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 1;
		gbConstraints.gridy = 2;
		gbConstraints.gridwidth = 1;
		pnlCarInfo.add(txtMileage, gbConstraints);
	}

	@Override
	public final void initGui() {
		this.initFields();
		// Calling the sub gui componet sections to be iniitialised
		initDataPanel();
		initButtonPanel();

		// add the table object to the pnlSpread sheet
		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 0;
		gbConstraints.insets = new Insets(2, 5, 5, 5);
		pnlSpreadSheet.add(new JScrollPane(this.tblCars), gbConstraints);

		// add the data panel

		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 0;
		gbConstraints.gridwidth = 2;
		gbConstraints.insets = new Insets(2, 5, 5, 5);
		pnlMain.add(pnlSpreadSheet, gbConstraints);
		this.add(pnlMain);

		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 1;
		gbConstraints.anchor = GridBagConstraints.NORTHWEST;
		gbConstraints.insets = new Insets(2, 5, 5, 5);
		pnlMain.add(pnlCarInfo, gbConstraints);

		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 1;
		gbConstraints.gridy = 1;
		gbConstraints.insets = new Insets(2, 5, 5, 5);
		pnlMain.add(pnlImageUploader, gbConstraints);

		gbConstraints.fill = GridBagConstraints.HORIZONTAL;
		gbConstraints.gridx = 0;
		gbConstraints.gridy = 2;
		gbConstraints.gridwidth = 2;
		gbConstraints.insets = new Insets(2, 5, 5, 5);
		pnlMain.add(pnlButtons, gbConstraints);

	}

	// this method set the car field form elements
	public void set(String aReg, String aModel, int aMileage) {
		this.txtReg.setText(aReg);
		this.txtModel.setText(aModel);
		this.txtMileage.setText(String.valueOf(aMileage));
	}

    @Override
	public void addActionListener(ActionListener listener) {
		this.btnAdd.addActionListener(listener);
		this.btnDeleteDetails.addActionListener(listener);
		this.btnDisplayCarDetails.addActionListener(listener);
		this.btnFindCar.addActionListener(listener);
		this.btnUpdate.addActionListener(listener);
	}

	// this method set the TableCars model where he reads its data from
	public void setTableModel(AbstractTableModel aModel) {
		this.tblCars.setModel(aModel);
	}

	@Override
	public void setModel(Model aDataSources) {

	}

	public String getRegistratioNumber() {
		// this function get the value at the
		return this.txtReg.getText().toString();
	}

	public String getModelNumber() {

		return this.txtModel.getText();
	}

	// This method add the selection listener to the Tables
	public void addListSelectionListener(ListSelectionListener listener) {
		this.tblCars.getSelectionModel().addListSelectionListener(listener);
	}

	public int getSelectedTableRow() {
		int rowIndex = this.tblCars.getSelectedRow();
		return rowIndex;
	}

	public String getMileage() {
		return this.txtMileage.getText();
	}

}
