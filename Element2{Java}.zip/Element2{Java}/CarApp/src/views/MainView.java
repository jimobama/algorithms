/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package views;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import includes.*;
/**
 *
 * @author hacker
 */
public final class MainView extends JFrame{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Action Command constant
	public final static String BUTTON_AUTHENTICATION = "Log In";
	public final static String BUTTON_EMPLOYEE_SETTINGS = "Employee control panel...";
	public final static String BUTTON_CAR_SETTINGS = "Car control panel...";
	public final static String BUTTON_ALL_CARS = "All cars";
	public final static String BUTTON_AVAILABLE_CARS = "Available cars";
	public final static String BUTTON_NON_AVALIABLE_CARS = "Unavailable cars";
	public final static String BUTTON_MYHIREDCARS = "My hired cars ";
	public final static String BUTTON_RETURN_CAR = "Return";
	public final static String BUTTON_RESERVE = "Reserve";
	public final static String BUTTON_CHANAGE_PASSWORD = "Change password...";
	public final static String BUTTON_CLOSE_APPLICATION = "Close application";
	public final static String BUTTON_FIND_CAR = "Find";
	public final static String BUTTON_LOGOUT="Log Out";

	private JPanel pnlMainPanelContent;

	// create the header panel
	JPanel pnlHeader;
	JPanel pnlContent;
	JPanel pnlCommands;
	JPanel pnlCarDetail;
	JPanel pnlEmployeeData;
	// create label fields

	JLabel lblCurrentStaffName;
	JLabel lblEmployeeID;
	JLabel lblCarModel;
	JLabel lblCarRegistrationNumber;
	JLabel lblCarMileage;
	JLabel lblCurrentDate;
	JLabel lblCarStatus;
	JLabel lblPassword;

	// create textfields
	CustomizeTextField txtCurrentStaffName;
	CustomizeTextField txtEmployeeID;
	CustomizeTextField txtCarModel;
	CustomizeTextField txtCarRegistrationNumber;
	CustomizeTextField txtCarMileage;
	CustomizeTextField txtCurrentDate;
	CustomizeTextField txtCarStatus;
	JPasswordField txtPassword;

	// create the button commands
	JButton btnEmployeeSettings;
	JButton btnCarSettings;
	JButton btnListAllCars;
	JButton btnListAvaliableCarsOnly;
	JButton btnListNonAvaliableCars;
	JButton btnListMyBorrowCars;
	JButton btnReserveCar;
	JButton btnReturnCar;
	JButton btnAuthentication;
	JButton btnChangePassword;
	JButton btnCloseApplication;
	JButton btnFind;

	// end button declarations

	// Create the table
	JTable tblCarInfo;
	// create JScrollPane
	JScrollPane jspCarInfo;

	// creating fonts
	Font fntButtonText;
	Font fntTextField;

	public MainView () {
		super();
		initFields();
		this.initGui();
		this.setContentPane(pnlMainPanelContent);
		this.setTitle("Application 1");
		this.setEnableCommands(false);

	}// end Car hiring system

	private void initFields() {
		// initialised fonts
		this.fntButtonText = new Font("sansserif", Font.PLAIN, 17);
		this.fntTextField = new Font(Font.SERIF, Font.PLAIN, 15);
		// creating panal borders
		Border blackline = BorderFactory.createEtchedBorder(1);
		Border carDetailsBorder = BorderFactory.createTitledBorder(blackline,
				"Car details...");

		// initialisation of the Panels Controls
		this.pnlMainPanelContent = new JPanel(new GridBagLayout());
		// this.mainPanelContent.setBackground(Color.blue);
		this.pnlHeader = new JPanel(new GridBagLayout());
		this.pnlContent = new JPanel(new GridBagLayout());
		this.pnlCommands = new JPanel(new GridBagLayout());		
		this.pnlCarDetail = new JPanel(new GridBagLayout());
		this.pnlCarDetail.setBorder(carDetailsBorder);
		this.pnlEmployeeData = new JPanel(new GridBagLayout());

		// initialised the buttons commands
		this.btnAuthentication = new JButton(BUTTON_AUTHENTICATION);
		this.btnAuthentication.setFont(fntButtonText);
		this.btnCarSettings = new JButton(MainView.BUTTON_CAR_SETTINGS);
		this.btnCarSettings.setFont(fntButtonText);

		this.btnChangePassword = new JButton(
				MainView.BUTTON_CHANAGE_PASSWORD);
		btnChangePassword.setFont(fntButtonText);

		this.btnCloseApplication = new JButton(
				MainView.BUTTON_CLOSE_APPLICATION);
		this.btnCloseApplication.setFont(fntButtonText);
		this.btnEmployeeSettings = new JButton(
				MainView.BUTTON_EMPLOYEE_SETTINGS);
		this.btnEmployeeSettings.setFont(fntButtonText);

		this.btnListAllCars = new JButton(MainView.BUTTON_ALL_CARS);
		this.btnListAllCars.setFont(fntButtonText);

		this.btnListAvaliableCarsOnly = new JButton(
				MainView.BUTTON_AVAILABLE_CARS);
		this.btnListAvaliableCarsOnly.setFont(fntButtonText);

		this.btnListMyBorrowCars = new JButton(MainView.BUTTON_MYHIREDCARS);
		this.btnListMyBorrowCars.setFont(fntButtonText);

		this.btnListNonAvaliableCars = new JButton(
				MainView.BUTTON_NON_AVALIABLE_CARS);
		this.btnListNonAvaliableCars.setFont(fntButtonText);

		this.btnReserveCar = new JButton(MainView.BUTTON_RESERVE);
		this.btnReserveCar.setEnabled(false);
		this.btnReserveCar.setFont(fntButtonText);
		this.btnReturnCar = new JButton(MainView.BUTTON_RETURN_CAR);
		this.btnReturnCar.setFont(fntButtonText);
		this.btnReturnCar.setEnabled(false);
		this.btnFind = new JButton(BUTTON_FIND_CAR);
		this.btnFind.setFont(this.fntButtonText);

		// initialising Table objects
		this.tblCarInfo = new JTable();
		this.tblCarInfo.setPreferredScrollableViewportSize(new Dimension(820,
				200));
		// call the view setTableAligment method to set the alignment of the
		// Cells
		View.setTableAlignment(tblCarInfo);
		// set the value to center

		// initialising the JScrollPane
		this.jspCarInfo = new JScrollPane(this.tblCarInfo);

		// initialised the textfield and labels here
		// labels
		this.lblCarMileage = new JLabel("Mileage :");
		this.lblCarModel = new JLabel("Model :");
		this.lblCarRegistrationNumber = new JLabel("Registration number :");
		this.lblCurrentDate = new JLabel("Current date :");
		this.lblCurrentStaffName = new JLabel("Staff fullname :");
		this.lblEmployeeID = new JLabel("Employee Id:");
		this.lblCarStatus = new JLabel("Hire status:");
		this.lblPassword = new JLabel("Password :");
		// fields
		this.txtCarMileage = new CustomizeTextField(5);
		this.txtCarMileage.setFont(fntTextField);
		this.txtCarModel = new CustomizeTextField(20);
		this.txtCarModel.setFont(fntTextField);
		this.txtCarRegistrationNumber = new CustomizeTextField(20);
		this.txtCarRegistrationNumber.setFont(fntTextField);
		this.txtCarStatus = new CustomizeTextField(20);
		this.txtCarStatus.setFont(fntTextField);
		this.txtCarStatus.setEditable(false);
		this.txtCurrentDate = new CustomizeTextField(20);
		this.txtCurrentDate.setFont(fntTextField);
		this.txtCurrentStaffName = new CustomizeTextField(20);
		this.txtCurrentStaffName.setFont(fntTextField);
		this.txtCurrentStaffName.setEditable(false);
		this.txtEmployeeID = new CustomizeTextField(20);
		txtEmployeeID.setFont(fntTextField);

		this.txtPassword = new JPasswordField(20);
		this.txtPassword.setFont(fntTextField);

	}

	protected void initGui() {
		initFields();
		// place the controls
		initCommandsPanelView();
		initContentGui();
		// create a grid bag constraints
		GridBagConstraints gc = new GridBagConstraints();

		// position the commands panel
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 2;
		gc.insets.set(10, 4, 2, 5);
		this.pnlMainPanelContent.add(this.pnlCommands, gc);

		// place the display content
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 1;
		gc.gridheight = 1;
		this.pnlMainPanelContent.add(this.pnlContent, gc);

	}

	private void initContentGui() {
		initHeaderGui();
		initCarDetailGui();
		initEmployeeDetailGui();
		// create a grid bag constraints
		GridBagConstraints gc = new GridBagConstraints();
		// position the commands panel
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 2;
		this.pnlContent.add(this.pnlHeader, gc);

		// position the commands panel
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.PAGE_START;
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridwidth = 1;
		this.pnlContent.add(this.pnlCarDetail, gc);

		// position the commands panel
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.PAGE_START;
		gc.gridx = 1;
		gc.gridy = 1;
		gc.gridwidth = 1;
		this.pnlContent.add(this.pnlEmployeeData, gc);

	}

	private void initCommandsPanelView() {
		// create a grid bag constraints
		GridBagConstraints gc = new GridBagConstraints();

		// position the commands panel
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets.set(0, 0, 8, 0);
		this.pnlCommands.add(this.btnEmployeeSettings, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 1;
		this.pnlCommands.add(this.btnCarSettings, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 2;
		this.pnlCommands.add(this.btnListAllCars, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 3;
		this.pnlCommands.add(this.btnListAvaliableCarsOnly, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 4;
		this.pnlCommands.add(this.btnListNonAvaliableCars, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 5;
		this.pnlCommands.add(this.btnListMyBorrowCars, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 6;
		this.pnlCommands.add(this.btnChangePassword, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 7;
		this.pnlCommands.add(this.btnCloseApplication, gc);

	}

	private void initEmployeeDetailGui() {
		GridBagConstraints gc = new GridBagConstraints();
		// position the commands panel

		// add car registration number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 0;

		gc.insets.set(5, 3, 3, 2);
		this.pnlEmployeeData.add(this.lblEmployeeID, gc);

		// add car registration number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridwidth = 2;
		gc.insets.set(5, 3, 3, 2);
		this.pnlEmployeeData.add(this.txtEmployeeID, gc);

		// add car registration number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 1;
		gc.insets.set(5, 3, 3, 2);
		this.pnlEmployeeData.add(this.lblPassword, gc);

		// add txtPassword field
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 1;
		gc.gridwidth = 2;
		gc.insets.set(5, 3, 3, 2);
		this.pnlEmployeeData.add(this.txtPassword, gc);

		// add  authentication button
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 2;
		gc.gridwidth = 1;
		gc.insets.set(5, 3, 3, 2);
		this.pnlEmployeeData.add(this.btnAuthentication, gc);
		
		// add  employee name fields
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.gridx = 0;
				gc.gridy = 3;
				gc.gridwidth = 1;
				gc.insets.set(5, 3, 3, 2);
				this.pnlEmployeeData.add(this.lblCurrentStaffName, gc);
		
				// add  employee name fields
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridwidth = 2;
				gc.insets.set(5, 3, 3, 2);
				this.pnlEmployeeData.add(this.txtCurrentStaffName, gc);
	}

	private void initCarDetailGui() {

		GridBagConstraints gc = new GridBagConstraints();
		// position the commands panel

		// add car registration number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets.set(5, 3, 3, 2);
		this.pnlCarDetail.add(this.lblCarRegistrationNumber, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridwidth = 2;
		this.pnlCarDetail.add(this.txtCarRegistrationNumber, gc);

		// add car model number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 1;
		this.pnlCarDetail.add(this.lblCarModel, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 1;
		gc.gridwidth = 2;
		this.pnlCarDetail.add(this.txtCarModel, gc);

		// add car mileage number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 2;
		this.pnlCarDetail.add(this.lblCarMileage, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 2;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		this.pnlCarDetail.add(this.txtCarMileage, gc);

		// add car mileage number fields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 3;
		this.pnlCarDetail.add(this.lblCarStatus, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 3;
		gc.gridwidth = 2;
		this.pnlCarDetail.add(this.txtCarStatus, gc);

		// create operational buttons
		JPanel pnlButtons = new JPanel();
		pnlButtons.add(this.btnReserveCar);
		pnlButtons.add(this.btnFind);
		pnlButtons.add(this.btnReturnCar);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 4;

		this.pnlCarDetail.add(pnlButtons, gc);

	}

	private void initHeaderGui() {
		GridBagConstraints gc = new GridBagConstraints();
		// position the commands panel
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 2;
		this.pnlContent.add(this.jspCarInfo, gc);
	}

	public void center() {
		int width, height;
		// get the screen size
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		width = dim.width;
		height = dim.height;

		// calculate the new location of the window
		int w = this.getSize().width;
		int h = this.getSize().height;
		int x = (width - w) / 2;
		int y = (height - h) / 2;
		// moves this component to a new location, the top-left corner of
		// the new location is specified by the x and y
		// parameters in the coordinate space of this component's parent
		this.setLocation(x, y);
	}

	public void setTableModel(AbstractTableModel model) {
		this.tblCarInfo.setModel(model);
	}

	public void addActionListener(ActionListener listener) {
		this.btnEmployeeSettings.addActionListener(listener);
		this.btnCarSettings.addActionListener(listener);
		this.btnListAvaliableCarsOnly.addActionListener(listener);
		this.btnListNonAvaliableCars.addActionListener(listener);
		this.btnListAllCars.addActionListener(listener);
		this.btnAuthentication.addActionListener(listener);
		this.btnCloseApplication.addActionListener(listener);
		this.btnListMyBorrowCars.addActionListener(listener);
		this.btnChangePassword.addActionListener(listener);

		this.btnReserveCar.addActionListener(listener);
		this.btnReturnCar.addActionListener(listener);
		this.btnFind.addActionListener(listener);
	}

	public void addListSelectionListener(ListSelectionListener listener) {
		this.tblCarInfo.getSelectionModel().addListSelectionListener(listener);
	}

	public void reportError(String message, String title) {

		JOptionPane.showMessageDialog(this, message, title,
				JOptionPane.ERROR_MESSAGE | JOptionPane.OK_OPTION);

	}// end the method reportError

	public int getSelectedIndex() {

		return this.tblCarInfo.getSelectedRow();
	}

	public void setCarDetail(String registrationNumber, String model,
			int mileage, boolean status) {
		this.txtCarRegistrationNumber.setText(registrationNumber);
		this.txtCarModel.setText(model);
		this.txtCarMileage.setText(String.valueOf(mileage));
		this.txtCarStatus.setText((status == false) ? "available"
				: "not available");
		if (status == false) {
			this.btnReserveCar.setEnabled(true);
			this.btnReturnCar.setEnabled(false);
		} else {
			this.btnReserveCar.setEnabled(false);
			this.btnReturnCar.setEnabled(true);
		}

	}

	public String getEmployeeID() {
		
		return this.txtEmployeeID.getText();
	}


	public String getPassword() {
		String pw="";
		try
		{
		pw= String.valueOf(this.txtPassword.getPassword());
		}
		catch(NullPointerException err)
		{
			err.printStackTrace();
		}
		
		return pw;
	}


	
	public void  setEnableCommands(boolean aBool)
	{
		this.btnCarSettings.setEnabled(aBool);
		this.btnChangePassword.setEnabled(aBool);
		this.btnEmployeeSettings.setEnabled(aBool);
		this.btnListAllCars.setEnabled(aBool);
		this.btnListAvaliableCarsOnly.setEnabled(aBool);
		this.btnListNonAvaliableCars.setEnabled(aBool);
		this.btnListMyBorrowCars.setEnabled(aBool);
		this.btnReserveCar.setEnabled(aBool);
		this.btnReturnCar.setEnabled(aBool);
	}

	public void setEmployeeFullName(String strName) {
	
		this.txtCurrentStaffName.setText(strName);
		
	}

	public void setLoginStatus(boolean b) {
	   if(b)
	   {
		   this.btnAuthentication.setText(BUTTON_LOGOUT);
		   this.txtEmployeeID.setEditable(false);
		   this.txtPassword.setText("");
		   this.txtPassword.setEditable(false);
	   }else
	   {
		   this.btnAuthentication.setText(MainView.BUTTON_AUTHENTICATION);
		   this.txtEmployeeID.setEditable(true);
		   this.txtPassword.setText("");
		   this.txtPassword.setEditable(true);
		   this.txtCurrentStaffName.setText("");		   
		   this.setCarDetail("", "", 0, false);
		   this.btnReserveCar.setEnabled(false);
		   this.btnReturnCar.setEnabled(false);
	   }
		
	}
//Disable or enable the administrator panels
	public void setAdministratorState(boolean b) {
	 this.btnCarSettings.setEnabled(b);
	 this.btnEmployeeSettings.setEnabled(b);		
	}
	public void reportSuccess(String message, String title) {

		JOptionPane.showMessageDialog(this, message, title,
				JOptionPane.INFORMATION_MESSAGE | JOptionPane.OK_OPTION);

	}
	public String getCarRegistrationNumber() {
		
		return this.txtCarRegistrationNumber.getText();
	}

	public String getCarModel() {
		
		return this.txtCarModel.getText();
	}

	public String getCarMileage() {
	
		return this.txtCarMileage.getText();
	}
        
        
        public JPanel getContentPane()
        {
            return this.pnlContent;
        }
}//end class brace

