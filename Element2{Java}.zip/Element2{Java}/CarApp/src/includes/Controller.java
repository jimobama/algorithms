/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;

/**
 *
 * @author hacker
 */
import java.awt.Container;

//This is an abstract class that all controller must inherit from
//The controller must have a view and a model
public abstract class Controller {
  
   
    // default constructor without parameters
    public Controller() {
      
    }   
    // Setter and getter methods of the controller class
    
    // The abstract class that all controller must have to update their view
    public abstract void update();
    public abstract void lunch();
    public abstract void setParent(Container parent);
    public abstract Model getModel();   
     public abstract View getView();
  
    
}
