/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

/**
 *
 * @author hacker
 */
//Import the class library to use here
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import includes.*;
import views.*;
import models.*;

public class FleetController extends Controller {
	private Fleet model;
	private FleetView view;
	

	public FleetController() {
		super();// initialised the super class
		this.model = new Fleet ();
		this.view = new FleetView();		
		// set the table model for the view
		this.view.setTableModel(this.model.getTableModel());
		// set the event handler
		EventHandler eventHandler = new EventHandler(this);
		this.view.addActionListener(eventHandler);
		this.view.addListSelectionListener(eventHandler);
		// end set event handler
                
                this.model.loadCars();
	}
    @Override
 public void setParent(Container aParent)
 {
	
 }
    
	// add car
	private void xhsAdd() {
		String registrationNumber = this.view.getRegistratioNumber();
		String modelNumber = this.view.getModelNumber();
		String mileage = this.view.getMileage();

		try {
			// check if the registration number exist
			if (this.model.isCarExists(registrationNumber)) {
				this.view.reportError("Ooops this car registration number ["
						+ registrationNumber + "] already exists",
						"Error Message");
				return;// stop execution of other codes
			}
			// else continue
			Car newCar = new Car();
			int aMileage = Integer.parseInt(mileage);
			newCar.set(registrationNumber, modelNumber, aMileage, false);
			this.model.add(newCar);
			this.view.reportSuccess("Car details has be successfully added",
					"News");
			this.view.set("", "", 0);
		} catch (AppException e) {
			this.view.reportError(e.getMessage(), "Adding error");
		} catch (NumberFormatException err) {
			this.view.reportError(
					"Mileage field must be an integer value only",
					"Adding error");
		}

	}// end method to add car

	private void xhsUpdate() {

		String registrationNumber = this.view.getRegistratioNumber();
		String modelNumber = this.view.getModelNumber();
		String mileage = ("".equals(this.view.getMileage().trim())) ? "0"
				: this.view.getMileage();
		int selectedRow = this.view.getSelectedTableRow();
		// if there is a selection then update else dont
		if (selectedRow >= 0) {
			try {
				// create a car object
				Car car = new Car();
				// set their values
				car.set(registrationNumber, modelNumber,
						Integer.parseInt(mileage));
				this.model.updateCar(car);
				this.view.reportSuccess("Car detail successfully updated", "News");
				this.view.set("", "", 0);
			} catch (AppException err) {
				this.view.reportError(err.getMessage(), "Update error:");
			} catch (NumberFormatException err) {
				this.view.reportError(
						"Mileage field must be an integer value only",
						"updating error");
			}
		} else {
			this.view.reportError(
					"Please select a car details from the car table list",
					"Selection error");
		}

	}// end update

	private void xhsDelete() {
		String reg = this.view.getRegistratioNumber();

		try {
			int pos = this.model.getCarPositionByRegistrationNumber(reg);
			if (pos > -1) {
				this.model.removeAt(pos);
				this.view
						.reportSuccess(
								"Car has be successfully deleted from database",
								"News");
				this.view.set("", "", 0);
			}
		} catch (AppException err) {
			this.view.reportError(err.getMessage(), "deletion error");
		}
	}// end xhsDeleted

	private void xhsDisplayAll() {
		
			this.model.loadCars();
			this.view.setTableModel(this.model.getTableModel());

	}

	// This method searh the car table database to see it the match string is
	// found
	private void xhsFind() {
		String registration = this.view.getRegistratioNumber();
		String modelNumber = this.view.getModelNumber();
		String mileage = this.view.getMileage();

		try {
			// This function find by registration number or model or mileage
			// number or both
			this.model.filter(registration, modelNumber, mileage);
		} catch (AppException err) {
			this.view.reportError(err.getMessage(), "error message:find");
		}

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

    @Override
    public Model getModel() {
        return this.model;
    }

    @Override
    public View getView() {
        return this.view;
    }

    @Override
    public void lunch() {
        
       this.view.pack();  
       this.view.center();
       this.view.setResizable(false);
       this.view.setVisible(true);
       
   
    }

   
   

	// This is the inner class object to handler the event of the View Elements
	protected class EventHandler implements ActionListener,
			ListSelectionListener {
		// the private object parent
		FleetController parent;

		// The inner class contructor
		EventHandler(FleetController controller) {
			this.parent = controller;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// Switch the action command and listen to their events
                       String actionCommand=e.getActionCommand();
			
			if(FleetView.BUTTON_ADD.equals(actionCommand)) {
				this.parent.xhsAdd();
			}
                        else if(FleetView.BUTTON_DELETE.equals(actionCommand)) {
				this.parent.xhsDelete();
			}
                        else if( FleetView.BUTTON_DISPLAY_ALL.equals(actionCommand)) {
				this.parent.xhsDisplayAll();
			}else if( FleetView.BUTTON_FIND.equals(actionCommand)) {
				this.parent.xhsFind();
			}
                        else if(FleetView.BUTTON_UPDATE.equals(actionCommand)) {
				this.parent.xhsUpdate();
			}
                        else
                        {
                            
			}

		}//end actionCommand Performed

		@Override
		public void valueChanged(ListSelectionEvent e) {
			// get the list selection model from the e event
			ListSelectionModel lse = (ListSelectionModel) e.getSource();
			int selectedIndex = lse.getLeadSelectionIndex();
			// if there is a selections
			if (!lse.isSelectionEmpty()) {
				// get the car at that position
				Car car = this.parent.model.at(selectedIndex);
				if (car == null) {
					return;
				}

				this.parent.view.set(car.getRegistrationNumber(),
						car.getModel(), car.getMileage());

			}

		}

	}
	// creating the inner class to control the event handler


}
