/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

/**
 *
 * @author hacker
 */
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import includes.*;
import views.*;
import models.*;

public final class CarHiringController extends Controller {
//creating the controller model and view
    private MainView view;
    private CarHiringModel model;
    private static boolean isLogin = false;
    private static boolean isFirstTime = false;
//if it is zero it the model for car else 1 it is the model for borrows
    private static int currentTableModel = 1;
// Other controller declarations
    EmployeeController employeeController;
    FleetController fleetController;
    AuthenticationController authenticatorController;

    public CarHiringController() {
//super();
        view = new MainView();
        model = new CarHiringModel();

//set the event listener of the view 
        EventHandler eventHandler = new EventHandler(this);
        view.addActionListener(eventHandler);
        view.addListSelectionListener(eventHandler);

//sett the model table data and the view table data source
        this.model.loadHireCars();
        this.view.setTableModel(this.model.getTableModel());
//create the other controller here
        employeeController = new EmployeeController();
        fleetController = new FleetController();


    }

    public void setParent(Container parent) {
        this.view.setLocationRelativeTo(parent);
    }

    public void update() {
// TODO Auto-generated method stub
    }

    @Override
    public void lunch() {


        this.view.pack();
        this.view.setResizable(false);
        this.view.center();
        this.view.setTitle("Car Hiring System 1.0v");
        this.view.validate();

//Check if there is already an administrator or employee
        EmployeeList employees = (EmployeeList) this.employeeController.getModel();
        employees.loadEmployees();
        if (employees.getRowCount() == 0) {
            this.view.reportSuccess("Welcome to Car Hiring System version 1.0  \n"
                    + "This is the first time you are running the application   \n"
                    + "therefore, your are given a privillage to create an account as \n a staff and assigned your self an aministrator.", null);

            this.view.setAdministratorState(true);
            isFirstTime = true;
        }
        this.view.setVisible(true);
    }

    private void xhsEmployeeSettingsWindow() {
        try {
            EmployeeList employees = (EmployeeList) this.employeeController.getModel();

            if (!employees.isAdmin(this.view.getEmployeeID()) && isFirstTime == false) {
                throw new AppException("You need administrator authorisation to be able to carryout this operation please!");

            } else {
                employeeController.lunch();
            }
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message:");
        }

    }

// the function that load the car settings window
    private void xhsCarSettingsWindow() {
        EmployeeList employees = (EmployeeList) this.employeeController.getModel();
        try {
            employees.loadEmployees();

            if (employees.isAdmin(this.view.getEmployeeID())) {

                Fleet.isAdministratorView = true;
                fleetController.lunch();
            } else {
                throw new AppException("You need administrator authorisation to be able to carryout this operation please!");

            }
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }
    }

//The method to display the available car
    private void xhsDisplayAvailableCars() {
        Fleet fleet = (Fleet) this.fleetController.getModel();
        currentTableModel = 0;
        try {
            Fleet.isAdministratorView = false;
            fleet.loadCars();
            fleet.filterAvailableCars(false);
            this.view.setTableModel(fleet.getTableModel());
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }
    }
//This function display non available cars,just to give the staff idea
    private void xhsDisplayNonAvailableCars() {
        Fleet fleet = (Fleet) this.fleetController.getModel();
        currentTableModel = 0;
        try {
            Fleet.isAdministratorView = false;
            fleet.loadCars();
            fleet.filterAvailableCars(true);
            this.view.setTableModel(fleet.getTableModel());
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }
    }

//this method display all the car in the database
    private void xhsDisplayAllCars() {
        Fleet fleet = (Fleet) this.fleetController.getModel();
        currentTableModel = 0;

        Fleet.isAdministratorView = false;
        fleet.loadCars();
        this.view.setTableModel(fleet.getTableModel());

    }

//this method allow the user to call the change password window 
    private void xhsChangePassword() {
      this.authenticatorController.lunch();
    }

//This method display the borrow cars of the employee
    private void xhsGetBorrowCars() {
        currentTableModel = 1;
        String employeeID = this.view.getEmployeeID();
        try {

            this.model.loadHireCars();
            this.model.filterByCars(employeeID);
            this.view.setTableModel(this.model.getTableModel());

        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error:");
        }
    }
// the inner class t handler the events

    private void xhsSelectedFleetCar() {
        Fleet fleet = (Fleet) this.fleetController.getModel();
        int selectedIndex = this.view.getSelectedIndex();
//System.out.println(selectedIndex);
//get the current car details
        Car car = fleet.at(selectedIndex);

//set the car fields details 
        this.view.setCarDetail(car.getRegistrationNumber(), car.getModel(), car.getMileage(), car.getStatus());


    }
//The method get the current car
    private void xhsSelectedBorrowedCar() {
        int selectedIndex = this.view.getSelectedIndex();
//System.out.println(selectedIndex);
        Fleet fleet = (Fleet) this.fleetController.getModel();
        try {
            HireCar hireCar = this.model.at(selectedIndex);
            fleet.loadCars();
            int aIndex = fleet.getCarPositionByRegistrationNumber(hireCar.getCarRegistrationNumber());
            Car car = fleet.at(aIndex);
            if (car == null) {
                return;
            }
//set the view form car detail
            this.view.setCarDetail(car.getRegistrationNumber(), car.getModel(), car.getMileage(), car.getStatus());

        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }



    }
//the method close the application

    private void xhsExit() {
        this.view.dispose();
        System.exit(0);
    }

//This method check if the user is allow to use the app
    private void xhsAuthenticatedUser() {
//get the login details
        String employeeID = (!"".equals(this.view.getEmployeeID())) ? this.view.getEmployeeID() : "";
        String password = this.view.getPassword();
//this.view.setEnableCommands(true);
        EmployeeList employees = (EmployeeList) this.employeeController.getModel();
        try {
            employees.loadEmployees();
//check if the employee exist and get the information of the employee;
            Employee employee;
            int index = employees.getEmployeePositionByID(employeeID);
            if (index < 0 || index >= employees.getRowCount()) {
                throw new AppException("Invalid login information please try again ");
            }
//if every is okay get the employee detail
            employee = employees.at(index);
            employee.setPassword(password);
            this.authenticatorController=new AuthenticationController(employeeID);
            Authentication authenticator=(Authentication)this.authenticatorController.getModel();
            if (authenticator.isEmployeeAuthenticated(employee)) {
                isLogin = true;
                //initialised the ability to change password
                 
                 
                 this.view.setEmployeeFullName(employee.getFirstName() + " " + employee.getLastName());
                this.view.setLoginStatus(true);
                this.view.setEnableCommands(true);
                if (employees.isAdmin(employee.getEmployeeID())) {
                    this.view.setAdministratorState(true);
                } else {
                    this.view.setAdministratorState(false);
                }

            } else {
                throw new AppException("Invalid login information please try again 2 ");
            }
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }

    }//end authentication

    private void xhsLogUserOut() {
        if (isLogin) {
//swicth login off
            isLogin = false;
            this.view.setEnableCommands(false);
            this.view.setLoginStatus(false);
            xhsGetBorrowCars();
        }
    }
//this method reserve the car to the current user
    private void xhsCarReservation() {
        String employeeID = this.view.getEmployeeID();
        String carReg = this.view.getCarRegistrationNumber();
        EmployeeList employees = (EmployeeList) this.employeeController.getModel();
        Fleet fleet = (Fleet) this.fleetController.getModel();
        try {
//load all the cars and employee to memory
            fleet.loadCars();
            employees.loadEmployees();
            if (employees.isEmployeeIDExists(employeeID)) {
                if (fleet.isCarBorrowedAlready(carReg)) {

                    throw new AppException("This car is not available at the moment please!");
                }
//else continue with borrowing

                this.model.borrowCar(carReg, employeeID);
                this.view.setTableModel(this.model.getTableModel());
                this.view.reportSuccess("The car has be successfully resereved for you", "News");
                this.view.setCarDetail("", "", 0, true);
                this.xhsGetBorrowCars();

            } else {
//logout the user
                this.xhsLogUserOut();
            }

        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }

    }

//this method provided the interface for the user to find car throw and get the information from the data model
    private void xhsFindCars() {
        String registration = this.view.getCarRegistrationNumber();
        String modelNumber = this.view.getCarModel();
        String mileage = this.view.getCarMileage();
        Fleet fleet = (Fleet) this.fleetController.getModel();

        try {
// This function find by registration number or model or mileage
// number or both
            Fleet.isAdministratorView = false;
            fleet.filter(registration, modelNumber, mileage);
            this.view.setTableModel(fleet.getTableModel());
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "finding error");
        }
    }
//this method allow the user to return a car

    private void xhsCarReturn() {
//System.out.println("return...");

        String strRegistrationNumber = this.view.getCarRegistrationNumber();
        String employeeID = this.view.getEmployeeID();
        Fleet fleet = (Fleet) this.fleetController.getModel();

        try {
            fleet.loadCars();
            if (fleet.isCarExists(strRegistrationNumber)) {
//car found
                if (fleet.isCarBorrowedAlready(strRegistrationNumber)) {
//this car is borrow okay
                    this.model.returnCar(strRegistrationNumber, employeeID);
                    this.view.setTableModel(this.model.getTableModel());
                    this.view.setCarDetail("", "", 0, true);
                } else {
                    throw new AppException("This car is 100% available for you to borrow not to return");
                }

            } else {
                throw new AppException("Enter a valid car registration or select from my borrow car list");
            }

        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Error Message");
        }
    }

    @Override
    public Model getModel() {
        return this.model;
    }

    @Override
    public View getView() {
        return null;
    }

///The Inner class that handler all the events for the controller
    private class EventHandler implements ActionListener, ListSelectionListener {

        CarHiringController parent;

        EventHandler(CarHiringController controller) {
            this.parent = controller;
        }

        @Override
        public void valueChanged(ListSelectionEvent e) {
//check if the value is adjusting  

            Fleet.isAdministratorView = false;
            if (e.getValueIsAdjusting() == true) {
//get the ListSelectionModel;
                ListSelectionModel lsm = (ListSelectionModel) e.getSource();

                EmployeeList employees = (EmployeeList) this.parent.employeeController.getModel();
                employees.loadEmployees();
                if (!employees.isEmployeeIDExists(this.parent.view.getEmployeeID())) {
                    this.parent.view.reportError("You can not select a car unless you login ", "Alert");
                    lsm.clearSelection();
                    return;
                }//end


                if (!lsm.isSelectionEmpty()) {
//check to know which model is that
                    if (CarHiringController.currentTableModel == 0) {
//call car table model
                        this.parent.xhsSelectedFleetCar();
                    } else if (CarHiringController.currentTableModel == 1) {
//call borrowed Car table model
                        this.parent.xhsSelectedBorrowedCar();
                    }

                }

            }
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String a = e.getActionCommand();


            if (MainView.BUTTON_EMPLOYEE_SETTINGS.equals(a)) {
                this.parent.xhsEmployeeSettingsWindow();

            } else if (MainView.BUTTON_CAR_SETTINGS.equals(a)) {
                this.parent.xhsCarSettingsWindow();
            } else if (MainView.BUTTON_AVAILABLE_CARS.equals(a)) {
                this.parent.xhsDisplayAvailableCars();
            } else if (MainView.BUTTON_NON_AVALIABLE_CARS.equals(a)) {
                this.parent.xhsDisplayNonAvailableCars();
            } else if (MainView.BUTTON_ALL_CARS.equals(a)) {
                this.parent.xhsDisplayAllCars();
            } else if (MainView.BUTTON_MYHIREDCARS.equals(a)) {
                this.parent.xhsGetBorrowCars();
            } else if (MainView.BUTTON_CLOSE_APPLICATION.equals(a)) {
                this.parent.xhsExit();
            } else if (MainView.BUTTON_CHANAGE_PASSWORD.equals(a)) {
                this.parent.xhsChangePassword();
            } else if (MainView.BUTTON_AUTHENTICATION.equals(a)) {
                this.parent.xhsAuthenticatedUser();
            } else if (MainView.BUTTON_LOGOUT.equals(a)) {
                this.parent.xhsLogUserOut();
            } else if (MainView.BUTTON_RESERVE.equals(a)) {
                this.parent.xhsCarReservation();
            } else if (MainView.BUTTON_RETURN_CAR.equals(a)) {
                this.parent.xhsCarReturn();

            } else if (MainView.BUTTON_FIND_CAR.equals(a)) {
                this.parent.xhsFindCars();
            } else {
//do nothing  
            }



        }
    }
}
