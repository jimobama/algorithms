/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;

import javax.swing.table.AbstractTableModel;

/**
 *
 * @author hacker
 */


public class Car implements Model {

	/**
	 * A serialised class must declare a static serialVersionUID
	 */
	private static final long serialVersionUID = -8430657928772402458L;
	// declaring the class fields registration number ,model ,mileage and the
	// status flag which will later
	// be used to track if a class is hired or not
	private String reg;
	private String model;
	private int mileage;
	private boolean status;

	// The constructor class without parameter
	public Car() {
		reg = "";
		model = "";
		mileage = 0;
		status = false;
	} // This parameterised constructor set the fields of the Car , when its
		// object is create

	public Car(String aReg, String aModel, int aMileage, boolean aStatus)
			throws AppException {
		try {
			// calling the set method of the class to initialised the Car
			// fields.
			set(aReg, aModel, aMileage, aStatus);
		} catch (AppException err) {
			throw err;
		}

	}

	// This method set the fields of the car class
	final public void set(String aReg, String aModel, int aMileage,
			boolean aBool) throws AppException {
		// Setting the fields of the Car with the parameter passed above
		try {
			this.setRegistrationNumber(aReg);
			this.setMileage(aMileage);
			this.setStatus(aBool);
			this.setModel(aModel);
		} catch (AppException err) {
			throw err;
		}catch(NumberFormatException err)
		{
			throw new AppException("Enter a valid number in mileage field please!");
		}
	}

	
	
	// This method set the fields of the car class
		final public void set(String aReg, String aModel, int aMileage
				) throws AppException {
			// Setting the fields of the Car with the parameter passed above
			try {
				this.setRegistrationNumber(aReg);
				this.setMileage(aMileage);
			    this.setModel(aModel);
			} catch (AppException err) {
				throw err;
			}
			catch(NumberFormatException err)
			{
				throw new AppException("Enter a valid number in mileage field please!");
			}
		}
		
		
	// The setters method sections
	final public void setModel(String aModel) throws AppException {
		if (!Validator.isCarModel(aModel) || aModel.trim().isEmpty()) {
			throw new AppException(
					"Enter a valid car model please!, it could be the combination Letters and Number only");
		}

		model = aModel;
	}

	final public void setRegistrationNumber(String aReg) throws AppException {
		if (!Validator.isCarRegistrationNumber(aReg)) {
			throw new AppException(
					"Enter a valid UK registration number please! e.g AAYYAAA");
		}
		reg = aReg;
	}

	final public void setMileage(int aMileage) throws AppException {
		if (!Validator.isNumeric(String.valueOf(aMileage)) || aMileage <= 0) {
			throw new AppException(
					"Enter a numberic integer value required for car mileage");
		}
		mileage = aMileage;
	}

	final public void setStatus(boolean aStatus) // set the flag status field of
	// the class
	{
		status = aStatus;
	}

	// The getter method functions
	public String getModel() { // return model field value of the class object
		return model;
	}

	public String getRegistrationNumber() // return the registration number
	{
		return reg;
	}

	public int getMileage() // return the mileage value of the car object field
	{
		return mileage;
	}

	public boolean getStatus() // return the flag field value of the class
								// object
	{
		return status;
	}

	// This method display the details of the car in question

	@Override
	// Return the car object fields values as a string
	public String toString() {
		String strReturn;
		strReturn = "registrationNumber => " + reg + ",model => " + model
				+ ",mileage => " + mileage;
		return strReturn;
	}

	// This method validate the class
	@Override
	public boolean valiadated() throws AppException {
		try {
			this.setRegistrationNumber(this.getRegistrationNumber());
			this.setModel(this.getModel());
			this.setMileage(this.getMileage());
		} catch (AppException err) {
			throw err;
		}
		catch(NumberFormatException err)
		{
			throw new AppException("Enter a valid number in mileage field please!");
		}
		return true;
	}

   
	

}
