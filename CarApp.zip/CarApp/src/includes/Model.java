/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;

/**
 *
 * @author Obaro I. Johnson
 */


import java.io.Serializable;


/*The Data structure class interface 
 *  Any class that implement this interface is a Data structure but not an implementations it does not implement 
 * */
public interface Model extends Serializable {

	// this method must be inherit by any sub class to validate is fields
	public boolean valiadated() throws AppException;

    @Override
	public String toString();
      
}// end model class

