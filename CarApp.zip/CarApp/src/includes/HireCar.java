/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;
import java.util.Date;
/**
 *
 * @author hacker
 */
public class HireCar implements Model {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String carReg;
	private Date date;
	private String employeeID;

	@Override
	public boolean valiadated() throws AppException {
		// TODO Auto-generated method stub
		return false;
	}

	public String getCarRegistrationNumber() {
		return carReg;
	}

	public void setCarRegistrationNumber(String reg)
			throws AppException {
		if (reg.isEmpty()
				|| reg.trim().equals(""))
			throw new AppException("Set reservation number for car please! or contact admin");
		this.carReg = reg;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) throws AppException {
		if (employeeID.isEmpty() || employeeID.trim().equals(""))
			throw new AppException("Set Employee number for hire car please!");
		this.employeeID = employeeID;
	}

}
