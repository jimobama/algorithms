/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;

/**
 *
 * @author hacker
 */
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;

//The view interface since I am not going to carry out any implementation of the
//Class I use interface here
public abstract class View extends JDialog {

	private static final long serialVersionUID = 1L;
    
	protected Font fntButtonText;
	protected  Font fntTextField;
 
	public View() {
		super();
	// init fonts
		this.fntButtonText = new Font("sansserif", Font.BOLD, 14);
		this.fntTextField = new Font(Font.SERIF, Font.PLAIN, 16);	
	}

	// The abstract class that must be
	protected abstract void initGui();

	protected abstract void setModel(Model aDataSources);

	// this method can be override and it throw ViewException error
	public void reportError(String message, String title) {

		JOptionPane.showMessageDialog(this, message, title,JOptionPane.ERROR_MESSAGE |  JOptionPane.OK_OPTION);

	}// end the method reportError

	public void reportSuccess(String message, String title) {

		JOptionPane.showMessageDialog(this, message, title,
				JOptionPane.INFORMATION_MESSAGE | JOptionPane.OK_OPTION);

	}

	// this function resized an image of type Image Icon
	public final ImageIcon resizeImage(ImageIcon icon, int w, int h) {
		// Create an image Icon
		Image img = icon.getImage();
		// Scale the image object to the give height and width and return the
		// newImage Object
		Image newimg = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
		return new ImageIcon(newimg);
	}// end method

	public void center() {
		int width, height;
		// get the screen size
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		width = dim.width;
		height = dim.height;

		// calculate the new location of the window
		int w = this.getSize().width;
		int h = this.getSize().height;
		int x = (width - w) / 2;
		int y = (height - h) / 2;
		// moves this component to a new location, the top-left corner of
		// the new location is specified by the x and y
		// parameters in the coordinate space of this component's parent
		this.setLocation(x, y);
	}

	public static void setTableAlignment(JTable tblCarInfo) {
		 tblCarInfo.setShowGrid(false);
		//Set the alignment of the views table
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment( JLabel.CENTER );
		tblCarInfo.setDefaultRenderer(String.class, centerRenderer);
		tblCarInfo.setDefaultRenderer(Integer.class, centerRenderer);
		tblCarInfo.setDefaultRenderer(Boolean.class, centerRenderer);
		tblCarInfo.setDefaultRenderer(Double.class, centerRenderer);
	}
        
        
        
        public abstract void addActionListener(ActionListener listener);
        public abstract void addListSelectionListener(ListSelectionListener listener);

}// end the class

