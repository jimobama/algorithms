/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;

/**
 *
 * @author hacker
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
//import the stream to out objects to file and get objects from file;

//This class wrappers the BufferedInput and Out Stream object
public class IOStream {

    final private String DATABASE_DIR = "VData";
    private FileOutputStream fileOut;
    private FileInputStream fileInput;

// create a filename stream that will hold the filename to work with
    public IOStream() {
    }

    private void create(String filename) throws AppException {
        //check if the directory exist
        File direFile=new File(DATABASE_DIR);
        //check if the directory exists else
        if(!direFile.exists())   
               direFile.mkdirs();
        
        File file = new File(DATABASE_DIR+"/" + filename);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ioErr) {
                throw new AppException(ioErr.getMessage());
            }
        }

    }
// The method serialised and save the item binary into the file
    public void putFileObjectsContent(String filename, Object object)
            throws AppException {

        this.create(filename);
        // Create BufferedOutputStream object to out objects to buffer
        ObjectOutputStream coutObject;

        try {

            // creating the file out stream
            fileOut = new FileOutputStream(DATABASE_DIR + filename);
            // create the object
            coutObject = new ObjectOutputStream(fileOut);
            coutObject.writeObject(object);
            coutObject.close();

        } catch (IOException ioExp) {
            throw new AppException("saveObject method: " + ioExp.getMessage());
        }

    }// end

// This method get the object from the files
    public Object getFileObjectContent(String filename) throws AppException {
        this.create(filename);
        // Create the input and out buffered stream objects
        ObjectInputStream cinObject;
        try {
            // create and set the File paths
            this.fileInput = new FileInputStream(DATABASE_DIR + filename);
            cinObject = new ObjectInputStream(this.fileInput);
            return cinObject.readObject() ;
        } catch (IOException ioExp) {
           
            throw new AppException("readObject error:" + ioExp.getMessage());
        }
        
         catch (ClassNotFoundException e) {
            throw new AppException("readObject error: Unable to read object from file");
        }
        
        

    }// end getObject Method
}// end class

