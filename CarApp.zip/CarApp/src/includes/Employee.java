/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;

/**
 *
 * @author hacker
 */
public class Employee implements Model {

    private static final long serialVersionUID = 1L;
    private String employeeID;
    private String firstname;
    private String gender;
    private String password;
    private String lastname;
    private boolean status;
    final String namePattern = "^[A-Za-z]+[ a-z0-9A-Z \\/]+$";

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean aBool) {
        status = aBool;
    }

    // the staff constructor without parameter
    public Employee() {
        super();
        // initialised the class attributes
        initFields();
    }

    ;

    public Employee(String aEmployeeID, String aFirstName, String aLastName,
            String aSex) throws AppException {
        super();
        // initialised the class attributes
        initFields();

        try {
            this.setEmployeeID(aEmployeeID);
            this.setFirstName(aFirstName);
            this.setLastName(aLastName);
            this.setGender(aSex);

        } catch (AppException err) {
            throw err;
        }

    }

    // This method initialised the fields of the class
    private void initFields() {
        this.employeeID = "";
        this.firstname = "";
        this.gender = "";
        this.lastname = "";
        this.password = "";
    }// end method initFields

    public void set(String aEmployeeID, String aFirstName, String aLastName,
            String aSex) throws AppException {

        try {
            this.setEmployeeID(aEmployeeID);
            this.setFirstName(aFirstName);
            this.setLastName(aLastName);
            this.setGender(aSex);
        } catch (AppException err) {
            throw err;
        }
    }

    // this function the employeeId of the staff class , the state of the
    // attributes changes when a valid id is passed
    final public void setEmployeeID(String aEmployeeID) throws AppException {
        if (aEmployeeID.isEmpty() || aEmployeeID.trim().equals("")) {
            throw new AppException(
                    "Enter a valid employee identity number please!");
        }
        this.employeeID = aEmployeeID;
    }// end method

    // This method set the full name of the employee staff
    final public void setFirstName(String aName) throws AppException {
        // check if the name value passed is a valid naming required else throw
        // exception error
        if (aName.trim().isEmpty() || aName.trim().equals("")
                || aName.length() < 3 || !aName.matches(namePattern)) {
            throw new AppException(
                    "A valid employee first name is required please e.g Obaro");
        }
        this.firstname = aName;
    }// end method setFullName
    // This method set the full name of the employee staff

    final public void setLastName(String aName) throws AppException {
        // check if the name value passed is a valid naming required else throw
        // exception error
        if (aName.trim().isEmpty() || aName.trim().equals("")
                || aName.length() < 3 || !aName.matches(namePattern)) {
            throw new AppException(
                    "A valid employee last name is required please e.g Johnson");
        }
        this.lastname = aName;
    }// end method setFullName

    // This method set the employee gender
    final public void setGender(String aSex) throws AppException {
        if (aSex.trim().equals("") || aSex.trim().equals("...")) {
            throw new AppException("Select employee gender please!");
        }
        this.gender = aSex;
    }// end the method setGender

    @Override
    public boolean valiadated() throws AppException {

        // check if the staff required validate is validated

        try {
            this.setEmployeeID(this.getEmployeeID());
            this.setFirstName(this.getFirstName());
            this.setLastName(this.getLastName());
            this.setGender(this.getGender());
            this.setPassword(this.getPassword());
        } catch (AppException err) {
            throw err;

        }

        return true;
    }

    public String getGender() {

        return this.gender;
    }

    public String getFirstName() {

        return this.firstname;
    }

    public String getLastName() {

        return this.lastname;
    }

    public String getEmployeeID() {

        return this.employeeID;
    }

    @Override
    public String toString() {
        String strfields;
        strfields = "employeeID =>" + this.employeeID + ",fullname =>"
                + this.firstname + ",gender =>" + this.gender;
        return strfields;
    }// end to string method

    public void setPassword(String aPassword) throws AppException {

        if (aPassword.trim().equals("") || aPassword.trim().length() < 6) {
            throw new AppException("Enter a valid password please!");
        }
        this.password = aPassword;
    }

    public String getPassword() {
        // check if the password is empty if it is return null
         return password;
    }
}// end class Staff