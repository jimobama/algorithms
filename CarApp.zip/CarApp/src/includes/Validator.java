/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package includes;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hacker
 */
public abstract class Validator {

	public static boolean isNumeric(String aValue) {
		// Create a regular expression pattern
		// and call the Java API Pattern and matcher to test if the value
		// matchers
		String pattern = "^[0-9]+$";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(aValue.trim());

		if (m.matches()) {
			return true;
		}
		return false;
	}// end IsNumeric

	public static boolean isCarRegistrationNumber(String aValue) {
		String pattern = "^[A-Za-z]{2}[0-9]+[a-zA-Z0-9]+$"; // Create the
															// registration
															// pattern to
															// matched the give
															// value with
		Pattern p = Pattern.compile(pattern); // This method compile the pattern
												// to the understand of Java
		Matcher m = p.matcher(aValue.trim()); // this object create a matcher
												// that will match the value
												// give
		if (m.matches()) // check if the value is match if it matches it returns
							// true else return false
		{
			return true;
		}
		return false;
	}

	public static boolean isCarModel(String aModel) {// Creating the pattern and
														// the matcher to check
														// the value passed
		String pattern = "^[A-Za-z0-9 ]+$";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(aModel.trim());
		if (m.matches()) {
			return true;
		}
		return false;
	}

}// end class
