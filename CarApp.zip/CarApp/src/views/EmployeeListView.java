/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

/**
 *
 * @author hacker
 */
import java.awt.*;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import includes.*;
import javax.swing.border.Border;

public class EmployeeListView extends View {

	private static final long serialVersionUID = 1L;
	/**
	 * Declare all the view interface control that the user will interacted with
	 */
	// Declare Major even command
	public final String ADD_EMPLOYEE_COMMAND = "Add Employee";
	public final String DISPLAY_ALL_EMPLOYEE = "Display All Employees";
	public final String FIND_EMPLOYEE = "Find";
	public final String UPDATE_EMPLOYEE_DETAILS = "update";
	public final String DELETE_EMPLOYEE_DETAILS = "Delete";
	public final String ASSIGN_ADMINSITRATOR = "Assign Admin";
	public final String REMOVE_ADMIN = "Remove Admin";

	// Create the employee Identity field
	private JLabel lblEmployeeID;
	private CustomizeTextField txtEmployeeID;
	// create the employee full name field
	private JLabel lblEmployeeFirstName;
	private CustomizeTextField txtEmployeeFirstName;
	// create the employee full name field
	private JLabel lblEmployeeLastName;
	private CustomizeTextField txtEmployeeLastName;

	private JLabel lblSearch;
	private JTextField txtSearch;
	// create employee gender field
	private JLabel lblGender;
	private JComboBox<String> cboGender;
	// create password fieldsFIND_EMPLOYEE
	private JLabel lblPassword;
	private JPasswordField pwdPassword;
	// create another fields to make sure that staff currently enter his
	// password
	private JLabel lblComfirmPassword;
	private JPasswordField pwdComfirmPassword;
	// end field creations

	// creating buttons
	JButton btnAddEmployee;
	JButton btnDisplayAll;
	JButton btnUpdateEmployee;
	JButton btnNewEmployee;
	JButton btnAssignAdministrator;
	JButton btnRemoveAdministrator;
	JButton btnDeleteEmployee;
	JButton btnSearch;

	// create Command Tool bar
	JToolBar tlbCommands;
	// Create JPanels
	JPanel pnlMainWrapper;
	JPanel pnlHeaders;
	JPanel pnlContent;
	JPanel pnlEmployeeDetails;
	JPanel pnlAdministrators;
	JPanel pnlDataButton;
	JPanel pnlSearch;
        JPanel pnlButtons;
	// create tables
	JTable tblEmployees;
	// create List object
	JList<String> lstAdministrators;

	// create JScrollpanel
	JScrollPane jspEmployees;
	JScrollPane jspAdministrators;

	// create Layouts
	GridBagLayout gblLayout;
	// create Layout constraints
	GridBagConstraints gbConstraints;

	

	public EmployeeListView() {
		super();
                this.initGui();

	}

	private void initFields() {

		// init tables and scrollpanel
		this.tblEmployees = new JTable();
		// this set the table view ports
		this.tblEmployees.setPreferredScrollableViewportSize(new Dimension(820,
				200));
		this.tblEmployees.setFont(this.fntTextField);
		this.tblEmployees.setFillsViewportHeight(true);
		this.tblEmployees.setShowHorizontalLines(false);
		this.tblEmployees.setShowVerticalLines(false);
		// set the cell value to center
		View.setTableAlignment(tblEmployees);

		this.lstAdministrators = new JList<String>();

		this.lstAdministrators.setPreferredSize(new Dimension(220, 100));
		// setting the JscrollPane
		this.jspEmployees = new JScrollPane(this.tblEmployees);
		jspAdministrators = new JScrollPane(this.lstAdministrators);

		Border blackline = BorderFactory.createEtchedBorder(1);
		Border title = BorderFactory.createTitledBorder(blackline,
				"Create New Account...");
		Border titleAdmin = BorderFactory.createTitledBorder(blackline,
				"Administrator List");

		Border pnlChangePasswordPanelTitle = BorderFactory.createTitledBorder(
				blackline, "Search Panel");
		

		// init textfields
		this.txtEmployeeFirstName = new CustomizeTextField(30);
		this.txtEmployeeFirstName.setFont(fntTextField);

		this.txtEmployeeLastName = new CustomizeTextField(30);
		this.txtEmployeeLastName.setFont(fntTextField);

		this.txtEmployeeID = new CustomizeTextField(30);
		this.txtEmployeeID.setFont(fntTextField);

		this.txtSearch = new JTextField(40);
		this.txtSearch.setFont(fntTextField);
		// init combo boxes
		this.cboGender = new JComboBox<String>();
		this.cboGender.setFont(fntTextField);
		
		this.cboGender.addItem("...");
		this.cboGender.addItem("Male");
		this.cboGender.addItem("Female");
		// Init password fields
		this.pwdComfirmPassword = new JPasswordField(20);
		this.pwdComfirmPassword.setFont(fntTextField);
		this.pwdPassword = new JPasswordField(20);
		this.pwdPassword.setFont(fntTextField);

		// init labels
		this.lblComfirmPassword = new JLabel("Re-Password :");
		this.lblEmployeeFirstName = new JLabel("First Name :");
		this.lblEmployeeLastName = new JLabel("Last Name :");
		this.lblEmployeeID = new JLabel("Next Employee Id:");
		this.lblGender = new JLabel("Gender :");
		this.lblPassword = new JLabel("Password :");
		this.lblSearch = new JLabel("Searching for:");

		// initialised buttons

		this.btnAddEmployee = new JButton(ADD_EMPLOYEE_COMMAND);
		this.btnAddEmployee.setFont(fntButtonText);
		this.btnAddEmployee.setBorderPainted(false);
		this.btnAddEmployee.setAlignmentY(SwingConstants.RIGHT);
		// this.btnAddEmployee.setPreferredSize(new Dimension(0,30));

		this.btnAssignAdministrator = new JButton(ASSIGN_ADMINSITRATOR);
		this.btnAssignAdministrator.setFont(fntButtonText);
		this.btnAssignAdministrator.setBorderPainted(false);

		this.btnDeleteEmployee = new JButton(DELETE_EMPLOYEE_DETAILS);
		this.btnDeleteEmployee.setFont(fntButtonText);
		this.btnDeleteEmployee.setBorderPainted(false);

		this.btnDisplayAll = new JButton(DISPLAY_ALL_EMPLOYEE);
		this.btnDisplayAll.setFont(fntButtonText);
		this.btnDisplayAll.setBorderPainted(false);

		this.btnNewEmployee = new JButton("New Employee");
		this.btnNewEmployee.setFont(fntButtonText);
		this.btnNewEmployee.setBorderPainted(false);

		this.btnRemoveAdministrator = new JButton(REMOVE_ADMIN);
		this.btnRemoveAdministrator.setFont(fntButtonText);
		this.btnRemoveAdministrator.setBorderPainted(false);

		this.btnUpdateEmployee = new JButton(UPDATE_EMPLOYEE_DETAILS);
		this.btnUpdateEmployee.setFont(fntButtonText);
		this.btnUpdateEmployee.setBorderPainted(false);

		this.btnSearch = new JButton(FIND_EMPLOYEE);
		this.btnSearch.setFont(fntButtonText);
		

		// init JPanels
		this.pnlAdministrators = new JPanel(new GridBagLayout());
		//this.pnlAdministrators.setBorder(titleAdmin);
		this.pnlContent = new JPanel(new GridBagLayout());
                this.pnlContent.setBorder(title);
		this.pnlEmployeeDetails = new JPanel(new GridBagLayout());		
		this.pnlHeaders = new JPanel(new GridBagLayout());
		this.pnlMainWrapper = new JPanel(new GridBagLayout());
		this.pnlDataButton = new JPanel(new GridBagLayout());
		this.pnlSearch = new JPanel(new GridBagLayout());              
		
		// init layouts
		this.gblLayout = new GridBagLayout();

	}// end initFields()

	private void initMainWrapperGUILayout() {
		// placing the layout of the employee view
		GridBagConstraints gbC = new GridBagConstraints();
		initButtonsPanel();
                // placing the main changeable content

		gbC.fill = GridBagConstraints.HORIZONTAL;
		// place the component to the north west position of the column
		gbC.anchor = GridBagConstraints.NORTHWEST;
		gbC.gridx =0;
		gbC.gridy = 0;
		gbC.gridwidth =4;
		gbC.gridheight = 2;
                gbC.insets = new Insets(2, 2, 2, 2);
		// place the pnlContent in the first row
		this.pnlMainWrapper.add(this.pnlContent, gbC);                
                
             
                
                gbC.anchor = GridBagConstraints.NORTHWEST;
		gbC.gridx = 0;
		gbC.gridy = 3;
		gbC.gridwidth = 4;
                gbC.gridheight = 1;	
		// place the pnlHeader in the first row
		pnlMainWrapper.add(this.pnlHeaders, gbC);
                
               

	}

	private void initContentGui() {
		this.initEmployeeDetail();
                GridBagConstraints gc = new GridBagConstraints();
		// add the update button
		// add the display employee button command
                gc.anchor=GridBagConstraints.NORTHWEST;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 2;
                gc.insets.set(10,0,10,0);
		this.pnlContent.add(this.pnlEmployeeDetails, gc);             
                //add the buttons panel
                gc.anchor=GridBagConstraints.NORTHEAST;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 2;
		gc.gridy = 0;
		gc.gridwidth = 1;
                 gc.insets.set(0,5,0,5);
		this.pnlContent.add(this.pnlDataButton, gc);
                
                gc.anchor=GridBagConstraints.NORTHEAST;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 3;
		gc.gridy = 0;
		gc.gridwidth = 1;
		this.pnlContent.add(this.pnlAdministrators, gc);
	}

	private void initAdministratorPanelGui() {
		GridBagConstraints gc = new GridBagConstraints();
		// add the update button

		// add the display employee button command
		gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridwidth = 2;
		this.pnlAdministrators.add(this.jspAdministrators, gc);

		// add the display remove administrator button command
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHEAST;
		this.pnlAdministrators.add(this.btnRemoveAdministrator, gc);

	}// end pnlButtons

	public void initEmployeeDetail() {
		
		GridBagConstraints gc = new GridBagConstraints();
		// Add the current Employee Id Label
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(5, 2, 5, 2);
		this.pnlEmployeeDetails.add(this.lblEmployeeID, gc);
		// add the employee current ID
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.NORTHEAST;
		this.pnlEmployeeDetails.add(this.txtEmployeeID, gc);

		

		// Add employee first name
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 1;
		this.pnlEmployeeDetails.add(this.lblEmployeeFirstName, gc);
		// textfields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 1;
		this.pnlEmployeeDetails.add(this.txtEmployeeFirstName, gc);

		// Add employee last name
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 2;
		this.pnlEmployeeDetails.add(this.lblEmployeeLastName, gc);
		// textfields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 2;
		this.pnlEmployeeDetails.add(this.txtEmployeeLastName, gc);

		// Add gender
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 3;
		this.pnlEmployeeDetails.add(this.lblGender, gc);
		// textfields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 3;
		this.pnlEmployeeDetails.add(this.cboGender, gc);

		// Add confirm password field
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 4;
		this.pnlEmployeeDetails.add(this.lblPassword, gc);
		// textfields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 4;
		this.pnlEmployeeDetails.add(this.pwdPassword, gc);
		// Add password field
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 5;
		this.pnlEmployeeDetails.add(this.lblComfirmPassword, gc);
		// textfields
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 1;
		gc.gridy = 5;
		gc.anchor = GridBagConstraints.NORTHEAST;
		this.pnlEmployeeDetails.add(this.pwdComfirmPassword, gc);

		

	}// end

	private void initButtonsPanel() {
		GridBagConstraints gc = new GridBagConstraints();

		// add the display assign administrator button command
		gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.NORTHEAST;
                 gc.insets.set(0,0,10,0);
		this.pnlDataButton.add(this.btnAddEmployee, gc);
                gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 0;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.NORTHEAST;
		this.pnlDataButton.add(this.btnUpdateEmployee, gc);
                 gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 0;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHEAST;
		this.pnlDataButton.add(this.btnAssignAdministrator, gc);
                 gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 0;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHEAST;
		this.pnlDataButton.add(this.btnDeleteEmployee, gc);

	}

	private void initHeaderGui() {
		initSearchPanelGui();

		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 0;
                gc.insets = new Insets(2, 2, 10, 2);
		this.pnlHeaders.add(this.pnlSearch, gc);

		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.gridx = 0;
		gc.gridy = 1;
		this.pnlHeaders.add(this.jspEmployees, gc);

	}

	private void initSearchPanelGui() {
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 0;
		gc.gridy = 0;
                gc.insets = new Insets(2, 2, 2, 2);
		gc.anchor = GridBagConstraints.NORTHWEST;
		this.pnlSearch.add(this.lblSearch, gc);
		// adding the txt search
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridwidth = 2;
		this.pnlSearch.add(this.txtSearch, gc);

		// add the search button
		gc.fill = GridBagConstraints.BOTH;
		gc.gridx = 3;
		gc.gridy = 0;
                gc.gridwidth = 1;
		this.pnlSearch.add(this.btnSearch, gc);

		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.gridx = 4;
		gc.gridy = 0;
		gc.gridwidth = 1;
		this.pnlSearch.add(this.btnDisplayAll, gc);

	}

    @Override
	protected final void initGui() {
		this.initFields();// initialised the GUI fields
		// create the main layout
		this.initMainWrapperGUILayout();
		this.initAdministratorPanelGui();
		initContentGui();
		initHeaderGui();
		this.add(this.pnlMainWrapper, BorderLayout.NORTH);

	}

	

	public void addListSelectionListener(ListSelectionListener listener) {
		this.tblEmployees.getSelectionModel()
				.addListSelectionListener(listener);
	}

	@Override
	protected void setModel(Model aModel) {
		// TODO Auto-generated method stub

	}

	public void setTableModel(AbstractTableModel aModel) {
		this.tblEmployees.setModel(aModel);
	}

	public String getConfirmPassword() {
		String pw = "";
		try {
			pw=String.valueOf(this.pwdComfirmPassword.getPassword());

		} catch (NullPointerException err) {
			
		}
		return pw;

	}

	public void setAdministratorsList(AbstractListModel<String> aModel) {
		this.lstAdministrators.setModel(aModel);
	}

	public String getEmployeeFirstName() {
		return this.txtEmployeeFirstName.getText();
	}

	public String getEmployeeID() {
		// TODO Auto-generated method stub
		return this.txtEmployeeID.getText();
	}

	public String getPassword() {
		String pw = "";
		try {
			pw = String.valueOf(this.pwdPassword.getPassword());

		} catch (NullPointerException err) {
			
		}
		return pw;

	}

	// the method get the list selected index
	public String getListSelectedValue() {
		String employeeId = "";
                if(this.lstAdministrators.getSelectedIndex()>=0)
		  employeeId = this.lstAdministrators.getSelectedValue();
		return employeeId;
	}

	public String getGender() {
		String sex = (String) this.cboGender.getSelectedItem().toString();
		return sex;
	}

	public String getEmployeeLastName() {
		return this.txtEmployeeLastName.getText();
	}
	
	

	public String getEmployeeFindCriteria() {

		return this.txtSearch.getText();
	}

	public void setEmployeeFormDetail(String employeeID, String firstName,
			String lastName, String gender) {

		this.setEmployeeID(employeeID);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setGender(gender);

	}

	private void setLastName(String lastName) {
		this.txtEmployeeLastName.setText(lastName);

	}

	public void setGender(String gender) {
		// TODO Auto-generated method stub
		this.cboGender.setSelectedItem(gender);

	}

	public void setFirstName(String firstName) {
		this.txtEmployeeFirstName.setText(firstName);

	}

	public void setEmployeeID(String employeeID) {
		this.txtEmployeeID.setText(employeeID);

	}

    @Override
    public void addActionListener(ActionListener listener) {
        this.btnAddEmployee.addActionListener(listener);
		this.btnAssignAdministrator.addActionListener(listener);
		this.btnDeleteEmployee.addActionListener(listener);
		this.btnDisplayAll.addActionListener(listener);
		this.btnNewEmployee.addActionListener(listener);
		this.btnRemoveAdministrator.addActionListener(listener);
		this.btnSearch.addActionListener(listener);
		this.btnUpdateEmployee.addActionListener(listener);
    }


}
