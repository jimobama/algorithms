/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import includes.*;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionListener;
import javax.swing.*;
/**
 *
 * @author hacker
 */

/**
 *
 * @author jimobama
 */

    


public class LoginView extends View {

    
    //constant acction commands
    
    final static public String BUTTON_AUTHENTICATION="Log In";
    final static public String EXIT_APPLICATION="Exit";
    //create the class Controlls
    JLabel lblEmployeeID;
    JLabel lblCurrentPassword;
  
    
    //create textfields
    JTextField txtEmployeeID;
    JPasswordField txtPassword;
   
    
    
    //create buttons
    JButton btnCloseWindow;
    JButton btnLogin;
    
    //creating JPanels
    
    JPanel pnlMain;
    JPanel pnlHeader;
    JPanel pnlContent;
    
    
    
  public  LoginView()
    {
        super();
        this.initGui();  
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.center();
    }
    
    
    private void initFields()
    {
        //init the Label fields
        this.lblCurrentPassword=new JLabel("Password:");
        this.lblEmployeeID=new JLabel("Username:");    
       
        
        //init the textfields 
        
        this.txtEmployeeID=new  JTextField(20);
        this.txtEmployeeID.setFont(this.fntTextField);
        this.txtEmployeeID.setEditable(true);
      
        
        this.txtPassword=new JPasswordField(20);
        this.txtPassword.setFont(this.fntTextField);

        
         //init the Jpanels
         this.pnlMain=new JPanel(new GridBagLayout());
         this.pnlContent=new JPanel(new GridBagLayout());
         this.pnlHeader=new JPanel(new GridBagLayout());
         
         //initialised buttons
         
         this.btnLogin=new JButton(BUTTON_AUTHENTICATION);
         this.btnLogin.setFont(this.fntButtonText);
         this.btnCloseWindow=new JButton(EXIT_APPLICATION);
         this.btnCloseWindow.setFont(this.fntButtonText);
    
    }
    @Override
    protected final void initGui() {
        //initialised the fields by calling the initFields private method
      initFields();
      initHeaderGui();//this layout the controls of the header
      //lay the main layout
      initContentGui();//place the content
      
      GridBagConstraints gc=new GridBagConstraints();
      
      //place the header
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
      this.pnlMain.add(this.pnlHeader,gc);
      
      //place the content
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=1;     
      this.pnlMain.add(this.pnlContent,gc);      
      /// this add the main panel to the view content
      this.add(this.pnlMain);
    }

    
    private void initHeaderGui()
    {
       GridBagConstraints gc=new GridBagConstraints();
      
      //place the employeeID
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
     this.pnlHeader.add(this.lblEmployeeID,gc);  
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=0;
      gc.insets.set(5,5, 0, 5);
     this.pnlHeader.add(this.txtEmployeeID,gc); 
     
     
       //place the current password
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=0;
      gc.gridy=1;
      gc.insets.set(5,5, 0, 5);
     this.pnlHeader.add(this.lblCurrentPassword,gc);  
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=1;
      gc.insets.set(5,5, 0, 5);
      this.pnlHeader.add(this.txtPassword,gc);  
          
    }    
    
    private void initContentGui()
    {
         GridBagConstraints gc=new GridBagConstraints();
  
      //place the buttons
      
      JPanel pnlButtons=new JPanel();
      pnlButtons.add(this.btnLogin);
      pnlButtons.add(this.btnCloseWindow);
      gc.fill=GridBagConstraints.HORIZONTAL;
      gc.gridx=1;
      gc.gridy=2;
      gc.insets.set(5,5, 0, 5);
      this.pnlContent.add(pnlButtons,gc); 
      
     
    }
    @Override
    protected void setModel(Model aDataSources) {
       
    }

    @Override
    public void addActionListener(ActionListener listener) {
       this.btnLogin.addActionListener(listener);
       this.btnCloseWindow.addActionListener(listener);       
    }

    @Override
    public void addListSelectionListener(ListSelectionListener listener) {
       
    }

    public void setEmployeeID(String employeeID) {
        this.txtEmployeeID.setText(employeeID.toUpperCase());        
    }

    public String getEmployeeID() {
        return this.txtEmployeeID.getText();
    }

    public String getPassword() {
         try
        {
         String pw=String.valueOf( this.txtPassword.getPassword());
        return pw;
        }
        catch(NullPointerException err)
        {
            
        }
        return "";
    }


   

    public void setForm(String pwdPassword, String username) {
        
        this.txtPassword.setText(pwdPassword);
        this.txtEmployeeID.setText(username);
    }
    
    
    
}
