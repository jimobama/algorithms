/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package carapp;
import controllers.CarHiringController;


/**
 *
 * @author Obaro Johnson
 *
 * @version Hiring Car Version 1.0 2013 at West London Univeristy element 2
 * 
 * This is the main applictation entry class 
 * 
 * The CarApp is using full MVC designed pattern 
 */

/** Class CarApp is the main class that start the application with just one static  method main with String[] parameter array 
 
 */
public class CarApp {

    /**
     * @param args the command line arguments   
     
     @return void 
     */
    public static void main(String[] args) {
    CarHiringController hiringSystem=  new CarHiringController();    
    hiringSystem.lunch();   
        
    }
}

