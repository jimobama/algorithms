/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import includes.*;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import models.Authentication;
import models.EmployeeList;
import views.ChangePasswordView;

/**
 *
 * @author hacker
 */
public class AuthenticationController extends Controller{
     
   private Authentication model;
   private ChangePasswordView view;
    
     public AuthenticationController(String employeeID)
     {
     model=new  Authentication();
     view =new  ChangePasswordView();
     view.setEmployeeID(employeeID);
     //set employee ID and it is not editable
     //create the event object
     EventHandler eventHandler=new EventHandler(this);
     this.view.addActionListener(eventHandler);
         
     }
    @Override
    public void update() {
      this.view.repaint();
    }

    @Override
    public void lunch() {
       this.view.pack();
       this.view.center();
       this.view.setResizable(false);
       this.view.setVisible(true);
    }

    @Override
    public void setParent(Container parent) {
       
    }

    @Override
    public Model getModel() {
       return this.model;
    }

    @Override
    public View getView() {
       return this.view;
    }

    private void xhsApplyChanges() {
      
        String employeeID=this.view.getEmployeeID();
        String password=this.view.getPassword();
        String newPassword=this.view.getNewPassword();
        String confirmPassword=this.view.getConfirmPassword();
        
           
       
        try {
             //create an employeeList  object 
            EmployeeList employees=new EmployeeList();
            
            //check if the employee number exists or not
            employees.loadEmployees();
            if(!employees.isEmployeeIDExists(employeeID))
            {
                //close the window 
                  System.out.println(employeeID);
                this.xhsExitWindow();
                return ;
            }
            //get employee by the ID
            Employee employee=employees.at(employees.getEmployeePositionByID(employeeID));
            //set the password
            employee.setPassword(password);
            //validated the employee
            if(!model.isEmployeeAuthenticated(employee))
            {
             throw new AppException("Invalid employee login details");
            }
            //if the employee is confirm then change if the new password matches
            if(newPassword.length() < 6)
            {
             throw new AppException(
                        "New password must be more than 5 characters or number");   
            }
           else if (!confirmPassword.equals(newPassword)) {
                throw new AppException(
                        "New passwords did mismacth");
            }
           else
           {
            // create and set the employee updating details
             employee.setEmployeeID(employeeID);
            
          // update the staff
            employees.changePassword(newPassword, employee);
           this.view.reportSuccess("Password successfully changed","Info");
           this.view.setChangePasswordForm("","","");
           }

        } catch (AppException e) {
            this.view.reportError(e.getMessage(), "Updating Error:");
        }
        
    }

    private void xhsExitWindow() {
      this.view.dispose();
    }
    
    private class EventHandler implements ActionListener
    {
        AuthenticationController parent;
         EventHandler(AuthenticationController aParent)
         {
          this.parent=aParent;   
         }

        @Override
        public void actionPerformed(ActionEvent e) {
           String action=e.getActionCommand();
           
           if(action.equals(ChangePasswordView.APPLY_CHANGES))
           {
               this.parent.xhsApplyChanges();
           }
           else if(action.equals(ChangePasswordView.EXIT_APPLICATION))
           {
               this.parent.xhsExitWindow();
           }
          else
           {
               //do nothing
           }
         
           
        }
         
         
    }
    
    
}
