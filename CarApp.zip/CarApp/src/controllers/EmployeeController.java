/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

/**
 *
 * @author Obaro Johnson
 * 
 * @version  1.0v at West London University
 */
//import the base classes from the obaro.imports package
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import includes.*;
import models.*;
import views.*;

/** The EmployeeController class is the controller that handle both the employeeView and The Employee model class 
 . Its event methods with start with the prefix xhs-
 */
public class EmployeeController extends Controller {
//Declaring the view and the model
    private EmployeeList model;
    private EmployeeListView view;

    public EmployeeController() {
// call the super class controller
        super();
        try {
            this.model = new EmployeeList();
            this.view = new EmployeeListView();
            EventHandler listener = new EventHandler(this);
            this.view.addActionListener(listener);
            this.view.addListSelectionListener(listener);
// set the Table and the view listener
            this.view.setTableModel(model.getTableModel());
            this.view.setAdministratorsList(this.model.getListModel());
        } catch (AppException err) {
        }



    }// Parameterised Constructor
    @Override
    public void setParent(Container aParent) {
      
    }

    

// The controller method to trigger when the view send a add employee
// command
    private void xhsAdd() {
// Declare the Employee required fields from the view
        String employeeID = this.view.getEmployeeID();
        String firstname = this.view.getEmployeeFirstName();
        String lastname = this.view.getEmployeeLastName();
        String gender = this.view.getGender();
        String password = this.view.getPassword();
        String cPassword = this.view.getConfirmPassword();

// since the employeeList and Employee class model object will generate
// an AppException
// I will place the codes in a try and catch the exceptions generated

        try {
// create new employee object and set the values
// System.out.print(gender);
            Employee newEmployee = new Employee(employeeID, firstname,
                    lastname, gender);

// setting the fields values
            if (this.model.isEmployeeIDExists(employeeID)) {
                throw new AppException(
                        "Employee Identity number already exists");
            }
            newEmployee.setPassword(password);
            if (!cPassword.equals(newEmployee.getPassword())) {
                throw new AppException(
                        "Password did not match please re-enter passwords");
            }

            this.model.addEmployee(newEmployee);

            if (!this.model.isEmployeeAdded()) {
                throw new AppException(
                        "There is an error trying to add the employee ["
                        + firstname + " " + lastname + "]");
            }else
            {
               this.view.reportSuccess("The employee account has be successfully created", "Info"); 
            }

            this.view.setTableModel(this.model.getTableModel());

        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Failure Message");
        }

    }

    private void xhsDeleteEmployee() {
        String employeeID = this.view.getEmployeeID();
// put the rest of the codes in a try block
        try {
// check if the employeeId exit
            if (this.model.isEmployeeIDExists(employeeID)) {
                this.model.deleteEmployee(employeeID);
                this.view.setTableModel(this.model.getTableModel());
                this.view.reportSuccess("The employee with the number ["
                        + employeeID
                        + "] has be successfully delete form the list",
                        "Deletion sucessful");
            } else {
                throw new AppException("The Employee [ " + employeeID
                        + " ]Number doesnot not exist");
            }
        } catch (AppException newAppExc) {
            this.view.reportError(newAppExc.getMessage(),
                    "Deletion Error Message");
        }

    }// end deletion control function

    private void xhsUpdateEmployee() {
        String employeeID = this.view.getEmployeeID();
        String firstname = this.view.getEmployeeFirstName();
        String lastname = this.view.getEmployeeLastName();
        String employeeGender = this.view.getGender();
        String employeePassword = this.view.getPassword();

        try {
            Employee updateEmployee = new Employee();
            updateEmployee.set(employeeID, firstname, lastname, employeeGender);
            updateEmployee.setPassword(employeePassword);
// check if the employee exist
            if (this.model.isEmployeeIDExists(employeeID)) {
// update the employee details
                this.model.updateEmployee(updateEmployee);
// check if the update was successful
                if (this.model.isEmployeeUpdated()) {
                    this.view.setTableModel(this.model.getTableModel());
                    this.view.reportSuccess(
                            "The employee details has be successfully changed",
                            "Update successfull Messgae");
                }

            } else {
                throw new AppException("Employee Number not found "
                        + employeeID);
            }

        } catch (AppException exc) {
            this.view.reportError(exc.getMessage(), "Update Error Message");
        }

    }

// This method remove the administrator
    private void xhsDeleteAdministrator() {
        String employeeID = (this.view.getListSelectedValue().equals(""))?"":this.view.getListSelectedValue();
        if(employeeID.isEmpty())
                return ;
        try {
            if (this.model.isEmployeeIDExists(employeeID)) {
                this.model.deleteAdministrator(employeeID);
                this.view.setAdministratorsList(this.model.getListModel());
                this.view.reportSuccess(
                        "Administrator successfully remove from list",
                        "Information");
            }
        } catch (AppException err) {
            this.view.reportError(err.getMessage(),
                    "Deletion error:Aministrator");
        }
    }// end adminstrator deletion



    @Override
    public void update() {
// TODO Auto-generated method stub
    }

// create an xhsDisplayAll controller function
    public void xhsDisplayAll() {

        this.model.displayAllEmployees();
        this.view.setTableModel(this.model.getTableModel());

    }// end xhsDiaplyAll

// creating xhsFind All controller that will find and display the employees
    private void xhsFind() {
        String criteria = this.view.getEmployeeFindCriteria();
        try {
// create new Model fleet object
            this.model.findEmployees(criteria);
            this.view.setTableModel(this.model.getTableModel());
        } catch (AppException err) {
            this.view.reportError(err.getMessage(), "Find Message:");
        }

    }

    private void xhsAssignAdministrator() {
        String employeeID = this.view.getEmployeeID();
        try {
            if (this.model.isEmployeeIDExists(employeeID)) {
// check if the administrator already exist in administrator
// list
                if (!this.model.isAdmin(employeeID)) {
// assigned Administrator
                    this.model.assignAdministor(employeeID);
                    this.view.setAdministratorsList(this.model.getListModel());
                    if (this.model.isEmployeeAdded()) {
                        Employee em = this.model.at(this.model.getEmployeePositionByID(employeeID));
                        throw new AppException(
                                em.getLastName()
                                + " has be successfully assigned an administrator");
                    }
                } else {
                    throw new AppException(
                            "Oops this staff is already an administrator");
                }

            } else {
                throw new AppException(
                        "Invalid employee staff number please current valid employee Id");

            }
        } catch (AppException err) {
            this.view.reportError(err.getMessage(),
                    "error:Assign Administrator");
        }

    }

    @Override
    public Model getModel() {
       return this.model;
    }

    @Override
    public View getView() {
        return this.view;
    }

    @Override
    public void lunch() {
       this.view.pack();  
       this.view.center();
       this.view.setResizable(false);
       this.view.setVisible(true);       
    }


    /*
     * 
     * The inner controller event handler that will handle all the view event to
     * be able to interact with its model
     */
    protected class EventHandler implements ActionListener,
            ListSelectionListener {

        EmployeeController parent;

// The inner class Constructor
        EventHandler(EmployeeController aParent) {
            parent = aParent;
        }

        @Override
        public void actionPerformed(ActionEvent event) {
// TODO Auto-generated method stub

            if (this.parent.view.ADD_EMPLOYEE_COMMAND.equals(event.getActionCommand())) {
// Add staff to file

                this.parent.xhsAdd();// call the controller xhsAdd Employee
// method

            } else if (this.parent.view.DISPLAY_ALL_EMPLOYEE.equals(event.getActionCommand())) {
// Display all the employees
                this.parent.xhsDisplayAll();
            } else if (this.parent.view.FIND_EMPLOYEE.equals(event.getActionCommand())) {
// Find a particular employee either by name or employee ID
                this.parent.xhsFind();
            } else if (this.parent.view.UPDATE_EMPLOYEE_DETAILS.equals(event.getActionCommand())) {
// update employee details
                this.parent.xhsUpdateEmployee();
            } else if (this.parent.view.DELETE_EMPLOYEE_DETAILS.equals(event.getActionCommand())) {
// delete employee
                this.parent.xhsDeleteEmployee();
            } else if (this.parent.view.ASSIGN_ADMINSITRATOR.equals(event.getActionCommand())) {
                this.parent.xhsAssignAdministrator();
            } else if (this.parent.view.REMOVE_ADMIN.equals(event.getActionCommand())) {
                this.parent.xhsDeleteAdministrator();
            }

        }

        @Override
        public void valueChanged(ListSelectionEvent evt2) {
// get the listSelectionModel which is the particuar row selected
            ListSelectionModel lse = (ListSelectionModel) evt2.getSource();
            int selectedIndex = lse.getLeadSelectionIndex();
// check if the selected row changes
            if (!lse.isSelectionEmpty()) {
                try {
                    Employee employee = this.parent.model.at(selectedIndex);
                    this.parent.view.setEmployeeFormDetail(
                            employee.getEmployeeID(), employee.getFirstName(),
                            employee.getLastName(), employee.getGender());
                } catch (AppException err) {
                    this.parent.view.reportError(err.getMessage(),
                            "Error:Table Selection");
                }
            }

        }
    }//end inner event handler class
}//end class 
