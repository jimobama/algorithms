/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import includes.AppException;
import includes.Employee;
import includes.Model;

/**
 *
 * @author hacker
 */
public class Authentication implements Model{

    public Authentication()
     {
        super(); 
     }
    @Override
    public boolean valiadated() throws AppException {
      return false;
    }

    public boolean isEmployeeAuthenticated(Employee aEmployee)throws AppException {
               
            try
            {
                EmployeeList employees =new EmployeeList();
                 employees.loadEmployees();
                 
                 
            if ( employees.isEmployeeIDExists(aEmployee.getEmployeeID())) {
                
               
                    int index= employees.getEmployeePositionByID(aEmployee.getEmployeeID());
                    
                    Employee temEmployee =  employees.at(index);
                        // check if the password and the user name is correct
                    
                    if (temEmployee.getPassword().equals(aEmployee.getPassword())) {
                            return true;
                    }
                    return false;
            }// end if
            }
            catch(AppException err)
            {
                    throw err;
            }

            return false;
    }
}
