/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author hacker
 */
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import includes.*;

/*
 Implementation of Aggregation designed pattern 


 The fleet aggregate Car
 */
public class Fleet extends Car {
	/**
	 * This class can be serialised because it is inheriting from the Car object
	 * who primary inherit from the Model Interface
	 */
	private static final long serialVersionUID = 1L;
	// declare a car list
	ArrayList<Car> cars;
	IOStream db;
	TableModel tableModel;
	boolean isOkay;
	static public boolean isAdministratorView;

	public Fleet() {
		super();
		isAdministratorView = true;
		isOkay = false;
		db = new IOStream();
		cars = new ArrayList<Car>();
		tableModel = new TableModel(this);
	}

	@SuppressWarnings("unchecked")
	public void loadCars()  {
		// TODO Auto-generated method stub
		try {
			this.cars = (ArrayList<Car>) this.db
					.getFileObjectContent("cars.ob");
			this.tableModel.fireTableDataChanged();
			this.tableModel.fireTableStructureChanged();
		} catch (AppException err) {
			
		}
	}

	public void filterAvailableCars(boolean aBool) throws AppException {
		ArrayList<Car> temCars = new ArrayList<Car>();

		
			this.loadCars();
			// if there is a car then
			if (this.cars != null) {
				// loop and find the cars available
				for (int i = 0; i < this.cars.size(); i++) {
					Car car = this.at(i);
					// match if the value is true
					if (car.getStatus() == aBool) {
						temCars.add(car);
					}

				}
			}

		 

		this.cars = temCars;
		this.tableModel.fireTableDataChanged();
		this.tableModel.fireTableStructureChanged();

	}// end method

	public void saveCars() throws AppException {

		try {
			this.db.putFileObjectsContent("cars.ob", this.cars);
			this.tableModel.fireTableStructureChanged();
		} catch (AppException err) {
			throw err;
		}
	}

	public void add(Car car) throws AppException {
		isOkay = false;
		try {
			// transform the registration to upper case
			car.setRegistrationNumber(car.getRegistrationNumber().toUpperCase().trim());
			car.setStatus(false);
			// check if the variable fields of the car is currently set
			if (car.valiadated()) {
				this.loadCars();
				cars.add(car);
				this.saveCars();
				this.tableModel.fireTableDataChanged();

				isOkay = true;
			}// end if

		} catch (AppException err) {
			throw err;
		}
	}

	public void insert(int index, Car car) throws AppException {
		try {
			// check if the car fields are correct set
			if (car.valiadated()) {
				cars.set(index, car);
				this.saveCars();
				this.tableModel.fireTableDataChanged();
			}

		} catch (AppException err) {
			throw err;
		}

	}// end insert or update a car

	public void removeAt(int aIndex) throws AppException {
		if (aIndex < 0 || aIndex >= cars.size()) {
			throw new AppException("The index position is out of range ");
		}
		cars.remove(aIndex);
		this.saveCars();
		this.tableModel.fireTableDataChanged();

	}

	// This function will check if a car with the provided registration number
	// exist
	public boolean isCarExists(String aReg) {
		if (aReg == null || aReg.equals("")) // check if the registration is
		{
			return false;
		}

		aReg = aReg.toUpperCase().trim();

		for (int i = 0; i < cars.size(); i++) {
			// check if the registration number exist
			if (cars.get(i).getRegistrationNumber().trim().toUpperCase().equals(aReg)) {
				return true;
			}
		}

		return false;
	}// end isCarExists method

	public int getCarPositionByRegistrationNumber(String aReg) {
		// Finding the car with the registration number
		aReg = aReg.toUpperCase();
		int index = -1; // set the index to -1 if the registration number is not
		// found it return zero.
		for (int i = 0; i < cars.size(); i++) {
			// check if the registration number exist
			if (cars.get(i).getRegistrationNumber().equals(aReg)) {
				// Car found then stop loop
				index = i;
				break;
			}
		}
		return index; // return the car position in the list object of cars
	}// end getCarPositionBy registration Number

	public int getCarCounts() {
		return cars.size();
	}// end getNumberOfCar();

	public Car at(int aIndex) {
		if (aIndex < 0 || aIndex >= cars.size()) {
			return null;
		}
		return cars.get(aIndex);
	}

	public boolean isCarBorrowedAlready(String carRegistrationNumber) {
		
		
		if(this.isCarExists(carRegistrationNumber))
		{
			
			int index=this.getCarPositionByRegistrationNumber(carRegistrationNumber.trim().toUpperCase());
			//check the car object
			Car car=at(index);
			
			//now check the status
		  if(car.getStatus()==true)
		  {
			  return true;
		  }
		  return false;
		}
		return false;
	}

	public void updateCarStatus(String carRegistrationNumber, boolean b)throws AppException {
		
		try
		{
		this.loadCars();
		if(this.isCarExists(carRegistrationNumber.trim().toUpperCase()))
		{
			int index=this.getCarPositionByRegistrationNumber(carRegistrationNumber);
			//get the car object
			Car car=at(index);
			car.setStatus(b);
			this.updateCar(car);
			this.tableModel.fireTableDataChanged();
			
		}else
		throw new AppException("Car registration number not found");
		}
		catch(AppException err)
		{
			throw err;
		}

	}

	public final TableModel getTableModel() {
		return tableModel;
	}

	// Table model inne class

	private class TableModel extends AbstractTableModel {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		/**
		 * 
		 */

		// declare all the JTable columns
		private static final int CAR_REGISTRATION_NUMBER = 0;
		private static final int CAR_MODEL_NUMBER = 1;
		private static final int CAR_MILEAGE = 2;
		private static final int CAR_STATUS = 3;

		Fleet parent;

		TableModel(Fleet aParent) {
			parent = aParent;
		}

		// get the number of columns to create
		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 4;
		}

		@Override
		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return columnIndex == CAR_STATUS;
		}

		// setting the column name of the JTable view through its model
        @Override
		public String getColumnName(int col) {
			switch (col) {
			case TableModel.CAR_MILEAGE:
				return "Mileage";
			case TableModel.CAR_MODEL_NUMBER:
				return "Model";
			case TableModel.CAR_REGISTRATION_NUMBER:
				return "Registration Number";
			case TableModel.CAR_STATUS:
				return "Status";
			default:
				return null;
			}

		}

		// get the number of rows to loop on
		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return (cars.isEmpty()) ? 0 : cars.size();
		}

		@Override
		public Object getValueAt(int intRow, int intCol) {

			Car car = this.parent.at(intRow);
			// check if the return car is null
			if (car == null)
				return null;

			// else
			switch (intCol) {
			case TableModel.CAR_REGISTRATION_NUMBER:
				return car.getRegistrationNumber();
			case TableModel.CAR_MODEL_NUMBER:
				return car.getModel();
			case TableModel.CAR_MILEAGE:
				return car.getMileage();
			case TableModel.CAR_STATUS:
				if (isAdministratorView == true) {
					return car.getStatus();
				} else {
					if (car.getStatus() == true)
						return "not available";
					else
						return "available";
				}
			default:
				return null;
			}

		}

		@Override
		public void setValueAt(Object value, int indexRow, int colIndex) {

			try {
				// get the car object that the row positions
				Car car = this.parent.at(indexRow);

				switch (colIndex) {
				case TableModel.CAR_MILEAGE:
					car.setMileage((Integer) value);
					break;
				case TableModel.CAR_MODEL_NUMBER:
					car.setModel((String) value);
					break;
				case TableModel.CAR_REGISTRATION_NUMBER:
					car.setRegistrationNumber((String) value);
					break;
				case TableModel.CAR_STATUS: {

					car.setStatus((Boolean) value);

				}
					break;
				default:
					break;
				}
				this.parent.saveCars();

				// end switch

			} catch (AppException err) {

			}

		}

		// This method return the column type which make the editor to know the
		// type of value that it will accept

		@Override
		public Class<?> getColumnClass(int col) {
			switch (col) {
			case TableModel.CAR_MILEAGE:
				return Integer.class;
			case TableModel.CAR_MODEL_NUMBER:
				return String.class;
			case TableModel.CAR_REGISTRATION_NUMBER:
				return String.class;
			case TableModel.CAR_STATUS: {
				if (isAdministratorView == true)
					return Boolean.class;
				return String.class;
			}
			default:
				return null;
			}

		}

	}// end EmployeeList Class
		// This method filter

	public void filter(String registration, String modelNumber, String mileage)
			throws AppException {
		// load the cars
		mileage = mileage.trim();
		ArrayList<Car> searchCars = new ArrayList<Car>();
                this.loadCars();
		
			
			if (this.isCarExists(registration)) {
				int pos = this.getCarPositionByRegistrationNumber(registration);
				Car searchCar = this.at(pos);
				searchCars.add(searchCar);
			} else if (this.findCarsByModel(modelNumber).size() > 0) {
				searchCars = this.findCarsByModel(modelNumber);
			} else {
				searchCars = this.findCarsByMileage(Integer.parseInt(mileage));
			}
		

		this.cars = searchCars;
		this.tableModel.fireTableDataChanged();
		this.tableModel.fireTableStructureChanged();
	}

	private ArrayList<Car> findCarsByMileage(int mileage) {
		ArrayList<Car> searchCars = new ArrayList<Car>();

		for (int i = 0; i < this.cars.size(); i++) {
			// match if the mileage are same
			Car car = at(i);
			// search car
			if (car.getMileage() == mileage) {
				searchCars.add(car);
			}

		}// end for

		return searchCars;
	}// end method

	private ArrayList<Car> findCarsByModel(String modelNumber) {

		ArrayList<Car> searchCars = new ArrayList<Car>();

		for (int i = 0; i < this.cars.size(); i++) {
			// match if the mileage are same
			Car car = at(i);
			// search car
			if (car.getModel() == null ? modelNumber.toUpperCase().trim() == null : car.getModel().equals(modelNumber.toUpperCase().trim())) {
				searchCars.add(car);
			}

		}// end for

		return searchCars;
	}

	public void updateCar(Car car) throws AppException {
		isOkay = false;
		this.loadCars();
		try {
			if (!this.isCarExists(car.getRegistrationNumber().trim())) {
				throw new AppException("The car registration is invalid!");
			}
			// continue update
			// get the employee position
			int pos = this.getCarPositionByRegistrationNumber(car
					.getRegistrationNumber());
			cars.set(pos, car);
			// this saveEmployees after the list has be updated
			this.saveCars();
			this.tableModel.fireTableDataChanged();
			isOkay = true;
		} catch (AppException exceApp) {
			throw exceApp;
		}

	}

}// end class
