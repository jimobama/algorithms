/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
package models;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

//same packages
import includes.*;
import javax.swing.AbstractListModel;

/**
*
* @author hacker
*/
public class EmployeeList extends Employee {
private static final long serialVersionUID = 1L;

    private boolean isOkay;
    // The Employee constructor
    private final static String EMPLOYEE_FILE = "employees.ob";
    private final static String ADMINISTRATOR_FILE = "administrator.ob";
    private ArrayList<Employee> employees;
    private ArrayList<String> administratorID;
    IOStream db;
    private TableModel tableModel;

    // The employee List constructor start here
    public EmployeeList() throws AppException {
            super();
            this.isOkay = false;
            tableModel = new TableModel();
            this.employees = new ArrayList<Employee>();
            this.administratorID = new ArrayList<String>();
            this.db = new IOStream();	

            //load the employees and administrator
            //this.loadEmployees();
            this.loadAdministrators();


    }// end here

    final public void addEmployee(Employee aEmployee) throws AppException {
            try {
                    // turn off the okay flag
                    isOkay = false;
                    // try this code if there is error throw the exception again
                    aEmployee.setEmployeeID(aEmployee.getEmployeeID().trim().toUpperCase());
                    // check if the employee details required are currently entered
                    if (aEmployee.valiadated()) {
                            this.loadEmployees();
                boolean add = employees.add(aEmployee);
                if(add){
                            this.saveEmployees();
                            this.tableModel.fireTableDataChanged();
                            isOkay = true;
                }
                    }
            }// try
            catch (AppException err) {
                    throw err;
            }
    }// add method addEmployee

    final public int getEmployeePositionByID(String aEmployeeID) {
            int index = -1;// create the index and set to -1
            // Check if the aEmployeeID is empty if it is return -1
            if (aEmployeeID.trim().isEmpty()) {
                    return index;
            }
            // continue the search
            int counter = 0;
            for (Employee aEmployee : employees) {
                    // check if the Employee ID match
                    if (aEmployee.getEmployeeID().trim().toUpperCase().equals(
                                    aEmployeeID.trim().toUpperCase())) {
                            index = counter;
                            break;
                    }
                    counter++;// increment by 1
            }// end for

            return index;
    }// end getEmployeePositionByID

    // this check the list if the employee exists
    final public boolean isEmployeeIDExists(String aEmployeeID) {
             aEmployeeID =(aEmployeeID.isEmpty())?"":aEmployeeID;
            // get the staff position
            int position = this.getEmployeePositionByID(aEmployeeID.trim().toUpperCase());
            // check if the staff position is found , returns -1 if not found
            if (position < 0) {
                    return false;
            }
            return true;

    }// end method getEmployeePositionByID(aEmployeeID)

    final public void deleteEmployee(String aEmployeeID) throws AppException {
            if (!isEmployeeIDExists(aEmployeeID)) {
                    throw new AppException(
                                    "deletion fails : Enter a valid employee number please!");
            }

            int index = this.getEmployeePositionByID(aEmployeeID);
            // remove the employee
            employees.remove(index);
            this.saveEmployees();
            this.tableModel.fireTableDataChanged();
    }// end method deleteEmployee

    // This method update the employee informations
    final public void updateEmployee(Employee aEmployee) throws AppException {
            isOkay = false;
            try {
                    if (!this.isEmployeeIDExists(aEmployee.getEmployeeID().trim().toUpperCase())) {
                            throw new AppException(
                                            "employee update fails: enter a valid employee id please!");
                    }
                    // continue update
                    // get the employee position
                    int pos = this.getEmployeePositionByID(aEmployee.getEmployeeID());
                    employees.set(pos, aEmployee);
                    // this saveEmployees after the list has be updated
                    this.saveEmployees();
                    this.tableModel.fireTableDataChanged();
                    isOkay = true;
            } catch (AppException exceApp) {
                    throw exceApp;
            }
    }// end method

    // This method returns the Employee at the particular index or position
    public Employee at(int index) throws AppException {
            // check if the index is out of range
            if (index < 0 || index >= this.employees.size()
                            || this.employees.isEmpty())
                    throw new AppException("method at() says: Index(" + index
                                    + ")of or range ");
            // return the employee for the list
            return this.employees.get(index);

    }

    // this method change the user password
    public void changePassword(String newPassword, Employee aEmployee)
                    throws AppException {
            try {
                    isOkay = false;
                    if (this.isEmployeeIDExists(aEmployee.getEmployeeID())) {
                            // get the employee with the registration number
                            Employee temEmployee = this.at(this
                                            .getEmployeePositionByID(aEmployee.getEmployeeID()));
                            // set the values and update
                            if (temEmployee.getPassword() == null ? aEmployee.getPassword() == null : temEmployee.getPassword().equals(aEmployee.getPassword())) {
                                    temEmployee.setPassword(newPassword);
                                    this.updateEmployee(temEmployee);
                                    isOkay = true;//
                                   
                            } else {
                                    throw new AppException(
                                                    "The your current valid existing password ");
                            }
                    } else {
                            throw new AppException("The employee indentity  "
                                            + aEmployee.getEmployeeID() + " does not exits");
                    }
            } catch (AppException appExp) {
                    throw appExp;
            }
    }// /end method

    // This method save all the employees to database file
    private void saveEmployees() throws AppException {
            try {
                    this.db.putFileObjectsContent(EMPLOYEE_FILE, this.employees);
            } catch (AppException err) {
                    throw err;
            }

    }

    public void displayAllEmployees(){

                    this.loadEmployees();
                    this.tableModel.fireTableDataChanged();


    }

    // insertion sorting by name of the employee
    private void sortEmployees() throws AppException {

            // loop the Employees list array object on a try block
            try {
                    // declare the loop control variable
                    int i, j;
                    // start the loop
                    for (i = 1; i < this.employees.size(); i++) {
                            // get the 2nd Employee on the list
                            Employee temEmployee = this.at(i);
                            // get the names
                            String firstname = temEmployee.getFirstName();
                            String lastname = temEmployee.getLastName();
                            String fullname = firstname.concat("" + lastname);
                            // set the J variable to minus of of the current I control value
                            j = i - 1;
                            // declare a variable to hold the previous element values to
                            // compare
                            Employee preEmployee;
                            String preFullname;
                            // compare the strings if position that means fullname is
                            // greater than else negative or on equal it
                            // return 0
                            // While the J value is 0 or greater than 0
                            while (j >= 0) {
                                    // get the previous employee object
                                    preEmployee = this.at(j);
                                    // get his or her fullname
                                    preFullname = preEmployee.getFirstName() + " "
                                                    + preEmployee.getLastName();
                                    // compare if the fulname is greater then the preEmployee
                                    // fullname if yes break the loop
                                    if (fullname.compareToIgnoreCase(preFullname) > 0) {
                                            break;
                                    }
                                    this.employees.set(j + 1, preEmployee);
                                    j--;

                            }
                            this.employees.set(j + 1, temEmployee);
                            // carry of the insertion sorting

                    }
            } catch (AppException err) {
                    throw err;
            }

    }// end sorting
            // This function load all the employee from the base


    public void loadEmployees() {
            try{
                    this.employees = (ArrayList<Employee>) this.db.getFileObjectContent(EMPLOYEE_FILE);
                    this.sortEmployees();

            }
            catch(AppException err)
                    {

                    }
            catch(java.lang.NullPointerException err)
                    {

                    }
    }

    public void findEmployees(String aEmployeeID) throws AppException {
            this.loadEmployees();
            aEmployeeID = aEmployeeID.trim().toUpperCase();
            // check if the value pass is an employee ID
            ArrayList<Employee> temEmployees = new ArrayList<Employee>();
            Employee employee;
            try {
                    if (this.isEmployeeIDExists(aEmployeeID)) {
                            int index = this.getEmployeePositionByID(aEmployeeID);
                            employee = this.at(index);
                            temEmployees.add(employee);

                    } else {
                            temEmployees = this.findEmployeeNames(aEmployeeID);

                    }
                    employees = temEmployees;
                    if (employees.size() <= 0) {
                            this.loadEmployees();
                            throw new AppException(
                                            "Employee is not found with the search criteria Employee Id provided");
                    }
                    this.tableModel.fireTableDataChanged();

            } catch (AppException err) {
                    throw err;
            }

    }// end findEmployee method

    private ArrayList<Employee> findEmployeeNames(String aEmployeeID)
                    throws AppException {
            String search[] = aEmployeeID.split(" ");
            ArrayList<Employee> temEmployees = new ArrayList<Employee>();
            // loop and compare each words
           
                    this.loadEmployees();

                    for (int i = 0; i < search.length; i++) {

                            // search the whole list
                            for (Employee employee : employees) {
                                    // check if the employee fields matched the search words
                                    // positions
                                    if (employee.getLastName().trim().toUpperCase()
                                                    .equals(search[i])
                                                    || employee.getFirstName().trim().toUpperCase()
                                                                    .equals(search[i])
                                                    || employee.getGender().trim().toUpperCase()
                                                                    .equals(search[i])
                                                    || employee.getFirstName().trim().toUpperCase()
                                                                    .equals(aEmployeeID.trim().toUpperCase())
                                                    || employee.getLastName().trim().toUpperCase()
                                                                    .equals(aEmployeeID.trim().toUpperCase())) {

                                            // check if the employee has already added
                                            if (!this.isEmployeeIDExistsTemList(
                                                            employee.getEmployeeID(), temEmployees))
                                                    temEmployees.add(employee);
                                    }
                            }// end for statement inner

                    }// end for
           

            return temEmployees;
    }

    // check if the employee already exist

    private boolean isEmployeeIDExistsTemList(String aEmployeeID,
                    ArrayList<Employee> temEmployees) {

            boolean okay = false;
            for (Employee e : temEmployees) {
                    if (e.getEmployeeID().equals(aEmployeeID)) {
                            okay = true;
                    }
            }// end for

            return okay;
    }

    public boolean isEmployeeAdded() {
            return isOkay;
    }

    public int getRowCount() {
            return this.employees.size();
    }

    public boolean isAdmin(String aEmployeeID) {
            boolean okay = false;
           
                    this.loadAdministrators();
                    // loop the list of administrator ID
                    for (int i = 0; i < this.administratorID.size(); i++) {

                            if (administratorID.get(i).trim().equals(aEmployeeID.trim())) {                                    
                                    okay = true;
                                    break;
                            }
                    }

            return okay;

    }// end isAdministrator

    @SuppressWarnings("unchecked")
    private void loadAdministrators()  {
            try {
                    this.administratorID = (ArrayList<String>) db
                                    .getFileObjectContent(EmployeeList.ADMINISTRATOR_FILE);
            } catch (AppException err) {
                 //just handle it an leave it   
            }
    }

    public boolean isEmployeeUpdated() {
            return isOkay;
    }

    public void assignAdministor(String id) throws AppException {
            this.isOkay = false;
            try {
                    this.administratorID.add(id);
                    this.saveAdministrators();
                    this.isOkay = true;
            } catch (AppException err) {
                    throw err;
            }

    }

    private void saveAdministrators() throws AppException {
            try {
                    db.putFileObjectsContent(EmployeeList.ADMINISTRATOR_FILE,
                                    this.administratorID);
            } catch (AppException err) {
                    throw err;
            }
    }

    public int getAdministratorCount() {
            return administratorID.size();
    }

    public void deleteAdministrator(String employeeID) throws AppException {

            if (this.isAdmin(employeeID)) {
                    this.administratorID.remove(employeeID);
                    this.saveAdministrators();
                    this.loadAdministrators();
            } else {
                    throw new AppException(
                                    "Please contact top administrator for this operation");
            }

    }



    public String getAdministratorAt(int index) {
            try {
                    // get the employee id position and return its name instead of
                    // employee number
                    String employeeNumber = this.administratorID.get(index);
                    Employee employee = this.at(this
                                    .getEmployeePositionByID(employeeNumber));
                    return (employee.getLastName() + " " + employee.getFirstName());
            } catch (AppException err) {
                    // do nothing
            }
            return null;
    }

    public TableModel getTableModel() {

            return tableModel;

    }

    public ListModel getListModel() {
            return new ListModel();
    }

    // inner classes

    private class TableModel extends AbstractTableModel {
            /**
             * 
             */
            private static final long serialVersionUID = 1L;
            // declare all the JTable columns
            private static final int EMPLOYEE_NUMBER = 0;
            private static final int EMPLOYEE_FIRSTNAME = 1;
            private static final int EMPLOYEE_LASTNAME = 2;
            private static final int EMPLOYEE_GENDER = 3;
            private static final int EMPLOYEE_STATUS = 4;

            // get the number of columns to create
            @Override
            public int getColumnCount() {
                    // TODO Auto-generated method stub
                    return 5;
            }

            // get the number of rows to loop on
            @Override
            public int getRowCount() {
                    // TODO Auto-generated method stub
                    return (employees.isEmpty()) ? 1 : employees.size();
            }

            @Override
            public Object getValueAt(int intRow, int intCol) {
                    try {
                            sortEmployees();
                            Employee employee = at(intRow);
                            // check if the item is found else return null
                            if (employee == null) {
                                    return null;
                            }
                            // get the values at each row and out to the view
                            switch (intCol) {
                            case TableModel.EMPLOYEE_FIRSTNAME:
                                    return employee.getFirstName();
                            case TableModel.EMPLOYEE_LASTNAME:
                                    return employee.getLastName();
                            case TableModel.EMPLOYEE_GENDER:
                                    return employee.getGender();
                            case TableModel.EMPLOYEE_NUMBER:
                                    return employee.getEmployeeID();
                            case TableModel.EMPLOYEE_STATUS:
                                    return employee.getStatus();
                            default:
                                    return null;
                            }
                    } catch (AppException err) {
                            // do nothing
                    }
                    return null;
            }

    @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return columnIndex == 4;
            }

    @Override
            public void setValueAt(Object value, int rowIndex, int col) {
                    try {
                            Employee employee = at(rowIndex);

                            switch (col) {
                            case TableModel.EMPLOYEE_STATUS:
                                    employee.setStatus((Boolean) value);
                                    break;
                            default:
                                    break;
                            }
                            this.fireTableCellUpdated(rowIndex, col);
                            saveEmployees();
                    } catch (AppException err) {
                    }

            }

            // setting the column name of the JTable view through its model
    @Override
            public String getColumnName(int col) {
                    switch (col) {
                    case TableModel.EMPLOYEE_NUMBER:
                            return "Employee Number";
                    case TableModel.EMPLOYEE_FIRSTNAME:
                            return "First Name";
                    case TableModel.EMPLOYEE_LASTNAME:
                            return "Last Name";
                    case TableModel.EMPLOYEE_GENDER:
                            return "Gender";
                    case TableModel.EMPLOYEE_STATUS:
                            return "Status";
                    default:
                            return null;
                    }

            }

            // This method return the column type which make the editor to know the
            // type of value that it will accept

            @Override
            public Class<?> getColumnClass(int col) {
                    switch (col) {
                    case TableModel.EMPLOYEE_NUMBER:
                            return String.class;
                    case TableModel.EMPLOYEE_FIRSTNAME:
                            return String.class;
                    case TableModel.EMPLOYEE_LASTNAME:
                            return String.class;
                    case TableModel.EMPLOYEE_GENDER:
                            return String.class;
                    case TableModel.EMPLOYEE_STATUS:
                            return Boolean.class;
                    default:
                            return null;
                    }

            }

    }// end EmployeeList Class

    // This list model class
    private class ListModel extends AbstractListModel<String> {

            private static final long serialVersionUID = 1L;

            @Override
            public String getElementAt(int index) {
                    if (administratorID.isEmpty())
                            return "no administrator found";
                    return administratorID.get(index);
                    // return getAdministratorAt(index);
            }

            @Override
            public int getSize() {
                    // TODO Auto-generated method stub
                    return (getAdministratorCount() != 0) ? getAdministratorCount() : 1;
            }

    }// end listmodel inner class

}// end main class
