/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author hacker
 */
import java.util.ArrayList;
import java.util.Date;

import javax.swing.table.AbstractTableModel;
import includes.*;

//This class manages the employee cars , keep track of the car borrowed and the car return my employee

public class CarHiringModel implements Model {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	ArrayList<HireCar> hirecars;
	EmployeeList employees;
	Fleet fleet;
	String employeeID;
	TableModel tableModel;
	static final private String HIRE_CARS_TBL_FILE = "borrowcars.ob";
	// create an IO stream object
	IOStream db;

	public CarHiringModel() {
		
		init("");
	}

	public CarHiringModel(String aEmployeeID) {

		init(aEmployeeID);
	}

	private void init(String aEmployeeID) {
		tableModel = new TableModel(this);
		try {
			hirecars = new ArrayList<HireCar>();
			employees = new EmployeeList();
			fleet = new Fleet();
			employeeID = aEmployeeID;
			db = new IOStream();
		} catch (AppException err) {

		}
	}
  public void filterByCars(String employeeID)throws AppException
  {
	  this.fleet.loadCars();
	  this.employees.loadEmployees();
	  employeeID=employeeID.trim().toUpperCase();
	  ArrayList<HireCar>temHireCars=new ArrayList<HireCar>();
	  //check if there is record of hire cars
	  this.loadHireCars();
	  if(this.hirecars.size()>=0)
	  {
		 
		  //if there is a borrow car or cars then
		try
		{
		  for(int i=0;i<this.hirecars.size();i++)
		  {
			  
			  //get the hire car and match to see if it is the current user
			  HireCar hireCar=this.at(i);
			  String employeeIDDB=hireCar.getEmployeeID().trim().toLowerCase();
			  employeeID=employeeID.trim().toLowerCase();			  
			  //System.out.println(employeeIDDB +" = "+employeeID);			  
			  if(employeeIDDB.equals(employeeID))
			  {
				  temHireCars.add(hireCar);
			  }
			  
		  }
		  
		}//end try block
		catch(AppException err)
		{
			throw err;
		}
		  
	  }	  
	  this.hirecars = temHireCars;
	  this.tableModel.fireTableDataChanged();
	  this.tableModel.fireTableStructureChanged();
	
  }
	public void borrowCar(String carRegistrationNumber, String staffID)
			throws AppException {
		this.employees.loadEmployees();
		this.fleet.loadCars();
		if (employeeID.trim().equals(""))
			employeeID = staffID;
		// Check if the employee exit
		if (!employees.isEmployeeIDExists(employeeID.trim().toUpperCase()))
			throw new AppException(
					"Oops this employee number didnot exists or did not have the privillages to carryout this operation");
		// check if the car has be borrow already
		if (fleet.isCarBorrowedAlready(carRegistrationNumber)) {
			throw new AppException(
					"The car with the registration is already resereved by another staff, please! choose another car");
		}
		// If every went okay then create a node of hirecar and save it
		try {
			HireCar hireCar = new HireCar();
			hireCar.setEmployeeID(staffID);
			hireCar.setCarRegistrationNumber(carRegistrationNumber);
			hireCar.setDate(new Date());
			// add the hireCar to the list of hire car
			this.valiadated();
			this.hirecars.add(hireCar);			
			this.saveHireCars();
			this.fleet.updateCarStatus(carRegistrationNumber,true);
			this.tableModel.fireTableDataChanged();
			this.tableModel.fireTableStructureChanged();
		} catch (AppException err) {
			throw err;
		}
	}// end borrow method

	private void saveHireCars() throws AppException {

		try {
			db.putFileObjectsContent(HIRE_CARS_TBL_FILE, this.hirecars);
			this.loadHireCars();
		} catch (AppException err) {
			throw err;
		}

	}



	public void returnCar(String carRegistrationNumber, String staffID)
			throws AppException {
		if (this.employeeID.equals("")) {
			this.employeeID = staffID;
		}
		employees.loadEmployees();
		fleet.loadCars();
		
		if (!employees.isEmployeeIDExists(this.employeeID.trim().toUpperCase()))
			throw new AppException(
					"Employee number did not exit please re-login");
		
		// else if everything goes well then
		this.removeHireCar(carRegistrationNumber, this.employeeID.trim().toUpperCase());
		
		

	}// end method borrow car

	// This method read the cars to hire from the database
	@SuppressWarnings("unchecked")
	public void loadHireCars()  {
		try {
			this.hirecars = (ArrayList<HireCar>) db
					.getFileObjectContent(CarHiringModel.HIRE_CARS_TBL_FILE);
		} catch (AppException err) {
			
		}
	}

	// This method removeHireCar from registration number
	private void removeHireCar(String carRegistrationNumber, String employeeID)
			throws AppException {

		try {
			
			this.loadHireCars();
			// search the car list if the match meets delete the car and resave
			
			for (int i = 0; i < this.hirecars.size(); i++) {
				// get the hire car details
				
				HireCar hireCar = this.at(i);
				// match the values if they are same with the car details
				if (hireCar.getEmployeeID().trim().toUpperCase().equals(
						employeeID.trim().toUpperCase())
						&& hireCar.getCarRegistrationNumber().trim().toUpperCase().equals(
								carRegistrationNumber.trim().toUpperCase())) {
					// remove the car at the position
					System.out.println("Position "+this.hirecars.size());
					this.hirecars.remove(i);
					this.saveHireCars();
					this.fleet.updateCarStatus(carRegistrationNumber, false);		
					this.fleet.saveCars();
					this.tableModel.fireTableDataChanged();
					this.tableModel.fireTableStructureChanged();
					
				}// end if inner

			}// end for statment

		}// end try block
		catch (AppException err) {
			throw err;
		}// end catch block

	}
//The method return the table model object
	public TableModel getTableModel() {
		return tableModel;
	}

	//The method get the car at that location index provided
	public HireCar at(int index) throws AppException {
		//check if the index is valid
		if (index < 0 || index >= this.hirecars.size()) {
			throw new AppException("at() method index out of range");
		}
		return this.hirecars.get(index);
	}

	@Override
	public boolean valiadated() throws AppException {
		// TODO Auto-generated method stub
		return false;
	}

	// inner class
	private class TableModel extends AbstractTableModel {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		CarHiringModel parent;

		private static final int CAR_REGISTRATION_NUMBER = 0;
		private static final int EMPLOYEE_FIRSTNAME = 1;
		private static final int EMPLOYEE_LASTNAME = 2;
		private static final int CAR_MODEL = 3;
		private static final int CAR_MILEAGE = 4;
		private static final int EMPLOYEEID = 5;
		private static final int CAR_HIRED_DATE = 6;

		protected TableModel(CarHiringModel aParent) {
			this.parent = aParent;
		}

		@Override
		public int getColumnCount() {

			return 7;
		}

		@Override
		public int getRowCount() {

			return (!hirecars.isEmpty()) ? hirecars.size() : 1;
		}

		/*
		 * public void setValueAt(Object value,int row,int col) {
		 * 
		 * }
		 */

		@Override
		public Class<?> getColumnClass(int col) {
			switch (col) {
			case TableModel.CAR_HIRED_DATE:
				return String.class;
			case TableModel.EMPLOYEE_FIRSTNAME:
				return String.class;
			case TableModel.EMPLOYEE_LASTNAME:
				return String.class;
			case TableModel.CAR_MODEL:
				return String.class;
			case TableModel.CAR_MILEAGE:
				return String.class;
			case TableModel.EMPLOYEEID:
				return String.class;
			case TableModel.CAR_REGISTRATION_NUMBER:
				return String.class;
			default:
				return null;
			}

		}

		// setting the column name of the JTable view through its model
        @Override
		public String getColumnName(int col) {
			switch (col) {
			case TableModel.CAR_REGISTRATION_NUMBER:
				return "Car Registration";
			case TableModel.EMPLOYEE_FIRSTNAME:
				return "First Name";
			case TableModel.EMPLOYEE_LASTNAME:
				return "Last Name";
			case TableModel.CAR_MODEL:
				return "Car Model";
			case TableModel.CAR_MILEAGE:
				return "Car Mileage";
			case TableModel.EMPLOYEEID:
				return "Employee Number";
			case TableModel.CAR_HIRED_DATE:
				return "Hire Date";
			default:
				return null;
			}

		}

		@Override
		public Object getValueAt(int row, int col) {

			try {

				HireCar hireCar = this.parent.at(row);
				if(hireCar==null)
					return null;
				//get the employee that borrow this car
				int indexEmployee=this.parent.employees.getEmployeePositionByID(hireCar.getEmployeeID());
				Employee employee=this.parent.employees.at(indexEmployee);
				
				//get the car details
				int indexCar=this.parent.fleet.getCarPositionByRegistrationNumber(hireCar.getCarRegistrationNumber());
				Car car=this.parent.fleet.at(indexCar);

				// get the value at the column positions
				switch (col) {
				case CAR_REGISTRATION_NUMBER: {
						return car.getRegistrationNumber();
				}
				case EMPLOYEE_FIRSTNAME: {
					return employee.getFirstName();
				}
				case EMPLOYEE_LASTNAME: {
					return employee.getLastName();
				}
				case CAR_MILEAGE: {
				return car.getMileage();
				}
				case CAR_MODEL: {
					return car.getModel();
				}
				case CAR_HIRED_DATE: {
				  return hireCar.getDate();
				}
				case EMPLOYEEID: {
					return employee.getEmployeeID();
				}
				default:
					return null;

				}

			} catch (AppException err) {

			}
			return null;

		}// end method

	}// end inner class

}
