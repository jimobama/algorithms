<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Member
 *
 * @author jimobama
 */
class Member extends Controller {

    protected $model;

    public function __construct() {
        parent::__construct();

        $this->page = "Customer/index";
        require_once("model/Account.php");
        $this->model = new UserAccount();
    }

    public function validated() {
        
    }

//put your code here

    public function xhsLogOut() {
        Session::set(UNIVERSAL_REQUEST_ERROR, "Thanks for your visiting and your time spend");
        Session::delete(LOGIN);
        Session::delete(ACTIVE_SHIPPING_ADDRESS);
        Session::delete(LOGIN_EMAIL);
        Session::delete(CURRENT_ORDER_NUMBER);
        Session::delete(IS_ADMINISTRATOR);
       @header("Location:" . URL);
        exit();
    }

    final function xhsAssignAdministrator() {
        $customerID = isset($_REQUEST["id"]) ? $_REQUEST["id"] : null;


        try {
            if ($this->model->isCustomerIDExists($customerID) >= 0) {

                $customer = $this->model->getCustomerById($customerID);
                if ($customer == null) {
                    $customer = new TCustomer();
                }

                //now delete the customer                
                $this->model->assignAdministrator($customer->getEmail());
                if ($this->model->isAdded()) {
                    $fullname = $customer->getLastName() . " " . $customer->getFirstName();
                    throw new WebException("$fullname has be assigned the role of an administrator by you", 0, null);
                } else {
                    echo $this->model->getError();
                }
            }//end if
        } catch (WebException $err) {
            Session::set(UNIVERSAL_REQUEST_ERROR, $err->getMessage());
        }

        @header("Location:" . URL . "?url=member");
        exit();
    }

    final function xhsRemoveAdministrator() {
        $customerID = isset($_REQUEST["id"]) ? $_REQUEST["id"] : null;
        try {
            if ($this->model->isCustomerIDExists($customerID) >= 0) {

                $customer = $this->model->getCustomerById($customerID);
                if ($customer == null) {
                    $customer = new TCustomer();
                }

                //now delete the customer                
                $this->model->deleteAdmin($customer->getEmail());
                if ($this->model->isDeleted()) {
                    $fullname = $customer->getLastName() . " " . $customer->getFirstName();
                    throw new WebException("$fullname has be removed from being an administrator", 0, null);
                }
            }//end if
        } catch (WebException $err) {
            Session::set(UNIVERSAL_REQUEST_ERROR, $err->getMessage());
        }

       @header("Location:" . URL . "?url=member");
        exit();
    }

    public function xhsStockPageSwitch() {
        $customer = $this->model->getCustomer(Session::get(LOGIN_EMAIL));
        if (Session::get(LOGIN) && !method_exists($customer, "getLevel")) {
            $page = isset($_REQUEST["page"]) ? $_REQUEST["page"] : null;

            switch ($page) {
                case "addItem":
                    Session::set("STOCK_REQUEST_PAGE", "addStock.html.php");
                    break;
                case "displayItems":
                    Session::set("STOCK_REQUEST_PAGE", "displayItems.html.php");
                    break;
                case "findItem":
                    Session::set("STOCK_REQUEST_PAGE", "findItem.html.php");
                    break;
                case "addcategory":
                    Session::set("STOCK_REQUEST_PAGE", "addcategory.html.php");
                    break;
                case "user":
                    Session::set("STOCK_REQUEST_PAGE", "users.html.php");

                default:
            }
        }

        @header("Location:" . URL . "?url=member");
        exit();
    }

//end method
    //add member shipping address

    final function xhsAddShippingAddress() {
        Session::set(PREVIOUS_REQUEST_URL, "cart/xhsAddShippingAddress");
        //For member only who have login

        if (isset($_REQUEST["btnAddShipAddress"]) && $_SERVER["REQUEST_METHOD"]) {
            $email = Session::get(LOGIN_EMAIL);
            $recieverName = isset($_REQUEST['txtSFullname']) ? $_REQUEST['txtSFullname'] : null;
            $country = isset($_REQUEST['txtSCountry']) ? $_REQUEST['txtSCountry'] : null;
            $state = isset($_REQUEST['txtSState']) ? $_REQUEST['txtSState'] : null;
            $county = isset($_REQUEST['txtPSTown']) ? $_REQUEST['txtPSTown'] : null;
            $address1 = isset($_REQUEST['txtSAddress1']) ? $_REQUEST['txtSAddress1'] : null;
            $address2 = isset($_REQUEST['txtSAddress2']) ? $_REQUEST['txtSAddress2'] : null;
            $postcode = isset($_REQUEST['txtSPostcode']) ? $_REQUEST['txtSPostcode'] : null;

            //Sticking form start here

            Session::set("SHIP_FULLNAME", $recieverName);
            Session::set("SHIP_COUNTRY", $country);
            Session::set("SHIP_STATE", $state);
            Session::set("SHIP_TOWN", $county);
            Session::set("SHIP_ADDRESS1", $address1);
            Session::set("SHIP_ADDRESS2", $address2);
            Session::set("SHIP_POSTCODE", $postcode);
            if (Session::get(LOGIN) != true) {
               @header("Location:" . URL . "?url=guest");
                exit();
            }
            //let add the address nw

            if ($this->model->isCustomerEmail($email)) {
                //create a new address  
                // the class generate an exception so we have to handle it
                try {

                    $member = $this->model->getCustomer($email);
                    $address = new TAddress();
                    $id = (Integer) (microtime() * time()) . "" . $this->model->getAddressCount($member->getClientID());
                    //the address deatils
                    $address->setClientID($member->getClientID());
                    $address->setAddressID($id);
                    $address->setFullName($recieverName);

                    $address->setAddress1($address1);
                    $address->setAddress2($address2);
                    $address->setPostcode($postcode);
                    $address->setCountry($country);
                    $address->setState($state);
                    $address->setCounty($county);
                    if ($this->model->isAddressInfoExists($address)) {
                        Session::set(UNIVERSAL_REQUEST_ERROR, "The reciever's name [$recieverName] with this postcode[$postcode] number already exit in your address list!");
                    } else {//else carry out the operations
                        $this->model->addAddress($address);
                        if ($this->model->isAdded()) {
                            Session::set("ADD_ADDRESS_ERROR", explode(":", "address_success:Your address has be successfully added"));
                            //unset the Sessions
                            Session::delete("SHIP_FULLNAME");
                            Session::delete("SHIP_COUNTRY");
                            Session::delete("SHIP_STATE");
                            Session::delete("SHIP_TOWN");
                            Session::delete("SHIP_ADDRESS1");
                            Session::delete("SHIP_ADDRESS2");
                            Session::delete("SHIP_POSTCODE");
                        } else {
                            Session::set("ADD_ADDRESS_ERROR", explode(":", $this->getError()));
                        }
                    }
                } catch (WebException $err) {
                    Session::set("ADD_ADDRESS_ERROR", explode(":", $err->getMessage()));
                }
            }//end if statement
        }

        //redirect
        @header("Location:" . URL . "?url=cart");
        exit();
    }

//end shipping address

    final function xhsSelectAddressForOrder() {
        $url = "cart";
        $addressID = isset($_REQUEST["add"]) ? $_REQUEST["add"] : null;
        if ($addressID != null) {
            if ($this->model->isAddressExists($addressID)) {
                //selected Address;
                //$url="cart/&selected=$addressID";
                Session::set(ACTIVE_SHIPPING_ADDRESS, "$addressID");
            }
        }//end if

        @header("Location:" . URL . "?url=$url");
        exit();
    }

//end function

    final function xhsDeleteAddressForOrder() {

        if (isset($_REQUEST["add"])) {
            $addressID = isset($_REQUEST["add"]) ? $_REQUEST["add"] : null;

            if ($this->model->isAddressExists($addressID)) {
                $address = $this->model->getAddress($addressID);
                $clientID = $address->getClientID();
                $this->model->deleteCustomerAddress($clientID, $addressID);
            }
        }

        @header("Location:" . URL . "?url=cart");
        exit();
    }

}

//end class
?>
