<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Stock
 *
 * @author jimobama
 */
class Stock extends Controller {

    //put your code here
    protected $model;

    function __construct() {
        parent::__construct();
        $this->page = "Customer/index";
        require_once("model/Stock.php");
        $this->model = new Stock_Model();
    }

    //This function add category to the category list
    final public function xhsAddItem() {
      
        //get Image informations
            $image_name = isset($_FILES["itemImage"]["name"]) ? $_FILES["itemImage"]["name"] : null;
            $image_type = isset($_FILES["itemImage"]["name"]) ? $_FILES["itemImage"]["type"] : null;
            $image_size = isset($_FILES["itemImage"]["name"]) ? $_FILES["itemImage"]["size"] : null;
            $tem_name = isset($_FILES["itemImage"]["tmp_name"]) ? $_FILES["itemImage"]["tmp_name"] : null;
            //get Other details
            $itemname = isset($_REQUEST["txtItemName"]) ? $_REQUEST["txtItemName"] : null;
            $itemPrice = isset($_REQUEST["txtItemPrice"]) ? $_REQUEST["txtItemPrice"] : null;
            $itemStockNumber = isset($_REQUEST["txtItemStockNumber"]) ? $_REQUEST["txtItemStockNumber"] : null;
            $itemDesc = isset($_REQUEST["txtItemDesc"]) ? $_REQUEST["txtItemDesc"] : null;
            $itemCategory = isset($_REQUEST["itemCategory"]) ? $_REQUEST["itemCategory"] : null;
            //sticking form
            Session::set("ITEM_NAME", $itemname);
            Session::set("ITEM_PRICE", $itemPrice);
            Session::set("ITEM_STOCKNUMBER", $itemStockNumber);
            Session::set("ITEM_DESC", $itemDesc);
            Session::set(CURRENT_CATEGORY_TO_EDIT,$itemCategory);
        
        //check if the button is press
        if (isset($_REQUEST["btnAddNewItem"]) && $_SERVER["REQUEST_METHOD"] == "POST") {

            
            //check if item name exist already
            if (trim($image_name) != "") {
                if (!$this->model->isItemNameExists($itemname)) {
                    if ($image_type == "image/jpeg") {
                        if ($image_size <= "1600000") {
                            $id = (Integer) ((microtime() * time()) . $this->model->getItemsCount());
                            $filename = $id . $image_name;
                            if (uploadImages($filename, $tem_name, ITEM_IMAGES)) {
                                try {
                                    $item = new Item();
                                    $item->setCategoryNumber($itemCategory);
                                    $item->set($id, $itemname, floatval($itemPrice), floatval($itemPrice), $filename, (int) $itemStockNumber, (int) $itemStockNumber);
                                    $item->setDescription($itemDesc);
                                    Session::set("UPLOAD_ITEM_IMAGE", ITEM_IMAGES . $filename);
                                    $this->model->addItem($item);
                                    if ($this->model->isAdded()) {
                                        Session::set("ADD_ITEM_ERROR", explode(":", "add_success: The item has be successfully stocked"));
                                    } else {
                                        unlink(ITEM_IMAGES . $filename);
                                        Session::set("ADD_ITEM_ERROR", explode(":", $this->model->getError()));
                                    }
                                } catch (WebException $err) {
                                    unlink(ITEM_IMAGES . $filename);
                                    Session::set("ADD_ITEM_ERROR", explode(":", $err->getMessage()));
                                }
                            }
                        }
                    }
                }//end if exist
                else {
                    Session::set("ADD_ITEM_ERROR", explode(":", "item_name: The item already exist in the same category"));
                }
            } else {
                Session::set("ADD_ITEM_ERROR", explode(":", "item_image: Please add an Item image"));
            }//end if image is empty
            // print_r(Session::get("ADD_ITEM_ERROR"));
        }//end if statement press
        //
       else if(isset($_REQUEST["btnUpdateItem"]) && $_SERVER["REQUEST_METHOD"] == "POST") 
       {
           $itemNumber=isset($_REQUEST["txtItemNumberToEdit"])?$_REQUEST["txtItemNumberToEdit"]:null;
           Session::set(CURRENT_ITEM_TO_EDIT,$itemNumber);
           if($image_name!=null && trim($image_name)!="")
           {
           Session::set("ADD_ITEM_ERROR", explode(":", "item_image: Item image cannot be change please!"));                  
           }//end image checked
         
          
           if($this->model->isItemNumberExists($itemNumber))
           {
               $item=$this->model->find($itemNumber,Item::BYNUMBER);
               //check to make such is item object
               if($item==null)
                   $item=new Item();
             //set item details
               try
               {
              
               $item->setName($itemname);
               $item->setCurrentPrice(floatval($itemPrice));
               $item->setStockNumber(intval($itemStockNumber));
               $item->setDescription($itemDesc );   
               $item->setCategoryNumber($itemCategory);
                           
               $this->model->insertItem($item);
               if($this->model->isSaved())
               {
                   
                   throw new WebException("update_success:Item has be successfully updated",0,null);
               }
              else
              {
                throw new WebException($this->model->getError(),0,null);  
              }
                 
               }catch(WebException $err)
               {
                 Session::set("ADD_ITEM_ERROR",explode(":",$err->getMessage())) ;
               }
               
               
           }
          
       }
        //print_r(Session::get("ADD_ITEM_ERROR"));
        header("Location:" . URL . "/?url=member");
        exit();
    }    //end method

    final public function xhsDisplayItems() {
        $catID = isset($_REQUEST["itemCategoryListDisplay"]) ? $_REQUEST["itemCategoryListDisplay"] : null;
        try {
            if ($catID != null) {//check if there is post value
                //check if the category number exist , if exist return the position  
                if ($this->model->isCategoryIDExists($catID) >= 0) {
                    Session::set(CURRENT_CATEGORY_TO_DISPLAY, $catID);
                } else {
                    throw new WebException("error:Select item category to display please!", 0, null);
                }
            } else {
                throw new WebException("error:Select item category to display please!", 0, null);
            }
        } catch (WebException $err) {
            Session::set('CAT_DISPLAY_ERROR', explode(":",$err->getMessage()));
        }

        header("Location:" . URL . "?url=member");
        exit();
    }

    public function xhsAddCategory() {
        $categoryName = isset($_REQUEST["txtcategoryname"]) ? $_REQUEST["txtcategoryname"] : null;
        $keywords = isset($_REQUEST["txtacategorykeyords"]) ? $_REQUEST["txtacategorykeyords"] : null;

        if (isset($_REQUEST["btnAddCategory"]) && $_SERVER["REQUEST_METHOD"] == "POST") {

            //sticking form

            Session::set("insert_category_name", $categoryName);
            Session::set("insert_category_keywords", $keywords);

            try {
                $number = (Integer) (microtime() * time()) . "" . $this->model->getCategoryCounts();
                $category = new ItemCategory();

                $category->setNumber($number);
                $category->setName($categoryName);
                $category->setKeywords(strtolower($keywords));


                $this->model->addCategory($category);
                if ($this->model->isAdded()) {
                    Session::set("ADD_CATEGORY_ITEM", explode(":", "category_successful: Category $categoryName has be successfully added"));
                } else {
                    Session::set("ADD_CATEGORY_ITEM", explode(":", $this->model->getError()));
                }
            } catch (WebException $err) {
                Session::set("ADD_CATEGORY_ITEM", explode(":", $err->getMessage()));
            }
        }//
        else if (isset($_REQUEST["btnUpdateCategory"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
            $categoryNumber = isset($_REQUEST["txtUpdateCategoryID"]) ? $_REQUEST["txtUpdateCategoryID"] : null;

            if ($this->model->isCategoryIDExists($categoryNumber) >= 0) {
                try {
                    $category = $this->model->getCategory($categoryNumber);
                    $category->setName($categoryName);
                    $category->setKeywords(strtolower($keywords));
                    $this->model->updateCategory($category);
                    if ($this->model->isSaved()) {
                        Session::set("ADD_CATEGORY_ITEM", explode(":", "saved: Category details successfully updated"));
                    } else {
                        Session::set("ADD_CATEGORY_ITEM", explode(":", $this->model->getError()));
                    }
                } catch (WebException $err) {
                    Session::set("ADD_CATEGORY_ITEM", explode(":", $err->getMessage()));
                }
            }
        }//end else if statement




        header("Location:" . URL . "?url=member");
        exit();
    }

    //end method
    final public function xhsEditItem()
    {
    $itemNumber=isset($_REQUEST["itemNumber"])?$_REQUEST["itemNumber"]:null;
    $url=URL."?url=member";
    if($this->model->isItemNumberExists($itemNumber))
       {
        Session::set(CURRENT_ITEM_TO_EDIT,$itemNumber); 
        $url=URL."?url=member/xhsStockPageSwitch/&page=addItem";
      }      
      //Button updated press to edit the item
    header("Location:".$url);
    exit();
    }//end function
    
    final function xhsDeleteItem()
    {
        
        $itemNumber=isset($_REQUEST["itemNumber"])?$_REQUEST["itemNumber"]:null;
        if($this->model->isItemNumberExists($itemNumber))
        {
            $this->model->deleteItem($itemNumber);
            Session::set("DELETE_REPORT",explode(":","error:Item successfully deleted"));
        }
        header("Location:" . URL . "?url=member");
        exit();
        
    }//end function

    final public function xhsDeleteCategory() {
        $catNumber = isset($_REQUEST["cat"]) ? $_REQUEST["cat"] : null;
        //place the code in atry block
        try {
            if ($this->model->isCategoryIDExists($catNumber) >= 0) {
                //get items in category
                $counts = $this->model->getItemsInCategoryCount($catNumber);
                if ($counts > 0) {
                    //don't delete it just leave the item and remove from user not to see again
                    Session::set("CATEGORY_DELETE", explode(":", "delete_err:This category cannot be delete, because it has $counts item(s) stock in it"));
                } else {
                    //delete the category
                    $this->model->deleteCategory($catNumber);
                    if ($this->model->isDeleted()) {
                        throw new WebException("success:Item successfully deleted", 0, null);
                    } else {
                        throw new WebException($this->getError(), 0, null);
                    }
                }
            }
        } catch (WebException $err) {
            Session::set("CATEGORY_DELETE", explode(":", $err->getMessage()));
        }
        header("Location:" . URL . "?url=member");
        exit();
    }

    //end function

    final public function xhsEditCategory() {
        $catNumber = isset($_REQUEST["cat"]) ? $_REQUEST["cat"] : null;
        try {
            if ($this->model->isCategoryIDExists($catNumber) >= 0) {
                Session::set(CURRENT_CATEGORY_TO_EDIT, $catNumber);
            }
        } catch (WebException $err) {
            Session::set("EDIT_CATEGORY", $err->getMessage());
        }


        header("Location:" . URL . "?url=member");
        exit();
    }

    public function validated() {
        
    }

}

?>
