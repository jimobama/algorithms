<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Index
 *
 * @author jimobama
 */
class Index  extends Controller{
    //put your code here
    
    function __construct() {
        parent::__construct();
       $this->page="Index/index";
      
    }

    public function validated() {
        
    }
    
  
}

?>
