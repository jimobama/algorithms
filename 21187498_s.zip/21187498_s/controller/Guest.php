<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Description of signup
 *
 * @author jimobama
 */
class Guest extends Controller {

    protected $model;
    
    public function __construct() {
        parent::__construct();
        //if the guest already login , redirect him to Customer sections to have full access
        
       if(Session::get(LOGIN)==true)
         {
           header("Location:".URL);
         }
        require_once("model/Account.php");
        $this->page = "Customer/index";
        $this->model = new UserAccount();
        $this->view->setModel($this->model);
       
    }

//This controller method login the user into session
    function xhsLogIn() {//this function login the user into the user access area
        if (($_SERVER["REQUEST_METHOD"] == 'POST') && isset($_REQUEST["btnLogin"])) {
            $email = isset($_REQUEST["txtLEmail"]) ? $_REQUEST["txtLEmail"] : null;
            $password = isset($_REQUEST["txtLPassword"]) ? $_REQUEST["txtLPassword"] : null;
            //put the code in a try block since the model functions generate an exceptions
           
            try {
           
            
                if ($this->model->loginCustomer($email,$password)) {
                     
                    //set the login flag                   
                    Session::set(LOGIN_EMAIL, $email);
                    Session::set(LOGIN, true);  
                    //direct the user to the member area
                    $requestURL= (Session::get(PREVIOUS_REQUEST_URL)!="")?Session::get(PREVIOUS_REQUEST_URL):null;
                    if($requestURL==null)
                       $requestURL="member";     
                    
                     //check if the user is an administrator
                    if($this->model->isAdministrator($email))
                       {
                        Session::set(IS_ADMINISTRATOR,true);
                       }
                       header("Location:" . URL . "?url=".$requestURL);
                       exit();                   
                   
                } else {//set the error session 
                     
                    Session::set(CLIENT_ERROR, explode(":", $this->model->getError()));
                }
            } catch (WebException $err) {
                Session::set(CLIENT_ERROR, explode(":", $err->getMessage()));
            }
            
            
           //$this->view->setModel($this->model);
           header("Location:" . URL . "?url=guest");
           exit();
        }
    }

//This function call the model class to create a new account for client
    public function xhsCreateAccount() {
        //Check if the button Create account is pressed
        if (isset($_REQUEST["btnCreateAccount"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
            //get all the html field values to PHP variable
            $terms = isset($_REQUEST["terms"]) ? $_REQUEST["terms"] : null; //check if the checkbox for term is post
            $email = $_REQUEST["txtCEmail"];
            $firstname = $_REQUEST["txtCFirstName"];
            $lastname = $_REQUEST["txtCLastName"];
            $phone = $_REQUEST["txtCMobilePhone"];
            $password = $_REQUEST["txtCPassword"];
            $r_password = $_REQUEST["txtCRPassword"];

            //Session The variable by the Session class wrapper
            Session::set(V_EMAIL, $email);
            Session::set("v_firstname", $firstname);
            Session::set("v_phone", $phone);
            Session::set("v_lastname", $lastname);
            Session::set("v_term", true);
            //check if the term check box check else return
            if (!isset($terms) || $terms == null) {
                //Set error if the check box for terms is not checked or post
                Session::set(CLIENT_ERROR, explode(":", "term:Please you are required to read and agreed to the them and conditions before you can proceed"));
            } else {

                try {
                    //create the customer object
                    $customer = new TCustomer();
                    $clientID = (Integer) (microtime() * time()) . "" . $this->model->getCustomerCounts();
                    $customer->set($clientID, $firstname, $lastname, $email, $phone);
                    $customer->setPassword($password);
                    if ($password == $r_password) {
                        $this->model->add($customer); //add the customer details
                        //check if it successfully added
                        if ($this->model->isAdded()) {
                            Session::set(CLIENT_ERROR, explode(":", "create_success:Your account has be successfuly created"));
                        } else {
                            Session::set(CLIENT_ERROR, explode(":", $this->model->getError()));
                        }
                    } else {
                        Session::set(CLIENT_ERROR, explode(":", "mismatched: Password did not macthed"));
                    }
                } catch (WebException $err) {
                    Session::set(CLIENT_ERROR, explode(":", $err->getMessage()));
                }
            }//end checkbox else
            //navigate back
            header("Location:" . URL . "?url=guest");
            exit();
        }
    }

    
//this function switch off and on of the Registration and login panel
    public function xhsSwitch() {
        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : null;
        echo $page;
        if ($page != null) {
            if ($page == "signin") {
                Session::set(CLIENT_SWITCH, true);
            } else {
                Session::set(CLIENT_SWITCH, false);
            }
        } else {//end if statement
            if (Session::get(CLIENT_SWITCH) == true) {
                //switch the login section on
                Session::set(CLIENT_SWITCH, false);
            } else {
                Session::set(CLIENT_SWITCH, true);
            }
        }

        header("Location:" . URL . "?url=guest");
        exit();
    }

    public function validated() {
        
    }

    //A function that will log the user off and re-direct him/her to the home page
}

?>
