<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Cart
 *
 * @author jimobama
 */
class Cart extends Controller {

    protected $model;

    public function __construct() {
        parent::__construct();
        $this->page = "Cart/index";
        require_once("model/Stock.php");
        $this->model = new Stock_Model();
    }

    final public function xhsCancelOrder() {
        $orderNumber = isset($_REQUEST["orderID"]) ? $_REQUEST["orderID"] : null;
        require_once("model/Account.php");
        $account = new UserAccount();

        if ($account->isOrderNumberExists($orderNumber)) {
            $account->deleteOrder($orderNumber);
            if ($account->isDeleted()) {
                Session::set(UNIVERSAL_REQUEST_ERROR, "Your Order has be successfully cancelled and removed");
            }
        }

        header("Location:" . URL . "?url=cart");
        exit();
    }

    final public function xhsDeleteAllItemsFromBasket() {
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());
        if ($basket->count() > 0) {
            Session::delete(CART_BASKET);
            $this->deleteCookies();
            Session::set(UNIVERSAL_REQUEST_ERROR, "All Items has be successfully remove from your trolley");
        } else {
            Session::set(UNIVERSAL_REQUEST_ERROR, "There is nothing to remove from you trolley");
        }
        header("Location:" . URL . "?url=cart");
        exit();
    }

    final public function xhsOrderItemsFromBasket() {
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());
        if ($basket->count() <= 0) {
            Session::delete(ACTIVE_SHIPPING_ADDRESS);
            Session::set(UNIVERSAL_REQUEST_ERROR, "There is not item in your trolley, please add item to your trolley before you can check out.");
        } else {
            Session::set("CART_SWITCH_PANEL", explode(":", "OrderItemsFromBasket.html.php:step1"));
        }
        header("Location:" . URL . "?url=cart");
        exit();
    }

    final public function xhsDisplayItemsCategory() {
        $catNumber = isset($_REQUEST["cat"]) ? $_REQUEST["cat"] : null;
        //check if the cart number exist
        if ($this->model->isCategoryIDExists($catNumber) >= 0) {
            //get the cart number nly to display informations
            Session::set("CART_SWITCH_PANEL", explode(":", "displayCategoryItemsCart.html.php:$catNumber"));
        }

        header("Location:" . URL . "?url=cart");
        exit();
    }

    final public function xhsdisplayItemProfile() {
        $itemNumber = isset($_REQUEST["item"]) ? $_REQUEST["item"] : null;
        //check if the cart number exist
        if ($this->model->isItemNumberExists($itemNumber)) {
            //get the cart number nly to display informations
            Session::set("CART_SWITCH_PANEL", explode(":", "displayCategoryItemsCart.html.php:$itemNumber"));
        }

        header("Location:" . URL . "?url=cart");
        exit();
    }

    final function xhsAddToBasket() {
        $itemNumber = isset($_REQUEST["txtItemNumber"]) ? $_REQUEST["txtItemNumber"] : null;
        $noOfItems = isset($_REQUEST["txtNoOfItems"]) ? $_REQUEST["txtNoOfItems"] : null;
        if (is_numeric($noOfItems)) {
            if ($this->model->isItemNumberExists($itemNumber)) {
                try {

                    //create orderItem and reserve it on the basket
                    $item = $this->model->find($itemNumber, Item::BYNUMBER);
                    //check if it is object
                    if (!is_object($item)) {
                        $item = new Item();
                        Session::set(UNIVERSAL_REQUEST_ERROR, " Please there is an error why try to add item to basket contain administrator");
                    }

                    $ordeItem = new TOrderItem();
                    $ordeItem->setItemNumber(strval($item->getNumber()));
                    $ordeItem->setNumberOfItems(intval($noOfItems));
                    $ordeItem->setPrice($item->getCurrentPrice());


                    if ($ordeItem->getNumberOfItems() > $item->getStockLeft()) {
                        $numberInStock = $item->getStockLeft();
                        $ItemName = $item->getName();
                        if ($numberInStock == 0) {
                            Session::set(UNIVERSAL_REQUEST_ERROR, "We apologise that this item is no longer in stock for now check later please! ");
                        } else {
                            Session::set(UNIVERSAL_REQUEST_ERROR, "Oohs we only $numberInStock $ItemName are in stock for now, we apologise for that. ");
                        }
                    } else {
                        //get the basket list
                        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
                        //if there is no item then create an ArrayIteration List
                        if ($basket == null)
                            $basket = new ArrayIterator(Array());;

                        //Check if the Item already exist in the basket
                        if (!$this->isItemInBasket($itemNumber)) {
                            //append the item to a list control

                            $basket->append(serialize($ordeItem));
                            Session::set(CART_BASKET, $basket);
                        } else {
                           
                            $basketItem = $this->getBasketItem($itemNumber);
                            if($basketItem==null)
                                 $basketItem=new TOrderItem();
                               $totalItemNumber =intval($basketItem->getNumberOfItems()) + intval($noOfItems);
                            $this->updateBasketItem($itemNumber, $totalItemNumber);
                            Session::set(UNIVERSAL_REQUEST_ERROR, "The Item has be successfully added and updated");
                        }
                    }//end else 
                } catch (WebException $err) {
                    $messageArr = explode(":", $err->getMessage());
                    $message = $messageArr[1];
                    Session::set(UNIVERSAL_REQUEST_ERROR, $message);
                }
            }
        } else {
            Session::set(UNIVERSAL_REQUEST_ERROR, "Enter a valid item number please only numeric value are required");
        }

        header("Location:" . URL . "?url=cart");
        exit();
    }

    //end function
    final function xhsFindItems() {
        if (isset($_REQUEST["btnSubmitSearch"])) {
            $criteria = isset($_REQUEST["txtcriteria"]) ? $_REQUEST["txtcriteria"] : null;

            Session::set("CART_SWITCH_PANEL", explode(":", "displayCategoryItemsCart.html.php:$criteria"));
        }
        header("Location:" . URL . "?url=cart");
        exit();
    }

    final function xhsTrollerDisplay() {
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());
        $number = $basket->count();
        Session::set("CART_SWITCH_PANEL", explode(":", "basket.html.php:There are $number  Items in your basket"));
        header("Location:" . URL . "?url=cart");
        exit();
    }

    private final function isItemInBasket($number) {
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        $okay = false;
        if ($basket == null)
            return $okay;
        //check if  the item exist already in the basket
        foreach ($basket as $strOrderItems) {
            $orderItem = unserialize($strOrderItems);
            if ($number == $orderItem->getItemNumber()) {
                $okay = true;
                break;
            }
        }
        return $okay;
    }

    //end private method 

    final function xhsAmendBasketItem() {
        $itemNumber = isset($_REQUEST["txtItemNumber"]) ? $_REQUEST["txtItemNumber"] : null;

        if ($this->model->isItemNumberExists($itemNumber)) {

            try {


                //check if what operation the user want to carry out
                if (isset($_REQUEST["btnUpdateItemInBasket"])) {
                    //carryout update operation from in basket
                    $nitem = isset($_REQUEST["txtNItems"]) ? $_REQUEST["txtNItems"] : null;

                    $item = $this->model->find($itemNumber, Item::BYNUMBER);
                    if (!is_object($item))
                        $item = new Item();
                    $numberOfItems = (int) $nitem;
                    if ($numberOfItems > $item->getStockLeft()) {
                        $nItemsInstock = $item->getStockLeft();
                        $itemName = $item->getName();
                        throw new WebException("error:Oohs! we only have $nItemsInstock ($itemName)  in stock ", 0, null);
                    }
                    $this->updateBasketItem($itemNumber, $numberOfItems);
                } else if (isset($_REQUEST["btnDeleteItemFromBasket"]) && !empty($_REQUEST["btnDeleteItemFromBasket"])) {
                    //carryout deletion operation from on basket

                    $this->deleteBasketItem($itemNumber);
                }
            } catch (WebException $err) {
                Session::set("BASKET_OPERATIONS_FEEDBACK", explode(":", $err->getMessage()));
            }
        }//end if statement item number exist
        // print_r(Session::get("BASKET_OPERATIONS_FEEDBACK"));
        header("Location:" . URL . "?url=cart");
        exit();
    }

    //end xhsMethod

    final public function xhsItemsOrderPayments() {
        //check if there is item in the basket before proceeding
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());
        if ($basket->count() <= 0) {
            Session::delete(ACTIVE_SHIPPING_ADDRESS);
            Session::set(UNIVERSAL_REQUEST_ERROR, "There is not item in your trolley, please add item to trolley before you proceed.");
        } else {

            $addressId = isset($_REQUEST["address"]) ? $_REQUEST["address"] : null;
            require_once("model/Account.php");
            $account = new UserAccount();
            if ($account->isAddressExists($addressId)) {
                //if the address is set then check if there is item in the basket else
                //redirect the user to his basket
                //get the  basket else just create a new Array object to avoid error
                $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
                if ($basket == null)
                    $basket = new ArrayIterator();
                $number = $basket->count();

                if ($basket->count() >= 0) {

                    Session::set("ORDER_ADDRESS_ID", $addressId);
                    Session::set("CART_SWITCH_PANEL", explode(":", "ordersMakePayment.html.php:There are $number  Items in your basket"));
                } else {
                    Session::set("CART_SWITCH_PANEL", explode(":", "basket.html.php:There are $number  Items in your basket"));
                }
            }//end if
        }//end else basket not empty

        header("Location:" . URL . "?url=cart");
        exit();
    }

    //end 

    final private function updateBasketItem($itemNumber, $nitem) {
        if ($this->isItemInBasket($itemNumber)) {
            //delete the itemorder from the basket     


            $basket = (Session::get(CART_BASKET) != null) ? Session::get(CART_BASKET) : null;
            if ($basket == null)
                $basket = new ArrayIterator(Array());


            //loop the basket to fine the item
            while ($basket->valid()) {
                $orderItem = unserialize($basket->current());

                if ($orderItem->getItemNumber() == $itemNumber) {
                    if (!is_integer(intval($nitem)) || intval($nitem) < 1) {
                        throw new WebException("basket_error: number of item to order must be an integer value only.", 0, null);
                    } else {
                        $orderItem->setNumberOfItems((int) $nitem);
                        //set the item and update the basket
                        //echo $nitem;
                        $basket->offsetSet($basket->key(), serialize($orderItem));
                        Session::set(CART_BASKET, $basket);
                        break;
                    }
                }
                $basket->next();
            }//end foreach loop
        } else {
            throw new WebException("basket_error:The item is not even in your basket,so why trying to update it", 0, null);
        }
    }
    private function getBasketItem($itemNumber)
    {
        $basketItem=null;
         if ($this->isItemInBasket($itemNumber)) {
            //delete the itemorder from the basket     


            $basket = (Session::get(CART_BASKET) != null) ? Session::get(CART_BASKET) : null;
            if ($basket == null)
                $basket = new ArrayIterator(Array());
            
             //loop the basket to fine the item
            while ($basket->valid()) {
                $orderItem = unserialize($basket->current());

                if ($orderItem->getItemNumber() == $itemNumber) {
                       $basketItem=$orderItem;
                        break;
                    }
                $basket->next();
            }//end foreach loop
                
            }//end if            
         
        return $basketItem;
    }//end function

    final private function deleteBasketItem($itemNumber) {
        if ($this->isItemInBasket($itemNumber)) {
            //delete the itemorder from the basket
            $basket = (Session::get(CART_BASKET) != null) ? Session::get(CART_BASKET) : null;
            if ($basket == null)
                $basket = new ArrayIterator(Array());


            //loop the basket to fine the item
            while ($basket->valid()) {
                $orderItem = unserialize($basket->current());

                if ($orderItem->getItemNumber() == $itemNumber) {

                    $basket->offsetUnset($basket->key());
                    Session::set(CART_BASKET, $basket);
                    break;
                }
                $basket->next();
            }//end foreach loop
        } else {
            throw new WebException("basket_error:The item is not even in your basket, so there is no worries about deleting it", 0, null);
        }
    }

    //allow only login in user to carry of this operations

    final public function xhsMakePaymentForItems() {

        //get the form values ,card details
        $txtNameOnCard = isset($_REQUEST["txtNameOnCard"]) ? $_REQUEST["txtNameOnCard"] : null;
        $txtCardNumber = isset($_REQUEST["txtCardNumber"]) ? $_REQUEST["txtCardNumber"] : null;
        $txtExpiredate = isset($_REQUEST["txtExpiredate"]) ? $_REQUEST["txtExpiredate"] : null;
        $txtSecurityNumber = isset($_REQUEST["txtSecurityNumber"]) ? $_REQUEST["txtSecurityNumber"] : null;
        // $txtTotalAmount = isset($_REQUEST["txtTotalAmount"]) ? $_REQUEST["txtTotalAmount"] : null;
        //now Session the values for sticking form

        Session::set("CARD_NAME", $txtNameOnCard);
        Session::set("CARD_NUMBER", $txtCardNumber);
        Session::set("CARD_EXPIRING_DATE", $txtExpiredate);
        Session::set("CARD_SECURITY_NUMBER", $txtSecurityNumber);
        // not required since the fields is readonly Session::set("CARD_TOTAL_AMOUNT",$txtTotalAmount);
        //let check if the user login
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());


        if (Session::get(LOGIN) != true) {
            //re-direct user to login page
            Session::set(UNIVERSAL_REQUEST_ERROR, "Before you can be allow to order an item, please kindly login into your account or create one");
            Session::set(PREVIOUS_REQUEST_URL, "cart/xhsMakePaymentForItems");
            header("Location:" . URL . "?url=guest");
            exit();
        }//end if
        //Carry out the operations
        if ($basket->count() <= 0) {
            // echo "Hey".$basket->count();
            Session::set("CART_SWITCH_PANEL", explode(":", "basket.html.php:There are 0 Items in your basket"));
            header("Location:" . URL . "?url=cart/");
            exit();
        }
        //Set the panel you want the user to see when he or she make payment
        Session::set("CART_SWITCH_PANEL", explode(":", "ordersMakePayment.html.php:change address to ship to"));

        if ($this->getTotalItemsAmountFromBasket() > 0.0) {
            //now the there is an Item 

            require_once("model/Account.php");

            try {

                $account = new UserAccount();

                $account->validatedPaymentDetails($txtNameOnCard, $txtCardNumber, $txtExpiredate, $txtSecurityNumber);
                if ($account->isPayment()) {
                    //

                    $orderNumber = $this->orderItems((int) $txtCardNumber);
                    Session::set("ORDER_BY_PAYMENT", explode(":", "payment_sucessful: Your Items has be ordered"));
                    //switch the panel to order panel
                    Session::set("CART_SWITCH_PANEL", explode(":", "myorders.html.php:successully"));
                    Session::delete(CART_BASKET);

                    $this->deleteCookies(); //delete the basket cookies

                    Session::delete(ACTIVE_SHIPPING_ADDRESS);
                    Session::set(CURRENT_ORDER_NUMBER, $orderNumber);
                    Session::set(UNIVERSAL_REQUEST_ERROR, " Your current order number is $orderNumber:<p> Please take note that when order status change from pending to processed order can no longer be cancel</p>");
                }
            } catch (WebException $err) {
                Session::set("ORDER_BY_PAYMENT", explode(":", $err->getMessage()));
            }
        }//end if statement


        header("Location:" . URL . "?ur=cart");
        exit();
    }

    //end function

    final function xhsRandomItemDisplay() {
        $temCategories = new ArrayIterator(Array());
        //we have to cart all the item categories that have items inside and randomly select anyone to display
        $categories = $this->model->getCategories();
        //let check each category to see if their is an item if so,
        //then store 

        foreach ($categories as $category) {
            $itemsIncategory = $this->model->getItemsInCategory($category->getNumber());
            if ($itemsIncategory->count() > 0) {
                $temCategories->append($category);
            }
        }//end foreach
        //delete the rest variables
        unset($categories);

        //now we have categories with values in them
        $catNumber = null;
        if ($temCategories->count() > 0) {//if there is category store carry out this action
            srand(time());
            $numRandon = rand(0, $temCategories->count() - 1);
            $temcategory = $temCategories->offsetGet($numRandon);
            $catNumber = $temcategory->getNumber();
        }

        Session::set("CART_SWITCH_PANEL", explode(":", "displayCategoryItemsCart.html.php:$catNumber"));

        header("Location:" . URL . "?url=cart");
        exit();
    }

    //end function;

    final private function orderItems($txtCardNumber) {
        //get the basket of the customer and order all the items, and shipping address number
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());
        //check if Shiping address is active;
        $active_address_id = (Session::get(ACTIVE_SHIPPING_ADDRESS) != "") ? Session::get(ACTIVE_SHIPPING_ADDRESS) : null;
        if ($active_address_id === null)
            throw new WebException("error:Where are you shipping this items to please!, you have to select an address or add address to select", 0, null);
        //every is okay then let order the items now

        if ($basket->count() > 0) {
            //create an account object
            require_once("model/Account.php");
            $account = new UserAccount();
            $ordernumber = "";
            //get customer 
            $customer = $account->getCustomer(Session::get(LOGIN_EMAIL));
            $date = time();
            //there is an items to order
            foreach ($basket as $strOrderItem) {
                $orderItem = unserialize($strOrderItem);
                //*user to test item, it can order 
                if ($orderItem == null) {
                    $orderItem = new TOrderItem();
                    continue; //continue the next loop step
                }
                $ordernumber = (Integer) (microtime() * time()) . "" . $account->getOrdersCount();
                $orderItem->setOrderNumber($ordernumber);
                $orderItem->setDate($date);
                $orderItem->setPaymentCardNumber($txtCardNumber);
                $orderItem->setShipAddress($active_address_id);
                $orderItem->setCustomerID($customer->getClientID());
                $account->addOrderItem($orderItem);
                //check if the item is ordered
                if (!$account->isOrdered()) {
                    throw new WebException($account->getError(), 0, null);
                    break;
                }
                //update the number of stock stock 
                $item = $this->model->find($orderItem->getItemNumber(), Item::BYNUMBER);
                if (!is_object($item)) {
                    $item = new Item();
                }
                $item->setStockLeft($item->getStockLeft() - $orderItem->getNumberOfItems());
                $this->model->insertItem($item);
            }///end for each statement

            return $ordernumber; // stop the excution
        }

        throw new WebException("error:Ther is no item to order please!");
    }

    final private function getTotalItemsAmountFromBasket() {
        //get the basket of the customer
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());
        $totalAmountOfItems = 0.0;
        //loop and get the total about of item prices
        foreach ($basket as $strOrderItem) {

            $orderItem = unserialize($strOrderItem);
            $totalAmountOfItems +=(double) $orderItem->getTotalPrice();
        }
        //return the total amount
        /*
         *      echo "<pre>";
          print_r($basket);
          echo "</pre>";
         */
        return (float) $totalAmountOfItems;
    }

    //end the function

    final public function xhsChangeShippingAddress() {
        Session::set("CART_SWITCH_PANEL", explode(":", "OrderItemsFromBasket.html.php:change address to ship to"));
        header("Location:" . URL . "?url=cart");
        exit();
    }

    final public function xhsMyOrders() {
        if (Session::get(LOGIN) != true) {
            Session::set(PREVIOUS_REQUEST_URL, "cart/xhsMyOrders");
            Session::set(UNIVERSAL_REQUEST_ERROR, "Hello guest, you are required to login before you can access your order page!");
            Session::delete(LOGIN_EMAIL);
            header("Location:" . URL . "?url=guest");
            exit();
        }

        Session::set("CART_SWITCH_PANEL", explode(":", "myorders.html.php:myorders"));
        header("Location:" . URL . "?url=cart");
        exit();
    }

    //end function

    public function validated() {
        
    }

    private function deleteCookies() {
        $expireTime = time() - (60 * 60 * 24 * 30);
        setcookie(BASKET_COOKIES, "", $expireTime);
    }

    //put your code here

    final public function xhsShowItemProfile() {
        $itemID = isset($_REQUEST["itemID"]) ? $_REQUEST["itemID"] : null;
        if ($this->model->isItemNumberExists($itemID)) {
            Session::set("CART_SWITCH_PANEL", explode(":", "itemprofile.html.php:$itemID"));
        }

        header("Location:" . URL . "?url=cart");
        exit();
    }

//end function 
}

//end class cart
?>
