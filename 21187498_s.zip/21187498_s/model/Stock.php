<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Aggregation pattern style is implement here for the product
 * Description of product
 *
 * @author jimobama
 */
class Stock_Model extends Model {

    //put your code here
    private $isAdd;
    private $isDelete;
    private $isInsert;
    private $items;
    private $categories;
    private $isSave;
    private $db = null;
    private $itemFile;
    private $fileCategory;

//Th construct of the class 
    function __construct() {//tested
        parent::__construct(); //calling the parent constructor to be initialised
        $this->itemFile = DATA_PATH . "items_tbl.ob";
        $this->fileCategory = DATA_PATH . "category_tbl.ob";
        $this->db = new IOStream();
        //initialised the item array objects
        $this->items = new ArrayIterator(Array());
        $this->categories = new ArrayIterator(Array());
        //initialised the variables
        $this->isAdd = false;
        $this->isDelete = false;
        $this->isInsert = false;
        $this->isSave = false;
        $this->loadItems();
        $this->loadCategorys(); //load the data from the file to the ArrayIterations
    }

    //This function will added an item to the list 
    function addItem(Item $item = null) {//tested 
        $this->loadItems();
        //catch an error that will occur 
        if ($item == null) {
            throw new WebException("item:  WebException=> Stock method add() cannot accept null value", 0, null);
        }
         $item->validated(); //valid the class make such his not in a try block;
        if ($this->isCategoryIDExists($item->getCategoryNumber())>=0) {           
             try {
                //check if the item product number exist already
                if (!self::isItemNumberExists($item->getNumber())) {

                    //check if the item name already exist
                    if (self::isItemExistAlready($item->getName(), $item->getCategoryNumber())) {

                        throw new WebException("This Item you are trying to add already exist in this category [" . self::getCategory($item->getCategoryNumber()) . getName() . "]", 0, null);
                    } else {

                        self::appendItem($item);
                    }
                }//end item exits not           
            } catch (ItemException $err) {//catch the ItemException error 
                //set the error 
                $this->setError($err->getMessage());
            }
        } else {
            $this->setError("category_number:Please select item category");
        }
    }

    //append to the list
    protected function appendItem(Item $item) {//tested
        if ($this->items == null) {
            $this->items = new ArrayIterator();
        }
        //serialised the item object to string
        $serialisedItem = serialize($item);
        //append the serialised item to the list
        $this->items->append($serialisedItem);
        $this->saveItems();
        $this->isAdd = true;
    }

    //this function will return the position of an item 
    final private function getItemPosition($itemNumber) {//tested
        $index = -1;
        if ($this->items == null)
            return $index;
        foreach ($this->items as $strItem) {
            $item = unserialize($strItem);
            if ($item->getNumber() == $itemNumber) {

                $index = $this->items->key();
                break;
            }//end if
        }//end foreach statement

        return $index; //return the item position or key
    }

//end the method

    final public function isItemNumberExists($itemNumber) {//tested
        //The the function to get the item position 
        $pos = $this->getItemPosition($itemNumber);
        if ($pos >= 0) {
            return true;
        }
        return false;
    }

    final public function isItemNameExists($name) {
        //loop the item list object 
        $exists = false;
        if(!is_object($this->items))
            $this->items=new ArrayIterator(Array());
        
        while ($this->items->valid()) {
            $item = $this->items->current();
            //check if the product number is found
            if ($item->getName() == $name) {
                $exists = true;
                break; //stop the loop
            }
            //get the next item
            $this->items->next();
        }//end the while statement
        //return the feedback value 
        return $exists;
    }

    //check if the item is added to the item list
    final function isAdded() {//tested
        return $this->isAdd;
    }

    //Create a function that will delete an item from the list

    final public function deleteItem($itemNumber) {//tested
        if ($this->isItemNumberExists($itemNumber)) {
            //call the list upset method to delete the item with the particular item number
            $pos = $this->getItemPosition($itemNumber);
            //left delete the item image first
            $item=$this->find($itemNumber,Item::BYNUMBER);
            if(!is_object($item))
                 $item=new Item();
           if(file_exists(ITEM_IMAGES. $item->getPhoto()))
              @unlink(ITEM_IMAGES. $item->getPhoto());
            //the delete the item from the ArrayIterator obect
            $this->items->offsetUnset($pos);
            //set the deleted flag to true;
            $this->isDelete = true;
            if ($this->items == null)
                return;
            $this->saveItems();
        }
    }

//end function delete Item
//end method to delete item

    final private function findItemByNumber($number) {//tested
        $item = null;
       try
       {
        if ($this->isItemNumberExists($number)) {
            //get the item with the number
            $this->items->seek($this->getItemPosition($number));
            $item = unserialize($this->items->current());
        }
        //return the find item or null
       }
       catch(OutOfBoundsException $err)
       {
           
       }
        return $item;
       
      
    }

    final private function findItemsByName($name) {//tested
        $temItems = new ArrayIterator();
        if ($this->items == null)
            return;

        foreach ($this->items as $strItem) {
            $item = unserialize($strItem);
            if ($item->getName() == $name) {
                $temItems->append($item);
            }
        }

        //return the find item or null
        return $temItems;
    }

    final public function find($criteria, $by) {//tested
        $searchItems = new ArrayIterator(Array());
        //determined the type of the search and what you want to search it with
        $criteria=  strtolower($criteria);
        switch ($by) {
            //search item by the name type
            case Item::BYNAME: {
                    $searchItems = $this->findItemsByName($criteria);
                }break;
            case Item::BYNUMBER: {//serach items by the Number
                    $searchItems = $this->findItemByNumber($criteria);
                }break;
            case ItemCategory::CATEGORY: {//search items by their categories
                    $searchItems = $this->findItemsByCategory($criteria);
                }break;
            case ItemCategory::KEYWORDS: {//find the item by the keywords in the category
                    $searchItems = $this->findItemsByCategoryKeywords($criteria);
                }break;
        }//end switch

        return $searchItems;
    }

//end find method
//end find method

    private final function findItemsByCategory($criteria) {//tested
        $items = new ArrayIterator(Array());

        if ($this->items == null)
            return $items;
        //search the list 
        // echo $this->items->count();

        foreach ($this->items as $strItem) {
            //match the $criteria to the items category id              
            $item = unserialize($strItem);

            //  echo "<br>Item Number is ".$item->getCategoryNumber().": <br>";
            if ($item->getCategoryNumber() == $criteria) {

                $items->append($item);
            }
        }
        return $items;
    }

//end findItemsByCategory
//function to fine the items by keywords
    private final function findItemsByCategoryKeywords($criteria) {//tested and working
        //parse the $criteria to words array
        $teturnItems = new ArrayIterator();
        $keywords = explode(" ", $criteria);
        foreach ($keywords as $parsekeyword) {
            //echo $parsekeyword . "<br>";
            //get the category match numbers
            $categoryNumbers = $this->getMatchCategoryNumbers($parsekeyword);
            //check if there is a match else take no actions
            if ($categoryNumbers->count() > 0) {
                //gives two dimension array of Items category of items
                $temItemsForCategory = $this->getCategoryMatchItems($categoryNumbers);

                foreach ($temItemsForCategory as $items) {
                    //if there is items in the items then continue items object

                    if ($items->count() > 0) {
                        //get the item in the items array  
                        foreach ($items as $item) {//append the items                        
                            //check if the item is already added to the return items
                            if (!$this->isFound($item->getNumber(), $teturnItems)) {
                                $teturnItems->append($item);
                            }
                        }//end foreach items loop
                    }//end $items if
                }//end for each  
            }//end if greate than zeor categoryNumber arrays
        }//end foreach

        return $teturnItems;
    }

//end find by keywords

    private function getMatchCategoryNumbers($keyword) {//tested return all category number that keyword matched
        //test if there is an items in the category list
        $categories_numbers = new ArrayIterator(Array());

        if ($this->categories->count() > 0) {

            foreach ($this->categories as $strCategory) {

                $category = unserialize($strCategory);

                $categoryKeywords = explode(",", $category->getKeywords());

                for ($i = 0; $i < count($categoryKeywords); $i++) {

                    if (strtolower($categoryKeywords[$i]) == strtolower($keyword)) {
                        $categoryID = $category->getNumber();
                        //echo  $keyword.":I reach here<br>";                      
                        $categories_numbers->append($categoryID);
                        ;
                    }//end if
                }//end for
            }//end for each
        }//end if count


        return $categories_numbers;
    }

//end function 

    private function getCategoryMatchItems(ArrayIterator $arrayCategoryNumber) {//tested and working
        $itemsCategories = new ArrayIterator(Array());

        foreach ($arrayCategoryNumber as $categoryNumber) {
            $item_s = $this->findItemsByCategory($categoryNumber);
            if ($item_s != null)
                $itemsCategories->append($item_s);
        }
        return $itemsCategories;
    }

  final  public function isFound($number, ArrayIterator $items) {
        $isF = false; //set the flag to false
        if ($items != null) {
            foreach ($items as $item) {
                if ($item->getNumber() == $number) {
                    $isF = true;
                    break;
                }
            }
        }

        return $isF;
    }

    final function insertItem(Item $newitem) {//tested and working
        
        $newitem->validated();
        $number= $newitem->getNumber();
        $pos = $this->getItemPosition($number);
        
        if ($pos < 0 || $pos > ($this->items->count() - 1)) {
            throw new WebException("insert:Item $number  is not found or invalid item number!", 0, null);
            // echo $pos;
        }            
        $this->items->seek($pos);
        $this->items->offsetSet($pos, serialize($newitem));
        $this->saveItems();
        $this->isSave = true;
    }

//this method get the getItems object list and return ArrayIterator objects
    final public function getItems() {//tested
        //reload the items from the database and getthem
        $this->loadItems();
        //create a temlist of all the items and make such there are objects instead of string    
        $temItems = new ArrayIterator(Array());
        //loop inside the items
        while ($this->items->valid()) {
            $temItems->append(unserialize($this->items->current()));
            $this->items->next();
        }
        return $temItems;
    }

//this function can be over ride by child class or change directly
    protected function saveItems() {//tested
        //connect to the database file
        if ($this->db->isConnected($this->itemFile)) {
            $serialisedArrayIterator = serialize($this->items);
            $this->db->put_file_content($serialisedArrayIterator);
            $this->isSave = true;
        }
    }

//This function check if the  current save item is saved
    function isSaved() {//tested
        return $this->isSave;
    }

//this is a private function that will load the items fro the item database
    private function loadItems() {//tested
//Creating the instance of the IOstream
        //check if the file exist else it create and connect to the file
        if ($this->db->isConnected($this->itemFile)) {
//Check if there is data on the file or is null
            if ($this->db->get_file_content() != null || $this->db->get_file_content() != "") {
                //if there is an item in the file then get it
                $serialisedArrayIterator = $this->db->get_file_content();
                //unserialised the string items got
                $unserialisedArrayIterator = @unserialize($serialisedArrayIterator);
                // set it to the ArrayIterator Object of the class
                $this->items = $unserialisedArrayIterator;
            }
        }
    }

// This return the number of items in the file database
    final public function getItemsCount() {//tested
        if ($this->items == null)
            return 0;
        $counts = $this->items->count(); //get the number of the item
        if (!$counts) {//if it is -1 return 0
            return 0;
        }
        return $counts; //return the number of items
    }

    // This method check if an Item is deleted
    final function isDeleted() {//tested
        return $this->isDelete;
    }

    //this function check if the Item name already exist in the stock 
    final protected function isItemExistAlready($itemName, $catID) {//tested
        $isExist = false;
        $newListItem = $this->findItemsByName($itemName);
        if ($newListItem == null) {
            return;
        }
        while ($newListItem->valid()) {
            $item = $newListItem->current();
            //check if the item on the list match the query name
            if ($item->getName() == $itemName) {
                //if it does then
                //check if the item catgory is same
                if ($item->getCategoryNumber() == $catID) {
                    $isExist = true;
                }
            }
            $newListItem->next();
        }//end while statement
        return $isExist;
    }

//end function while
    //Category operations start here

    final function addCategory(ItemCategory $category) {//tested
        //validate the data inclass the object is pass to it without data
        $category->validated();
        try {//check if the category number exist 
            if ($this->isCategoryIDExists($category->getNumber()) == -1) {
                //check if the category Name exist
                if (!$this->isCategoryNameExists($category->getName())) {//add the category to the category list
                    $this->appendCategory($category);
                } else {
                    throw new WebException("exists: Category name already exist", 0, null);
                }
            }//end isCategoyIDExist
        } catch (WebException $err) {

            $this->setError($err->getMessage());
        }
    }//end add category
    //
    //
    
    final function deleteCategory($catNumber)
    {
        if ($this->isCategoryIDExists($catNumber)>=0) {
            //call the list upset method to delete the categorywith the particular item number
            $pos = $this->getCategoryPosition($catNumber);
            //the delete the item from the ArrayIterator obect
            $this->categories->offsetUnset($pos);
            //set the deleted flag to true;
            $this->isDelete = true;
           $this->saveCategory();
        }
      else
      {
          $this->setError("error: Category cannot be deleted because the category number is not found");
      }
    }
    //This method return all the category list objects
    public final function getCategories() {
        $temCategories = new ArrayIterator(Array());
        if(!is_object($this->categories) || $this->categories->count()<=0)
        {
            return $temCategories;
        }
        foreach ($this->categories as $strCategory) {
            $category = unserialize($strCategory);
            $temCategories->append($category);
        }
        return $temCategories;
    }

    private final function loadCategorys() {//tested
//Creating the instance of the IOstream
        //check if the file exist else it create and connect to the file
        if ($this->db->isConnected($this->fileCategory)) {
//Check if there is data on the file or is null
            if ($this->db->get_file_content() != null || $this->db->get_file_content() != "") {
                //if there is an item in the file then get it
                $serialisedArrayIterator = $this->db->get_file_content();
                //unserialised the string items got
                $unserialisedArrayIterator = @unserialize($serialisedArrayIterator);
                // set it to the ArrayIterator Object of the class
                $this->categories = $unserialisedArrayIterator;
            }
        }
    }

//end methed load category
final function getCategoryCounts()
{
    return $this->categories->count();
}
    final function isCategoryIDExists($categoryid) {//tested
        $index = -1;
        $counter = 0;
       
        foreach ($this->categories as $strCategory) {
            $temcategory = unserialize($strCategory);
            if ($temcategory->getNumber() == $categoryid) {
                $index = $counter;
                break;
            }
            $counter++;
        }

        return $index;
    }

//end function 

    function getCategory($categoryNumber) {//tested
        try {
            $index = self::getCategoryPosition($categoryNumber);

            if ($index < 0 || $this->categories->count() <= 0) {
                //throw exceptions
                throw new WebException("category_number: The category[$categoryNumber] is not found", 0, null);
            }
            //move to the position of the category
            // echo $index;
            $this->categories->seek($index);
            return unserialize($this->categories->current());
        } catch (OutOfBoundsException $err) {
            $this->setError($err->getMessage());
        }
        catch(WebException $err)
        {
         throw $err;   
        }
    }

    final private function appendCategory(ItemCategory $category) {//tested
        if ($this->db->isConnected($this->fileCategory)) {
            $this->loadCategorys(); //load the category from the file database         
            $this->categories->append(serialize($category));
            $this->saveCategory();
            $this->isAdd = true;
        }
    }

//This function save the category objects into the category table or file
    private function saveCategory() {//tested
        // This test if there is value in the category list
        if (!$this->categories->valid()) {
            throw new WebException("There is no category list to save please!", 0, null);
        }

        if ($this->db->isConnected($this->fileCategory)) {
            $serialisedCategoryArrayIterator = serialize($this->categories);
            $this->db->put_file_content($serialisedCategoryArrayIterator);
        }
    }

//end saveCategory

    private function getCategoryPosition($categoryid) {//tested
        $index = -1;
        $counter = 0;
        if ($this->categories != null) {
            foreach ($this->categories as $strCategory) {
                $itemCategory = unserialize($strCategory);
                if ($itemCategory->getNumber() == $categoryid) {
                    $index = $counter;
                    break;
                }
                $counter++;
            }//end while statement
        }
        //echo $index;
        return $index;
    }

//end getCategoryPosition

    private function isCategoryNameExists($name) {//tested
        $isTrue = false; //set the default value to false
        //loop the list 
        foreach ($this->categories as $strCategory) {
            $category = unserialize($strCategory);
            //check if the name is same
            if ($category->getName() == $name) {
                $isTrue = true;
            }
        }//end for each

        return $isTrue;
    }

//end method
    
    
   final public function getItemsInCategoryCount($catNumber)
   {
       $items=$this->findItemsByCategory($catNumber);       
       return $items->count();
   }
   
     
   final public function getItemsInCategory($catNumber)
   {
       $items=$this->findItemsByCategory($catNumber);       
       return $items;
   }

   final function updateCategory($category)
   {
            if(!isset($category) || !is_object($category))
            {
                throw new WebException("error: There is no category object set to updated ");
                
            }
        $number=$category->getNumber();    
       $pos = $this->getCategoryPosition($number);
       
        if ($pos < 0 || $pos > ($this->categories->count() - 1)) {
            throw new WebException("insert:Category $number  is not found or is invalid!", 0, null);
            // echo $pos;
        }
        $this->categories->seek($pos);       
        $this->categories->offsetSet($pos, serialize($category));
        $this->saveCategory();
        $this->isSave = true;
       
        
   }
    function __destruct() {//tested and working
        parent::__destruct();
        unset($this->items);
        unset($this->categories);
    }

}

?>
