<?php

//end brace

class UserAccount extends Model {

    private $customers;
    private $addresses;
    private $orders;
    private $customer_tbl;
    private $customer_address_tbl;
    private $admins;
    private $admin_tbl;
    private $orders_tbl;
    private $db;
    private $isAdd;
    private $isSave;
    private $isPayment;
    private $isOrder;
    private $isDelete;

    public function __construct() {
        $this->isAdd = false;
        $this->isSave = false;
        $this->isPayment = false;
        $this->isOrder = false;
        $this->isDelete = false;
        $this->customer_tbl = DATA_PATH . "customer_tbl.ob";
        $this->customer_address_tbl = DATA_PATH . "address_tbl.ob";
        $this->orders_tbl = DATA_PATH . "orders_tbl.ob";
        $this->admin_tbl=DATA_PATH."admin_tbl.ob";
        
        $this->db = new IOStream();
        $this->customers = new ArrayIterator(Array());
        $this->addresses = new ArrayIterator(Array());
        $this->orders = new ArrayIterator(Array());
        $this->admins=new ArrayIterator(Array());
        $this->loadCustomers(); //this function load all the customer to the customers list
        $this->loadAddress();
        $this->loadOrders();
        $this->loadAdmins();
    }

//end method

    final private function loadCustomers() {
        //check if the file is connected
        if ($this->db->isConnected($this->customer_tbl)) {
            if ($this->db->get_file_content() != null || $this->db->get_file_content() != "") {
                //if there is an item in the file then get it
                $serialisedArrayIterator = $this->db->get_file_content();
                //unserialised the string items got

                $unserialisedArrayIterator = @unserialize($serialisedArrayIterator);
                // set it to the ArrayIterator Object of the class
                $this->customers = $unserialisedArrayIterator;
            }
        }//end isConnected brace
    }

//end the function

    public function at($index) {

        $count = $this->customers->count();

        if ($index >= 0 && $index < $count) {
            //seek the position of the item
            $this->customers->seek($index);
            return unserialize($this->customers->current());
        }
        throw new WebException("There is no customer found with that $index number", 0, null);
    }

    //this function append a client record to the list
    function add(TCustomer $customer) {
        //Set the values
        $customer->validated(); //throw an exception if there is an error

        try { //set the customer details
            ///$clientID = (Integer) (microtime() * time()) + "" + $this->customers->count();
            if (!$this->isCustomerEmail($customer->getEmail())) {
                //add and save the customer list
                $this->appendCustomer($customer);
            } else {
                $this->setError("email: This email address has already be used by another customer");
            }
        }//end try
        catch (WebException $err) {
            $this->setError($err);
        }
    }

//end add customer details
    final public function isAdded() {
        return $this->isAdd;
    }

    public function isCustomerEmail($email) {

        $postion = self::getCustomerPosition($email);

        if ($postion >= 0) {
            return true;
        }
        return false;
    }

//end 

    final private function getCustomerPosition($email) {
        $email = addslashes(strtolower(trim($email)));
        $index = -1;
       
        if (!is_object($this->customers) || $this->customers->count() <= 0) {
            $this->customers=new ArrayIterator(Array());
            return $index;
        }
         
        $counter=0; 
        foreach ($this->customers as $strCustomer) {
            $customer = unserialize($strCustomer);
            if (strtolower($customer->getEmail()) == $email) {
                $index = $counter;
                break;
            }
          $counter++;
        }//end foreach
               
        return $index;
    }

//end method
    final public function getCustomers() {
        $customers = new ArrayIterator(Array());
        if ($this->customers->count() > 0) {
            foreach ($this->customers as $strCustomer) {
                $customer = unserialize($strCustomer);
                $customers->append($customer);
            }
        }

        return $customers;
    }

//end method
    final public function getCustomer($email) {
        $email = addslashes(trim($email));
        $customer = null;
        $postion = self::getCustomerPosition($email);
        if ($postion >= 0) {
            $customer = $this->at($postion);
        }

        return $customer;
    }
    
  final function isCustomerIDExists($id)
   {
        $isOkay= -1;
       if(!is_object($this->customers)){
           $this->customers=new ArrayIterator(Array());
           return $isOkay;
       }
      
       
       $counter=0;
       foreach($this->customers as $strcustomer)
       {            
           $customer=  unserialize($strcustomer);
          // echo "$id sdjhsfdv ".$customer->getClientID();
           if($customer==null)
               $customer=new TCustomer();
           if($customer->getClientID()==$id)
           {
               $isOkay=$counter;
               break;
           }
        $counter++;   
       }
       return $isOkay;
   }

   final function getCustomerById($id)
   {
       $pos = $this->isCustomerIDExists($id);
       $customer=null;
       if($pos>=0)
       {
           $customer = $this->at($pos);
       }
      return $customer;
   }
    public final function deleteCustomer($email) {

        $email = addslashes(trim($email));

        $index = $this->getCustomerPosition($email);

        if ($index >= 0) {

            $this->customers->offsetUnset($index);
            $this->saveCustomers();
            $this->isDelete = true;
            return;
        }
        throw new WebException("customer_email:Customer account cannot be deleted: invalid email address", 0, null);
    }

    private final function appendCustomer(TCustomer $customer) {
        $customer->setPassword(md5($customer->getPassword()));
        $this->customers->append(serialize($customer));
        $this->saveCustomers(); //save the customer informations
        $this->loadCustomers(); //reload the customers from the file
        $this->isAdd = true;
    }

//end 
    final public function saveCustomers() {

        if ($this->customers->count() >= 0) {
            if ($this->db->isConnected($this->customer_tbl)) {
                $customers = serialize($this->customers);
                $this->db->put_file_content($customers);
                $this->isSave = true;
            }
        }
    }

//save customer

    final public function insertCustomer($email, TCustomer $customer) {

        $email = addslashes(trim($email));
        $customer->setPassword(md5($customer->getPassword()));
        if ($this->isCustomerEmail($email)) {
            $pos = $this->getCustomerPosition($email);
            if ($pos >= 0) {
                $temCustomer = $this->at($pos);
                $customer->setClientID($temCustomer->getClientID());
                $this->customers->offsetSet($pos, serialize($customer));
                $this->saveCustomers();
                return;
            }
            throw new WebException("customer:Customer information is invalid and cannot be updated please!", 0, null);
        }
        throw new WebException("customer_email: Customer  account is not found", 0, null);
    }

    public final function getCustomerCounts() {

        return $this->customers->count();
    }

    public function loginCustomer($email, $password) {
        $email = addslashes(trim($email));
        $index = $this->getCustomerPosition($email);
        $password = (md5($password));
        //check if the index is less than 0
        
        if ($index < 0) {
            throw new WebException("customer_login:The email address did not exist[ you can register this email if you want]", 0, null);
        }
        //return the customer data object of the position provided
        $customer = $this->at($index);
        //verify if the login details is correct
        if ($customer->getPassword() == $password && $customer->getEmail() == $email) {
            return true;
        }

        throw new WebException("customer_login: Invalid  email address or password ", 0, null);
    }

    //This function change the customer password
    final public function changePassword($currentpassword, TCustomer $customer) {
        $customer->validated();
        try {

            $email = $customer->getEmail();
            //encrpt the password            
            $password = md5(addslashes($currentpassword));
            $pos = $this->getCustomerPosition($email);
            //if the email is found then
            if ($pos > -1) {
                $temCustomer = $this->at($pos); //get the previous customer details
                if ($temCustomer->getPassword() == $password) {
                    $customer->setClientID($temCustomer->getClientID());
                    $this->insertCustomer($email, $customer);
                    return;
                }
                $this->setError("customer_password:Enter your previous password");
            } else {
                $this->setError("customer_email:Please re-login before you can carry this operations(Account expired)");
            }
        } catch (WebException $err) {
            throw $err;
        }
    }

    //add the adresses

    final public function addAddress(TAddress $address) {
        //check if the details are set
        $address->validated();
        try {
            if (!$this->isAddressExists($address->getAddressID())) {
                //if did nt exist
                $this->appendAddress($address);
            } else {
                throw new WebException("address_exist: The exist ID already exist", 0, null);
            }
        } catch (WebException $err) {
            $this->setError($err->getMessage());
        }
    }

//end addAdress

    private final function appendAddress(TAddress $address) {
        $strAdress = serialize($address);
        $this->addresses->append($strAdress);
        $this->saveAddresses();
    }

    private final function saveAddresses() {
        if ($this->db->isConnected($this->customer_address_tbl)) {
            $strAddresses = serialize($this->addresses);
            $this->db->put_file_content($strAddresses);
        }
        $this->loadAddress();
    }

    private final function loadAddress() {
        if ($this->db->isConnected($this->customer_address_tbl)) {
            $strAddresses = $this->db->get_file_content();
            $this->addresses = unserialize($strAddresses);
        }
    }

    final function isAddressExists($addressId) {
        $okay = false;
        if ($this->addresses->count() <= 0)
            return $okay;
        //loop the address object array
        foreach ($this->addresses as $strAddress) {
            $address = unserialize($strAddress);
            if ($address == null)
                $address = new TAddress();
            if ($address->getAddressID() == $addressId) {
                $okay = true;
                break;
            }//end if
        }//end foreach

        return $okay;
    }

    final function getAddressCount() {

        return $this->addresses->count();
    }

    final public function getAddress($addressID) {
        $address = null;

        if ($this->addresses->count() > 0) {
            while ($this->addresses->valid()) {
                $strAddress = $this->addresses->current();
                $temaddress = unserialize($strAddress);

                if ($temaddress->getAddressID() == $addressID) {
                    $address = clone $temaddress;
                    break;
                }


                $this->addresses->next();
            }
        }//end if


        return $address;
    }

    public final function getAddresses($email = "") {
        $customer_address = new ArrayIterator(Array());
        //if customer email address then return the customer address on array
        if ($this->isCustomerEmail($email)) {

            //get the customer identity number from the email provided
            $customer = $this->getCustomer($email);
            $clientID = $customer->getClientID();
            // echo "$email  ".$this->addresses->count();
            foreach ($this->addresses as $strAddress) {
                $address = unserialize($strAddress);
                if ($address->getClientID() == $clientID) {
                    //the append the address to the array
                    $customer_address->append($address);
                }//end if
            }//end for each
        }//end if

        return $customer_address;
    }

    public function deleteCustomerAddress($clientID, $AddressID) {

        if ($this->addresses->count() > 0) {
            //find the address with the same information provided above

            while ($this->addresses->valid()) {

                //get the address
                $address = unserialize($this->addresses->current());
                if ($address->getClientID() == $clientID && $address->getAddressID() == $AddressID) {
                    //delete the address
                    $this->addresses->offsetUnset($this->addresses->key());
                    //update the database file
                    $this->saveAddresses();
                    break;
                }
                //get next strAddress
                $this->addresses->next();
            }//end while statement
        }//end if statement
    }

//end function


    /* Ordering accounting methods */

    final function validatedPaymentDetails($txtNameOnCard, $txtCardNumber, $txtExpiredate, $txtSecurityNumber) {
        $email = Session::get(LOGIN_EMAIL);
        $customer = $this->getCustomer($email);
        $customerName = $customer->getFirstName() . " " . $customer->getLastName();


        if (!Validator::isPaymentNameMatched($txtNameOnCard, $customerName)) {
            throw new WebException("card_name: Card name must match the account name please!", 0, null);
        } else if (!is_integer($txtCardNumber) && strlen(trim($txtCardNumber)) <= 11) {
            throw new WebException("card_number: Invalid card number must be 12 digit exactly!", 0, null);
        } else if (!Validator::isStringDate($txtExpiredate)) {
            throw new WebException("card_number: Invalid card expire date entry please it should be mm/yyyy and valid", 0, null);
        } else if (!is_integer($txtSecurityNumber) && strlen(trim($txtSecurityNumber)) != 3) {
            throw new WebException("card_security_number:Enter a valid security card number [the last 3digit number at the back of the card]", 0, null);
        } else {
            $this->isPayment = true;
        }
    }

//end function

    final public function isPayment() {
        return $this->isPayment;
    }

    final public function addOrderItem(TOrderItem $orderItem) {
        $orderItem->validated();
        try {
            //right code here

            if ($this->isAddressExists($orderItem->getShipAddress())) {
                $this->appendOrderItem($orderItem);
            } else {
                $this->setError("error:There is problem with the shipping address");
            }
        } catch (WebException $err) {
            $this->setError($err->getMessage());
        }
    }

    final private function appendOrderItem(TOrderItem $orderItem) {
        if (!is_object($this->orders)) {
            $this->orders = new ArrayIterator(Array());
        }
        $strOrderItem = serialize($orderItem);
        $this->orders->append($strOrderItem);
        $this->saveOrders();
        $this->isOrder = true;
    }

    final private function saveOrders() {
        if ($this->db->isConnected($this->orders_tbl)) {
            $strOrder = serialize($this->orders);
            $this->db->put_file_content($strOrder);
        }
        $this->loadOrders();
    }

//end function

    private final function loadOrders() {
        if ($this->db->isConnected($this->orders_tbl)) {
            $strOrders = $this->db->get_file_content();
            //using the @ to supress the unwanted error of unserialize if their is any 
            $this->orders = @unserialize($strOrders);
        }
    }

    final public function isOrdered() {
        return $this->isOrder;
    }

    final public function getOrdersCount() {
        if (!is_object($this->orders))
            $this->orders = new ArrayIterator(Array());
        return $this->orders->count();
    }

    //return all the orders items to the users  
    final public function getCustomerOrders($customerID) {
        $temOrders = new ArrayIterator(Array());
        //check if any has orders in the order list
        if (!is_object($this->orders)) {
            $this->orders = new ArrayIterator(Array());
            return new ArrayIterator();
        }
        if ($this->orders->count() <= 0)
            return $temOrders;

        foreach ($this->orders as $strOrder) {
            //get the order object
            $order = unserialize($strOrder);
            if ($order->getCustomerID() == $customerID) {
                $temOrders->append($order);
            }
        }

        return $temOrders;
    }

    final public function isOrderNumberExists($orderNumber) {
        $isOkay = false;
        //chech if it is an object or there is no order   
        if (!is_object($this->orders) || $this->orders->count() <= 0)
            return $isOkay;

        foreach ($this->orders as $strOrder) {
            $order = unserialize($strOrder);
            if ($order->getOrderNumber() == $orderNumber) {
                $isOkay = true;
                break;
            }
        }
        return $isOkay;
    }

    final function deleteOrder($orderNumber) {
        //chech if it is an object or there is no order   
        if (!is_object($this->orders) || $this->orders->count() <= 0)
            return;
        while ($this->orders->valid()) {
            $order = unserialize($this->orders->current());
            if ($order->getOrderNumber() == $orderNumber) {
                $this->orders->offsetUnset($this->orders->key());
                $this->isDelete = true;
                $this->saveOrders();
                break;
            }

            $this->orders->next();
        }
    }

    final public function isDeleted() {
        return $this->isDelete;
    }

//administrator

    final function assignAdministrator($email) {
        if ($this->isCustomerEmail($email)) {
            $level=1;
            //create new admin
            $admin=new TAmin();
            $admin->setEmail(strtolower($email));
            $admin->setLevel($level);
            //check if the admins exist
            if(!is_object($this->admins))
            {
                $this->admins=new ArrayIterator(Array());
            }
            $this->admins->append(serialize($admin));
            $this->saveAdmins();
            $this->isAdd=true;
        }
        else
        {
            throw new WebException("Customer email does not exists please!",0,null);
        }
    }//end function
    
    
      final private function saveAdmins() {
        if ($this->db->isConnected($this->admin_tbl)) {
            $strAdmin = serialize($this->admins);
            $this->db->put_file_content($strAdmin);
        }
        $this->loadAdmins();
    }
  
     private final function loadAdmins() {
        if ($this->db->isConnected($this->admin_tbl)) {
            $strAdmins = $this->db->get_file_content();
            $this->admins = unserialize($strAdmins);
        }
    }//end 
    
    
    final function deleteAdmin($email)
    {
        if($this->isCustomerEmail($email))
        {
            //carry out administration deletions
            if($this->isAdministrator($email))
            {
                //delete the administration
                while($this->admins->valid())
                {
                    $admin=  unserialize($this->admins->current());
                    if($admin==null)
                        $admin=new TAmin();
                    if($admin->getEmail()==$email)
                    {
                        $this->admins->offsetUnset($this->admins->key());
                        $this->isDelete=true;
                        $this->saveAdmins();
                        break;
                    }
                    $this->admins->next();
                }//end while statement
            }
           else
           {
               throw new WebException("error:Oops the user is not an administrator",0,null);
           }
        }//end if
    }//end function

    
    
    final function isAdministrator($email)
    {
      $isOkay=false;
      if(!is_object($this->admins))
          $this->admins=new ArrayIterator();
     foreach($this->admins as $strAdmin)
     {
         $admin=  unserialize($strAdmin);
         if($admin==null)
             $admin=new TAmin();
         if($admin->getEmail()==  strtolower($email))
         {
             $isOkay=true;
             break;
         }
     }
     
     return $isOkay;
      
    }
    
    
    
  final public function isAddressInfoExists(TAddress $address)
  {
      $isOkay=false;      
      // Let do the main job
     
      if(!is_object($this->addresses))
      {
          $this->addresses=new ArrayIterator(Array());
          return $isOkay;
      }
     
        
      // now I have to carry of the loop checking on the address
     if($this->addresses->count()>0)
      {
        //carry out this commands only if there is address in the database
      
         foreach($this->addresses as $strAddress)
         {
              
             //suppress the serialised unwanted error with the @ statement
             $checkAddress= @unserialize($strAddress);
             if(!is_object($checkAddress))
             {
                 $checkAddress=new TAddress();
                 continue;//continue to the next loop
             }
           //check if the name,the post code and the account owner name is same
             if((strtolower($checkAddress->getPostcode())==strtolower($address->getPostcode())) && 
                     (strtolower($checkAddress->getFullName())==strtolower($address->getFullName()))                     
                     && (strtolower($checkAddress->getClientID())==  strtolower($address->getClientID())))
             {
                 $isOkay=true;
                 break;//dont continue the loop 
             }
         }
      }//end if statement
      
     
      return $isOkay;
      
  }
    
}//end class
?>
