 
    /*
     //clear the payment form
    var nameOnCard = document.getElementById("txtNameOnCard");
    var cardNumber = document.getElementById("txtCardNumber");
    var cardExpireDate = document.getElementById("txtExpiredate");
    var securityNumber = document.getElementById("txtSecurityNumber");
    
     nameOnCard.style.backgroundColor = "#FFF";
     nameOnCard.style.color = '#000';
     
     cardNumber.style.backgroundColor = "#FFF";
     cardNumber.style.color = '#000';
     
     cardExpireDate .style.backgroundColor = "#FFF";
     cardExpireDate .style.color = '#000';
     
     securityNumber.style.backgroundColor = "#FFF";
     securityNumber.style.color = '#000';
    
    
function clearCategory()
{
 var catname=document.getElementById("txtcategoryname");
var desc=document.getElementById("txtacategorykeyords"); 
  catname.style.color="#000";
  catname.style.backgroundColor="#FFF";
  
   desc.style.color="#000";
  desc.style.backgroundColor="#FFF";
}

function isEmpty(value)
{
  var isOkay=false;

  if(value ==null || value=="")
      {
          isOkay=true;
      }
   return isOkay;
}

   
   */
