//Most of the javascript function are re-useable code from my previous access
//at http://soc.uwl.ac.uk/~21187498/

//clear all js script error when the page loads

function clearError()
{

    errortag = document.getElementById("divErrorTag");
    errortag.style.display = "none";
    //clear login errors
    var e_email = document.getElementById("txtLEmail");
    var e_passowrd = document.getElementById("txtLPassword");

    e_email.style.backgroundColor = "#FFF";
    e_email.style.color = '#000';
    e_passowrd.style.backgroundColor = "#FFF";
    e_passowrd.style.color = '#000';
    //clear registration errors
    var r_email = document.getElementById("txtCEmail");
    var r_firstname = document.getElementById("txtCFirstName");
    var r_lastname = document.getElementById("txtCLastName");
    var r_phoneNumber = document.getElementById("txtCMobilePhone");
    var r_password = document.getElementById("txtCPassword");
    var r_re_password = document.getElementById("txtCRPassword");

    r_email.style.backgroundColor = "#FFF";
    r_email.style.color = '#000';
    r_firstname.style.backgroundColor = "#FFF";
    r_firstname.style.color = '#000';
    r_lastname.style.backgroundColor = "#FFF";
    r_lastname.style.color = '#000';
    r_phoneNumber.style.backgroundColor = "#FFF";
    r_phoneNumber.style.color = '#000';
    r_password.style.backgroundColor = "#FFF";
    r_password.style.color = '#000';
    r_re_password.style.backgroundColor = "#FFF";
    r_re_password.style.color = '#000';


}//end if



function clearPaymentField()
{
    //clear the payment form
    var nameOnCard = document.getElementById("txtNameOnCard");
    var cardNumber = document.getElementById("txtCardNumber");
    var cardExpireDate = document.getElementById("txtExpiredate");
    var securityNumber = document.getElementById("txtSecurityNumber");

    nameOnCard.style.backgroundColor = "#FFF";
    nameOnCard.style.color = '#000';

    cardNumber.style.backgroundColor = "#FFF";
    cardNumber.style.color = '#000';

    cardExpireDate.style.backgroundColor = "#FFF";
    cardExpireDate.style.color = '#000';

    securityNumber.style.backgroundColor = "#FFF";
    securityNumber.style.color = '#000';
}

function clearShipAddressFields()
{
    //cear the address error fields   

    var fullname = document.getElementById("txtSFullname");
    var address1 = document.getElementById("txtSAddress1");
    var address2 = document.getElementById("txtSAddress2");
    var postcode = document.getElementById("txtSPostcode");
    var country = document.getElementById("txtSCountry");
    var county = document.getElementById("txtSState");
    var town = document.getElementById("txtPSTown");

    fullname.style.backgroundColor = "#FFF";
    fullname.style.color = '#000';

    address1.style.backgroundColor = "#FFF";
    address1.style.color = '#000';

    address2.style.backgroundColor = "#FFF";
    address2.style.color = '#000';

    postcode.style.backgroundColor = "#FFF";
    postcode.style.color = '#000';

    country.style.backgroundColor = "#FFF";
    country.style.color = '#000';

    county.style.backgroundColor = "#FFF";
    county.style.color = '#000';
    town.style.backgroundColor = "#FFF";
    town.style.color = '#000';
}
//This function is call to check the email address
function isEmail(value)
{
    var ok = false;
    //Emaill address regular expression pattern 
    var pattern = /^[(^[a-zA-Z\_){1,4}a-zA-Z0-9\_\.]+@[a-zA-Z\.0-9]+\.[a-zA-Z0-9]{2,3}$/;
    //test if the email field value match the pattern required
    if (pattern.test(value))
    {
        ok = true;
        return ok;//yes return true
    }
    else
    {
        ok = false;
        return ok;//no from5 the test then  return false
    }//end else brace
}
;//end function
//This funcion check is a value is a address
function isAddress(value)
{
    var ok = false;

    var pattern = /^[ a-zA-Z,\.0-9]{3,}[ A-Za-z0-9\.]+$/;
    if (pattern.test(value))
    {
        ok = true;
    }

    return ok;
}
//This function check the credit card expiring date of the format mm/yyyy
function isDate(dateObj)
{
    var isOkay = false;
    var dateFormat = /^[0-9]{1,2}\/[0-9]{4}$/; //regular express for date value
    if (dateFormat.test(dateObj))//the require date format is inputted ?
    {


        var s_month = parseInt(dateObj.split("/")[0]);//get day value from the second /
        var s_year = parseInt(dateObj.split("/")[1]);//get day value from the thrid

        if (isNumeric(s_month) && isNumeric(s_year))
        {
            //check if the year is future
            var now = new Date();
            if (s_year > now.getFullYear())
                isOkay = true;
        }


    }
    return isOkay;
}//end isDate

//This is a re-usable code from my previous element1a
function setError(msg, element)
{

    errortag = document.getElementById("divErrorTag");
    errortag.innerHTML = msg;
    element.style.backgroundColor = '#FF7373';
    element.style.color = '#FFF';
    element.focus();
    errortag.style.backgroundColor = '#FFFFCC';
    errortag.style.position = 'relative';
    errortag.style.border = '2px solid #FF0000';
    errortag.style.color = '#000';
    errortag.style.zIndex = 3;
    errortag.style.margin = '4px';
    errortag.style.padding = '4px';
    errortag.style.display = 'block';
    errortag.style.borderRadius = '5px'; // standard
    errortag.style.MozBorderRadius = '5px'; // Mozilla
    errortag.style.WebkitBorderRadius = '5px'; // WebKit
    errortag.style.textAlign = 'center';
    //get the next two elements
    previousE = element.previousSibling;
    previousE2 = previousE.previousSibling;
    element.parentNode.insertBefore(errortag, previousE2);

}




function isName(value)
{
    var pattern = /^[a-zA-Z ]+[a-zA-Z0-9 & \\ \_]+$/;
    //test if the email field value match the pattern required
    if (pattern.test(value))
    {
        return true;//yes return true
    }
    else
    {
        return false;//no from the test then  return false
    }//end else brace
}
;

function isPhoneNumber(value)
{
    $pattern = /^[0-9\.]{11,15}$/;
    if ($pattern.test(value)) {
        return true;
    }
    return false;
}

function isPostcode(postcode) {

    //UK post validator
    var pattern = /^[a-zA-Z]{2}[ ]{0,1}[0-9]{1,2}[ ]{0,1}[A-Za-z0-9]+$/;
    if (pattern.test(postcode)) {
        return true;
    }
    return false;
}
function isNumeric(value)
{
    if (isNaN(parseFloat(value)) || !isFinite(value))
        return false;
    return true;
}
function isEmpty(pString) {
    if (!pString || pString.length == 0) {
        return true;
    }
    return !/[^\s]+/.test(pString);
}
//This function is call to test if an object is an integer value
function isInteger(value)
{
    var isOkay = false;
    if (typeof value === 'number' || (value % 1) === 0) {
        isOkay = true;
    }   
    return isOkay;
}


//This function is call when the user wanted to login
function userLogin()
{
    clearError();
    var isOkay = false;
    var e_email = document.getElementById("txtLEmail");
    var e_passowrd = document.getElementById("txtLPassword");


    if (e_email.value == "" || !isEmail(e_email.value))
    {
        setError("Please enter a valid email address", e_email);
        isOkay = false;


    }
    else if (e_passowrd.value == "")
    {
        setError("Please enter a valid email address", e_passowrd);
        isOkay = false;
        ;
    }
    else
    {
        isOkay = true;
    }

    return isOkay;
}//end login

//This function is call to validated the createAccount Input fields
function createAccount()
{
    //set the flag to false 
    var isOkay = false;
    clearError();
    //get the html tag object
    var email = document.getElementById("txtCEmail");
    var firstname = document.getElementById("txtCFirstName");
    var lastname = document.getElementById("txtCLastName");
    var phoneNumber = document.getElementById("txtCMobilePhone");
    var password = document.getElementById("txtCPassword");
    var re_password = document.getElementById("txtCRPassword");
    var agree = document.getElementById("terms");

    //alert(password.value);
    //verify and validated the user input
    if (!isEmail(email.value))
    {
        setError("Enter a valid email address please!", email);
        isOkay = false;
    }
    else if (!isName(firstname.value))
    {
        setError("Enter a valid human name please! e.g John", firstname);
        isOkay = false;
    }
    else if (!isName(lastname.value))
    {
        setError("Enter a valid human being name please! e.h Steve", lastname);
        isOkay = false;
    }
    else if (!isPhoneNumber(phoneNumber.value))
    {
        setError("Enter a valid phone number please!", phoneNumber);
        isOkay = false;
    }
    else if ((password.value).length <= 6 || password.value == null)
    {
        setError("Enter a valid password and must be more than 6 characters", password);
        isOkay = false;
    }
    else if (password.value !== re_password.value)
    {
        setError("The Password you re-enter did not match the previous one please enter them again!", re_password);
        isOkay = false;
    }
    else if (!agree.checked)
    {
        setError("Hey , please you must agree to the term and condition of the site", email);
        isOkay = false;
    }
    else
    {
        isOkay = true;
    }

    return isOkay;

}

//this function is call to validate payment

function makePayment()
{
    var isOkay = false;
    //get customer card details
    //
    clearPaymentField();
    var nameOnCard = document.getElementById("txtNameOnCard");
    var cardNumber = document.getElementById("txtCardNumber");
    var cardExpireDate = document.getElementById("txtExpiredate");
    var securityNumber = document.getElementById("txtSecurityNumber");
    var lenSecurity = Number(securityNumber.value.length);
    if (!isName(nameOnCard.value))
    {
        setError("Enter the name that is display on card e.g Dice Alen", nameOnCard);
        isOkay = false;
    }
    else if (cardNumber.value.length < 12 || cardNumber.value == null)
    {
        setError("Enter a valid debit/credit card number please!", cardNumber);
        isOkay = false;
    }
    else if (!isDate(cardExpireDate.value))
    {
        setError("Enter card expire date mm/yyyy only please!", cardExpireDate);
        isOkay = false;
    }
    else if (!isNumeric((securityNumber.value) || lenSecurity !== 3))
    {
        setError("Enter a valid debit/credit card security number it's the last 3digit only please!", securityNumber);
        isOkay = false;
    }
    else
    {
        isOkay = true;
    }

    //varify user fields


    return isOkay;
}


//This function is called when the user is about to add Shipping Address 
function addShippingAddress()
{
    clearShipAddressFields();
    var isOkay = false;

    var fullname = document.getElementById("txtSFullname");
    var address1 = document.getElementById("txtSAddress1");
    var address2 = document.getElementById("txtSAddress2");
    var postcode = document.getElementById("txtSPostcode");
    var country = document.getElementById("txtSCountry");
    var county = document.getElementById("txtSState");
    var town = document.getElementById("txtPSTown");

    if (!isName(fullname.value))
    {
        setError("Please enter reciever's full name", fullname);
    }
    else if (!isAddress(address1.value))
    {
        setError("Please! enter a valid address1 e.g 10 diamond court", address1);
    }
    else if (!isAddress(address2.value))
    {
        setError("Please! enter a valid address2 e.g street name[cherington road]", address2);
    }
    else if (!isPostcode(postcode.value))
    {
        setError("Please! enter a valid UK format postcode address or number", postcode);
    }
    else if (!isName(country.value))
    {
        setError("Please! enter a valid name of reciever's country of resident e.g UK", country);
    }
    else if (!isName(county.value))
    {
        setError("Please! enter a valid reciever's county or state e.g London", county);
    }
    else if (!isName(town.value))
    {
        setError("Please! enter a valid reciever's town", town);
    }

    else
    {
        isOkay = true;
    }


    return isOkay;
}//end address function end here


//This function clears all the javascript generated error of the category
function clearCategory()
{
    var catname = document.getElementById("txtcategoryname");
    var desc = document.getElementById("txtacategorykeyords");
    catname.style.color = "#000";
    catname.style.backgroundColor = "#FFF";
    desc.style.color = "#000";
    desc.style.backgroundColor = "#FFF";
}


//This function is call when the user is about to addCategory

function addCategory()
{

    var isOkay = false;
    clearCategory();
   
    var catname = document.getElementById("txtcategoryname");
    var desc = document.getElementById("txtacategorykeyords");

    if (!isName(catname.value))
    {
    setError("Enter a valid category name please!", catname);
    }
    else if (isEmpty(desc.value))
    {
        setError("Enter category keywords for searching the category items please, make such you seperate by comman [,]",catname);
    }
    else
    {
        isOkay = true;
    }
    return isOkay;
}


function clearAddItemFields()
{
    var category = document.getElementById("itemCategory");
    var itemName = document.getElementById("txtItemName");
    var ItemPrice = document.getElementById("txtItemPrice");
    var itemNumberToStock = document.getElementById("txtItemStockNumber");
    var itemDescription = document.getElementById("txtItemDesc");

    category.style.color= "#000";
    category.style.backgroundColor ="#FFF";
    ItemPrice.style.color = "#000";
    ItemPrice.style.backgroundColor = "#FFF";
    itemNumberToStock.style.color = "#000";
    itemNumberToStock.style.backgroundColor = "#FFF";
    itemDescription.style.color = "#000";
    itemDescription.style.backgroundColor = "#FFF";
    itemName.style.color = "#000";
    itemName.style.backgroundColor = "#FFF";


}

function addItemValidator()
{

    var isOkay = false;
    //check the field document
    clearAddItemFields();
    var category = document.getElementById("itemCategory");
    var itemName = document.getElementById("txtItemName");
    var ItemPrice = document.getElementById("txtItemPrice");
    var itemNumberToStock = document.getElementById("txtItemStockNumber");
    var itemDescription = document.getElementById("txtItemDesc");
    //alert(ItemPrice.value)

    //validate the fields

    if (isEmpty(category.value))
    {
        setError("please select item category!", category);
    }
    else if (!isName(itemName.value))
    {
        setError("Please enter a valid item name", itemName);
    }
  else if(isEmpty(ItemPrice.value) || !isNumeric(ItemPrice.value) || Number(ItemPrice.value)<=0)
      {
         setError("Enter the item price please!", ItemPrice); 
      }   
    else if(isEmpty(itemNumberToStock.value) || !isInteger(itemNumberToStock.value))
    {
        setError("Please enter a valid number of item to stock and most be a positive integer only.", itemNumberToStock);
    }
    else if (isEmpty(itemDescription.value))
    {
        setError("Kindly describe this items please! there is a textarea provided below", itemName);
    }
    else
    {
        isOkay = true;
    }


    return isOkay;
}



function displayItemValidator()
{
    var isOkay=false;
    var category=document.getElementById("itemCategoryListDisplay");
    if(isEmpty(category.value))
        {
          setError("Select category items to display",category);   
        }
    else
        {
           category.style.backgroundColor="#FFF";
           category.style.color="#000";
            isOkay=true;
        }
    
    return isOkay;
}


