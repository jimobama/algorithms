<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Administrator
 *
 * @author jimobama
 */

class TAmin extends Object{
   private $level;
   private $email;
   
   public function __construct() {
      $this->level=null;
      $this->email=null;
   }
   
   function setEmail($email)
   {
       if(!Validator::isEmail($email))
       {
           throw new WebException("Enter administrator valid email!",0,null);
       }
       $this->email=$email;
   }
   final function getEmail()
   {
       return $this->email;
   }
   public final function setLevel($level)
   {
       if(!is_integer($level))
       {
           throw new WebException("Administrator level field is required please!",0,null);
       }
      $this->level=$level;
   }
   final public function getLevel()
   {
       return $this->level;
   }
   
  final public function validated()
   {
      parent::validated();//call the parent validator 
      try {
        $this->setLevel($this->getLevel());
       }
       catch(WebException $err)
       {
           throw  $err;
       }
      
       
       
   }

    public function toString() {
        
    }
  
  
    
}//end 

?>
