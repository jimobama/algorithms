<?php
/*
 * 
 * This file iostream wrappers PHP file operations method into class
 * Author Name: Jimotech
 */
class IO
{
    const WriteOnly='w';
    const ReadOnly='r' ;
    const WriteAndRead='w+';
    const Append='a';
}

class IOStream {
    
   
   private $filename=null;
   private $handle=null;
   
   public function __construct()
   {
      $this->filename="";
   }
   //staic 
  public function isConnected($file)
  {
      if(!file_exists($file))
       {
          self::isOpen($file,IO::WriteOnly);
          $this->filename=$file;
          self::close();  
       }
      $this->filename=$file;
      return true;
  }
   public static function IO($filename,$mode) 
   {
       $instance= new Self();
       $instance->open($filename,$mode); 
       return  $instance;
   }//end constructor
 
   public function isOpen($file,$mode)
   {     
       $this->handle = fopen($file,$mode);
       $this->filename=$file;       
      return true;     
   }//end function
 
   public function write($string)
   {
      if($this->handle==null){
          echo  $this->filename;
          return false;
      }
       fwrite($this->handle, $string);
       return true;
   }
   
  function put_file_content($string)
   {
      if($this->filename!=null)
      {
         
      file_put_contents($this->filename,$string);
      return true;
      }
      return false;
   }
  function get_file_content()
   {
      if($this->filename!=null)
      {
       return file_get_contents($this->filename);      
      }
      return null;
   } 
  
  public function close()
  {
     if($this->handle==null) 
     {
         return ;
     }
      fclose($this->handle);
  }
 
}//end class

?>
