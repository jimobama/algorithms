<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Model
 *
 * @author jimobama
 */
 class Model extends Object{
    
   public function __construct() {
     
  }
     public function toString() {
        
     }

    public function validated() {
        
    }
}

?>
