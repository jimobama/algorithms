<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TAddress
 *
 * @author jimobama
 */
class TAddress extends Object {

    //put your code here

    private $addressID;
    private $clientID;
    private $fullname;
    private $country;
  
    private $state;
    private $county;
    private $address1;
    private $address2;
    private $postcode;

    public function __construct() {
        $this->addressID = null;
        $this->clientID = null;
        $this->fullname = null;
        $this->country = null;
        $this->state = null;
        $this->county = null;
        $this->address1 = null;
        $this->address2 = null;
        $this->postcode = null;
       
    }
    
 

    final function setPostcode($postcode) {
        if (!Validator::isPostcode($postcode)) {
            throw new WebException("address_post:Enter a valid receiver's UK post address please!", 0, null);
        }
        $this->postcode = $postcode;
    }

    final function getPostcode() {
        return $this->postcode;
    }

    final function setState($state) {
        if (!is_string($state) || trim($state) == "") {
            throw new WebException("address_state:Enter a valid receiver's state please!", 0, null);
        }
        $this->state = $state;
    }

    final function getState() {
        return $this->state;
    }

    final function setCounty($county) {
        if (!is_string($county) || trim($county) == "") {
            throw new WebException("address_county:Enter a valid receiver's county please!", 0, null);
        }
        $this->county = $county;
    }

    final function getCounty() {
        return $this->county;
    }

    final function setCountry($country) {
        if (!is_string($country) || trim($country) == "") {
            throw new WebException("address_country:Enter a valid receiver's country please!", 0, null);
        }
        $this->country = $country;
    }

    final function getCountry() {
        return $this->country;
    }

    final function setAddress1($address1) {
        if (!is_string($address1) || trim($address1) == "") {
            throw new WebException("address1:Enter address1 of reciever please! [ the house name and number]",0,null);
        }
        $this->address1 = $address1;
    }

    final function getAddress1() {
        return $this->address1;
    }

    final function setAddress2($address2) {
        if (!is_string($address2) || trim($address2) == "") {
            throw new WebException("address_2:Enter address2 of reciever please! [the street name or road name]",0,null);
        }
        $this->address2 = $address2;
    }

    final function getAddress2() {
        return $this->address2;
    }

    final function setFullName($fullname) {
        if (!is_string($fullname) || strlen(trim($fullname)) < 3) {
            throw new WebException("address_fullname:Enter a valid receiver's fullname please!",0,null);
        }
        $this->fullname = $fullname;
    }

    final function getFullName() {
        return $this->fullname;
    }

    final function setAddressID($id) {
        if (!is_string($id) || trim($id) == "") {
            throw new WebException("address_id:Hey please set address indentity number", 0, null);
        }
        $this->addressID = $id;
    }

    final function getAddressID() {
        return $this->addressID;
    }

    final function setClientID($clientID) {
        if (!is_string($clientID) || trim($clientID) == "") {
            throw new WebException("client_id:Please set member's email please", 0, null);
        }
        $this->clientID = $clientID;
    }

    final function getClientID() {
        return $this->clientID;
    }

    public function toString() {
        
    }

    public function validated() {

        try {
            $this->setClientID($this->getClientID());
            $this->setAddressID($this->getAddressID());
            $this->setFullName($this->getFullName());
            $this->setCountry($this->getCountry());
            $this->setState($this->getState());
            $this->setCounty($this->getCounty());
            $this->setAddress1($this->getAddress1());
            $this->setAddress2($this->getAddress2());
            $this->setPostcode($this->getPostcode());            
        } catch (WebException $err) {
            throw $err;
        }
    }

}

?>
