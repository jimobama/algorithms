<?php



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TBasketItem
 *
 * @author jimobama
 */
class TOrderItem extends Object {

    private $numberOfItems;
    private $price;
    private $total;
    private $date;
    private $customerID;
    private $itemNumber;
    private $orderNumber;
    private $shipAddressId;
    private $cardNumber;
    private $status;
    private $vat;
  

    public function __construct() {
        $this->customerID = null;
        $this->date = null;
        $this->numberOfItems = null;
        $this->price = null;
        $this->total = null;
        $this->shipAddressId=null;
        $this->cardNumber=null;
        $this->customerID=null;
        $this->status=false;
    }
    
    
  final function getVAT()
  {
      return $this->vat;
  }
    
    
  
  
    final function setStatus($bool)
    {
        if(!is_bool($bool))
        {
             throw new WebException("error:order status can only take boolean value!", 0, null);
        }
        $this->status=$bool;
    }
final function getStatus()
{
    return $this->status;
}
     final public function setPaymentCardNumber($number) {
        if (strlen(strval(trim($number))) < 3 || trim($number) == "") {
            throw new WebException("error:Set payment card number please!", 0, null);
        }
        $this->cardNumber = $number;
    }

    final public function getPaymentCardNumber() {
        return $this->cardNumber;
    }
    
    
      final public function setShipAddress($addressnumber) {
        if (!is_string($addressnumber) || trim($addressnumber) == "") {
            throw new WebException("error:Set shipping adddress number please!", 0, null);
        }
        $this->shipAddressId= $addressnumber;
    }

    final public function getShipAddress() {
        return $this->shipAddressId;
    }
    
    
    final public function setOrderNumber($ordernumber) {
        if (!is_string($ordernumber) || trim($ordernumber) == "") {
            throw new WebException("error:Set order number please!", 0, null);
        }
        $this->orderNumber = $ordernumber;
    }

    final public function getOrderNumber() {
        return $this->orderNumber;
    }
    

    final public function setItemNumber($number) {
        
        if (!is_string($number) || is_null($number) ) {
            throw new WebException("error: Item Identity number must be set please! ", 0, null);
        }

        $this->itemNumber = $number;
    }

    final public function getItemNumber() {
        return $this->itemNumber;
    }

    final public function setCustomerID($customerID) {
        if (!is_String($customerID) || is_null($customerID) || trim($customerID) == "") {
            throw new WebException("error:set current customer identity number!", 0, null);
        }
        $this->customerID = $customerID;
    }

    final public function getCustomerID() {
        return $this->customerID;
    }

    final public function setPrice($amount) {
        if (!is_double($amount)) {
            throw new WebException("error:Enter the current amountof item", 0, null);
        }
        $this->price = $amount;
    }

    final function getPrice() {
        return $this->price;
    }

    final public function getTotalPrice() {
        $price = (double) $this->price;
        $nItems = (int) $this->numberOfItems;
        $total = $price * $nItems;
        $this->vat=0.0;
        return $total;
    }

    final function setNumberOfItems($number) {
        if (!is_integer($number) || intval($number)==0) {
            throw new WebException("error:Enter the number of items to purchase please!", 0, null);
        }
        $this->numberOfItems = $number;
    }

    final function getNumberOfItems() {
        return $this->numberOfItems;
    }

    final function setDate($date) {
        //$date=date_parse($date);
        $this->date = $date;
    }

    
    final function getDate() {
       
        return $this->date;
    }

    public function toString() {
        
    }

    public function validated() {
        
        try
        {
            $this->setCustomerID($this->getCustomerID());
            $this->setDate($this->getDate());
            $this->setItemNumber($this->getItemNumber());
            $this->setNumberOfItems($this->getNumberOfItems());
            $this->setPaymentCardNumber($this->getPaymentCardNumber());
            $this->setOrderNumber($this->getOrderNumber());
            $this->setPrice($this->getPrice());
            $this->getShipAddress($this->getShipAddress());
            
        }
       catch(WebException $err)
       {
           throw $err;
       }
   
    }//end function

    //put your code here
}

?>
