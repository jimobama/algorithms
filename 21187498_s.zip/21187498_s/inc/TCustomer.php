<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TCustomer
 *
 * @author jimobama
 */
class TCustomer extends Object{
    //put your code here
    private $firstname;
    private $lastname;
    private $email;
    private $phone;
    private $clientID;
    private $password;
    
   public function __construct() {
      $this->firstname=null;
      $this->lastname=null;
      $this->email=null;
      $this->phone=null;
      $this->password=null;
      $this->clientID=null;
    }
    final public function set($clientID,$firstname,$lastname,$email,$phone)
    {
      $this->setClientID($clientID);
      $this->setEmail($email);
      $this->setFirstName($firstname);  
      $this->setLastName($lastname);    
      $this->setPhoneNumber($phone);     
      
    }
    
   final function setPassword($password)
   {
       if(strlen($password)<6 || trim($password)=="" )
       {
           throw new WebException("password:Please enter a very strong password which is  more than 6 characters and must be a combination of characters",0,null);
       }
       $this->password= addslashes($password);
   }
   final function setFirstName($firstname)
   {
       if(!is_string($firstname) || !Validator::isWord($firstname))
       {
           throw new WebException("firstname:Enter valid name for lastname field please!",0,null);
       }
       $this->firstname=addslashes($firstname);
   }
   
   final function setLastName($lastname)
   {
       if(!is_string($lastname) || !Validator::isWord($lastname))
       {
           throw new WebException("lastname:Enter valid name for lastname field please!",0,null);
       }
       $this->lastname=addslashes($lastname);
   }
  final function setClientID($clientID)
  {
      if(!is_string($clientID) || trim($clientID)=="" )
      {
          throw new WebException("Hey are you try to voilent primary key rule, please enter a valid client ID",0,null);
      }
      $this->clientID=addslashes($clientID);
  }
  final function setEmail($email)
  {
      if(!is_string($email) || !Validator::isEmail($email))
      {
          throw new WebException("email:Enter a valid email address please! for example someone@domain.com",0,null);
      }
      $this->email= addslashes((trim($email)));
  }
  
  final public function setPhoneNumber($phoneNumber)
  {
     if(!Validator::isNumber($phoneNumber))
     {
         throw new WebException("phone:Enter a valid phone number please! [0776655223]",0,null);
     }
      $this->phone=  addslashes($phoneNumber);
  }
//getter 
  final public function getClientID()
  {
      return stripslashes($this->clientID);
  }
  
  final public function getFirstName()
  {
      return stripslashes($this->firstname);
  }
  
 final public function getLastName()
 {
     return stripslashes($this->lastname);
 }
 
 final public function getPhoneNumber()
 {
   return stripslashes($this->phone);  
 }
final public function getEmail()
{
    return $this->email;
}

final function getPassword()
{
    return $this->password;
}
    public function toString() {
        
    }

    public function validated() {
       
        try
        {
            $this->set($this->getClientID(), $this->getFirstName(),$this->getLastName(),$this->getEmail(), $this->getPhoneNumber());
            $this->setPassword($this->getPassword());
            
        }
        catch(WebException $err)
        {
            throw $err;
         }
    }
    
}

?>
