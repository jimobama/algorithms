<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TObjects
 *
 * @author jimobama
 * what to make such that all my objects have the following methods
 */
abstract class Object {
    const INVALID_PAGE_ERROR="page_error_404";
    private $error=null;
    static public function  PageNotFound()
    {
      $msg="This page you are requesting did not exists ";
      return $msg;
    }
    abstract function __construct();  
   function __destruct()
    {
        
    }
    abstract function toString();
 protected function setError($err)
  {   if(trim($err)=="")
      return null;
      $this->error=$err;
  }
 public function getError()
  {
      return $this->error;
  }
 
  abstract  function validated();
  
}

?>
