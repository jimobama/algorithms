<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ItemCategory
 *
 * @author jimobama
 */
class ItemCategory extends Object {

    const KEYWORDS = "keywords";
    const CATEGORY = "category_number";

    private $name;
    private $number;
    private $keywords;

    public function __construct() {
        $this->name = null;
        $this->number = null;
        $this->keywords = null;
    }

    final function setNumber($number) {
        if (trim($number) == "" || is_null($number) || !is_string($number)) {
            throw new  WebException("category_number:category required identity number please!", 0, null);
        }
        $this->number = $number;
    }

    final function getNumber() {
        return $this->number;
    }

    final function setKeywords($keywords) {

      
             if (is_null($keywords) ||trim($keywords) == "" || !is_string($keywords)) {
                throw new  WebException("category_keywords: keywords field must be set for atleast one item and it should not be a number please", 0, null);
             }
           
            $this->keywords=$keywords;
                  
    }

    final function getKeywords() {
        return $this->keywords;
    }

    final function getName() {
        return $this->name;
    }

    final function setName($name) {
        if (trim($name) == "" || is_null($name) || !is_string($name)) {
            throw new  WebException("category_name:category name field must be a string value and should not empty or null ", 0, null);
        }
        $this->name = $name;
    }

    final public function validated() {
        //try to send the value again
        $this->setNumber($this->number);
        $this->setName($this->getName());
        $this->setKeywords($this->getKeywords());

        return true;
    }

    public function toString() {
        
    }

}

?>
