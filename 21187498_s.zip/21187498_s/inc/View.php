<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of View
 *
 * @author jimobama
 */
class View extends Object {

    private $model;

    public function __construct() {
        $this->model = new Model();
    }

    public function __destruct() {
        
    }

    public function toString() {
        
    }

//put your code here

    public function setModel(Model $model) {
        $this->model = $model;
    }

    public function render($page = "") {

        //if no page is passed or if the page does not exist
        $pagePath = "view/" . $page . ".php";

        if ($page != "" && file_exists($pagePath)) {

            $this->header();
            require_once $pagePath;
            require_once("view/footer.html");
        } else {
            require_once("view/header.html");
            echo ("<h2>Error 404: Page not found</h2>");
            require_once("view/footer.html");
        }
    }

    private function header() {
        echo ("
            <!doctype html>
            <html lang='en'>
            <!-- The header tag start here -->
            <head>
               <title>:Store </title>
               <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
               <script type='text/javascript' src='" . URL . "public/js/login.js'></script>
              <link rel='stylesheet'type='text/css' href='" . URL . "public/css/default.css'>
              <!--CSS used Google fonts  -->        
              <link href='http://fonts.googleapis.com/css?family=Plaster&subset=latin-ext' rel='stylesheet' type='text/css'>
              <link href='http://fonts.googleapis.com/css?family=Oranienbaum' rel='stylesheet' type='text/css'>
           </head>
          <body onload='return clearError();'>

            <div id='wrapper'>
            <header>");
        require_once("view/topLink.html");
        echo("<div id='header'><a href='" . URL . "?url=cart'>
                    <div><h1 id='companyname'>Fast Sale</h1>
                        <img src='public/image/logo.jpg' alt='Money Manager' width='50' height='50'> 
                    </div>
                    </a>

          ");

        require_once("view/search.html");

        echo "   </div>
             </header>";
        //staements here
        $this->menu();
        $universal_error = (Session::get(UNIVERSAL_REQUEST_ERROR) != "") ? Session::get(UNIVERSAL_REQUEST_ERROR) : null;
        if ($universal_error != null) {
            echo "<div id='universal-error'>$universal_error</div>";
        }

        echo("<div id='divErrorTag'></div>           
            <div id= 'content'>          

            <div id='content-right'>");
    }

//end header

    private function menu() {
        $basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
        if ($basket == null)
            $basket = new ArrayIterator(Array());

        //get the number of items in the basket   
        $numberOfBasketItems = $basket->count();

        $menuBar = new ArrayIterator(Array("store" => "Home",
            "basket" => "My Troller($numberOfBasketItems)",
            "account" => "My Account"));

        echo "<div id='main_menu'><ul>";
        foreach ($menuBar as $key => $menu) {
            switch ($key) {
                case 'account': {
                        echo "<li><a>My Account</a>";
                        echo("<ul> 
             <li><a href='" . URL . "?url=cart/xhsMyOrders/&$key=$key'>My Orders</a>             
              ");
                        if (Session::get(LOGIN) == true) {
                            if (Session::get(IS_ADMINISTRATOR) == true) {
                                echo "<li><a href='" . URL . "?url=member/xhsStockPageSwitch/&page=addcategory&$key=$key'>Admin Panel</a></li>";
                            }

                            echo "<li><a href='" . URL . "?url=member/xhsLogOut/&$key=$key'>Log Out</a></li>";
                        }

                        echo "</li></ul>";
                    }break;
                case 'basket': {
                        echo (" <li><a href='" . URL . "?url=cart/xhsTrollerDisplay/&$key=$key'>$menu</a></li> ");
                    }break;
                case 'store': {
                        echo " <li><a href='" . URL . "?>?url=cart/xhsRandomItemDisplay/&$key=$key'>$menu</a></li>  ";
                    }break;
                default:
                    break;
            }//end switch 
        }//end foreach
        echo "</ul></div>";
    }

//end menu
//end 

    public function validated() {
        
    }

}
?>
