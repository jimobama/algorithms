<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of JimoTechShopingWebSite
 *
 * @author jimobama
 */
class WebApp extends Object {

    private $current_controller = null;
    private $file="";
    private $page="";
    private $method="";
    final private function __clone() {
        
    }

    function __construct() {

        //get the url
        $url = isset($_REQUEST["url"]) ? $_REQUEST["url"] : null;
        //There is a controller passed
        if ($url != null) {
            //now we have to take the first parameter to make such it is not a folder
            $url = rtrim($url, "/");
            //split the url to arrays
            $urls = explode("/", $url);
            $controller = ucfirst($urls[0]);
            $file = "controller/" . $controller . ".php";
          
            if (is_file($file) || file_exists($file)) {
                  
                $this->current_controller = $controller;
                $this->setRequestFile($file); //set the requested file
                //check if the previous requested page is the same with the current now
                $previous_page=Session::get("PREVIOUS_PAGE");
                $current_page=Session::get("CURRENT_PAGE");
                //set the method
                if(isset($urls[1]))
                {
                   $this->method=$urls[1];
                }
                 
                if( $current_page == $controller)
                  {
                    Session::set("PREVIOUS_PAGE",$previous_page);
                    Session::set("CURRENT_PAGE",$controller);
                  }
                else
                {
                    Session::set("PREVIOUS_PAGE",Session::get("CURRENT_PAGE"));
                    Session::set("CURRENT_PAGE",$controller);
                }
                               
                
                return;
            }//end if file
            else {
                $this->current_controller = null;
            }
        }//end if
    }

//end constructor

    private function setRequestFile($file) {
        $this->file = $file;
    }

    public function __destruct() {
        
    }

    public function toString() {
        
    }

//put your code here


    public function exec() {
       $this->trackBasket();//track the user and set the basket cookies
       $this->loadCookies();
     //  $this->deleteCookies();
        if ($this->file != null) {
            require_once $this->file;

            //check if the class exit
            if (class_exists($this->current_controller)) {
                
                require_once $this->file;                
                 $controller=new $this->current_controller;            
                   //call the controller function dynamically     
                 if(method_exists($controller, $this->method))
                 {
                    $method=$this->method;
                    $controller->$method(); 
                 }
                        
                 $controller->update();
            } else {
                
            }
        }//end file exist
     else
     {
        //relocate it to this 
         header("Location:".URL."?url=cart/xhsRandomItemDisplay");
         exit();
          
     }
        
        
    }
private function trackBasket()
{
    if(Session::get(CART_BASKET)!="")
    {
    $expireTime=time() + 60*60*24*30; 
    $strBasket=serialize(Session::get(CART_BASKET));
    setcookie(BASKET_COOKIES,$strBasket, $expireTime);   
    }
  

}
private function loadCookies()
{
   if(Session::get(CART_BASKET)==""){
       if(isset($_COOKIE[BASKET_COOKIES])){
       $basket= unserialize($_COOKIE[BASKET_COOKIES]);
       Session::set(CART_BASKET,$basket);
       }
   }
      
         
}



   public function validated() {
        
    }//end exec
    
    
}//class



?>
