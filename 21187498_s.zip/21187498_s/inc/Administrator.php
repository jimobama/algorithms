<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Administrator
 *
 * @author jimobama
 */

class Administrator extends TCustomer {
   private $level;
   private $customer;
   
   public function __construct() {
       parent::__construct();
   }
   public final function setLevel($level)
   {
       if(!is_integer($level))
       {
           throw new WebException("Administrator level field is required please!",0,null);
       }
      $this->level=$level;
   }
   final public function getLevel()
   {
       return $this->level;
   }
   
  final public function validated()
   {
      parent::validated();//call the parent validator 
      try {
        $this->setLevel($this->getLevel());
       }
       catch(WebException $err)
       {
           throw  $err;
       }
      
       
       
   }
  
  
    
}//end 

?>
