<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Controller
 *
 * @author jimobama
 */
abstract class Controller extends Object{
    
    protected $view;   
    protected $page;
    protected $model;
    public function __construct()
    {
        $this->view=new View();
        $this->model=new Model();        
        
    }

    public function __destruct() {
        
    }

    public function toString() 
    {
        
    }
    
    //This function update the window contents
    public function update()
    {
       $this->view->setModel($this->model);
       if(trim($this->page)=="" || $this->page==null)
       {
          $this->view->render(); 
          return;
       }
        
         $this->view->render($this->page);
    }    
    
    
}

?>
