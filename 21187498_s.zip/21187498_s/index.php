<?php
date_default_timezone_set('UTC');
//Main application index main file
include_once("config/Paths.php");
include_once("config/constants.php");
/*
 * Include files
 */
include_once("inc/Object.php");
include_once("inc/Controller.php");
include_once("inc/Model.php");
include_once("inc/Validator.php");
include_once("inc/WebApp.php");
include_once("inc/View.php");
include_once("inc/Session.php");;
include_once("inc/IOStream.php");
include_once("inc/Item.php");
include_once("inc/ItemCategory.php");
include_once("inc/TCustomer.php");
include_once("inc/TAdmin.php");
include_once("inc/WebException.php");
include_once("inc/OrderItem.php");
include_once("inc/TAddress.php");

/*
include_once("model/Account.php");
$user=new UserAccount();
$user->assignAdministrator("isrealism2003@yahoo.com");
 * 
 */

/*
 * The main application runs here

*/

Session::init();
$phpversion=  strval(phpversion());
if($phpversion >= "5.3.22" )
{
//Session::delete(CART_BASKET);
$app=new WebApp();//create the main bootstrap (application entry)
$app->exec();//This runt the application
}else
{
    echo"<h1>The php version need to be update please to a 5.3.22 version or higher one</h1>
            <p>To see this application clink <a href='http://obarojohnson.co.uk/1c/'>HERE</a></p>";
}


?>