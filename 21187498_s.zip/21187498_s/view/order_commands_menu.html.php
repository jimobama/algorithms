
<div id='cart_menu'>
    
    <ul>
       
        <li><a class='buttonLink' href='<?php echo URL."?url=cart/xhsMakePaymentOfItems"; ?>'>Make payment to order items</a></li>
    </ul> 
   
</div>
