<?php
if(!is_object($stock)){
    require_once("model/Stock.php");
    $stock=new Stock_Model();
}
//get category information back to the fields
 $categoryNumberEdit=(Session::get(CURRENT_CATEGORY_TO_EDIT)!="")?Session::get(CURRENT_CATEGORY_TO_EDIT):null;
 if($categoryNumberEdit !=null)
 {
     try
     {
     $category= $stock->getCategory($categoryNumberEdit);
     
     Session::set("insert_category_name",$category->getName());
     Session::set("insert_category_keywords",$category->getKeyWords());
     }
     catch(WebException $err)
     {
         
     }
 }
 
    $errorArray= Session::get("ADD_CATEGORY_ITEM");
    $deleteError=Session::get("CATEGORY_DELETE");
   
    if($errorArray !="" )
      {
        //carry operations here
       if(isset($errorArray[1]) && !empty($errorArray[1]))
        {
            $errorMsgFromArray = $errorArray[1];
            
            
        }
        
      }///end if statement
     
     if($deleteError!="")
     {
         if(isset($deleteError[1]) && !empty($deleteError))
         {
             $deleteMessage=$deleteError[1];
         }
     }///end if statement
     
     Session::delete("ADD_CATEGORY_ITEM");
     Session::delete("CATEGORY_DELETE");
     Session::delete(CURRENT_CATEGORY_TO_EDIT);
    
    ?>
    
<div id='category-div'>
    
     
    <fieldset class='line-border'>
       
<div class='form'>
    <table ><caption>Category Item List<p><?php if(isset($deleteMessage)){echo "<div ".ERROR_STYLE.">".$deleteMessage."</div>";}?></p></caption> <tr><thead><th>Title</th><th width='55%'>Keywords</th><th colspan='2' width='10%'>#</th></thead></tr>
    <?php
     $categories= $stock->getCategories();
     $categories->asort();
     foreach($categories as $category)
     {
         $title=$category->getName();
         $keywords=$category->getKeywords();
         $number=$category->getNumber();
         if(strlen($keywords)>40)
         {
           $keywords=Validator::getStringFrom($keywords,0,40)."..."; 
         }
         echo ("<tr><td>$title</td><td>$keywords</td><td colspan='1'><a href='".URL."?url=stock/xhsEditCategory/&cat=$number"."'>
             <img src='public/image/edit.png' width='20' height='20' alt='del'  />
             </a></td><td colspan='1'><a href='".URL."?url=stock/xhsDeleteCategory/&cat=$number"."'>
             <img src='public/image/delete.png' width='20' height='20' alt='del'  /></a></td></tr>");
     }
     ?>
    </table>
</div>
</fieldset  >
 


<div class='form' class='line-border' id='categoryAdd'>
    <fieldset>
        <legend class='line'> Add New</legend>
  
    <?php 
    if(isset( $errorMsgFromArray)){echo  "<div ".ERROR_STYLE.">".$errorMsgFromArray."</div>";} 
    ?>
    
    <form action='<?php echo URL."?url=stock/xhsAddCategory"?>' method='post' onSubmit='return addCategory();'/>
    <span>
        <label>
             New Category Name:
        </label>
        <input class='text' type='text' id='txtcategoryname' name='txtcategoryname' value='<?php echo Session::get("insert_category_name");Session::delete("insert_category_name"); ?>' />
               
    </span>
    <span>
         <label>
           Enter category keyword description and separate with comma e.g Accessories,Cover Bag
        </label>
    </span>
     <span>
       
        <textarea class='textarea'  id='txtacategorykeyords' name='txtacategorykeyords' ><?php echo Session::get("insert_category_keywords"); Session::delete("insert_category_keywords"); ?> 
        </textarea>
               
    </span>
    <span>
         <?php
          if(isset($categoryNumberEdit) && $categoryNumberEdit !=null)
          {
              echo"<input class='text' type='hidden' name='txtUpdateCategoryID' value='$categoryNumberEdit' />";
              echo "<input class='button' type='submit' name='btnUpdateCategory' value='Update Category' />";
          }
        ?>
        <input class='button' type='submit' name='btnAddCategory' value='Add Category' />
         
               
    </span>
    
      </fieldset>
</div>
    
   

 
</div>