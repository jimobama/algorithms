
<?php

 require_once("model/Stock.php");
 $stock=new Stock_Model();
 
?>
<div id='control-panel'>
<fieldset class='line-border'>
    <legend class='line'><input type='checkbox' name='stockcheck'>Stock  Panel</legend>
<ul id='stock_menu_commands'>
    <li><a href='<?php echo URL."?url=member/xhsStockPageSwitch/&amp;page=addcategory"?>'>Add Category</a></li>
    <li><a href='<?php echo URL."?url=member/xhsStockPageSwitch/&amp;page=addItem"?>'>Add Item</a></li>    
    <li><a href='<?php echo URL."?url=member/xhsStockPageSwitch/&amp;page=displayItems"?>'>Display Items</a></li> 
    <li><a href='<?php echo URL."?url=member/xhsStockPageSwitch/&amp;page=user"?>'>Users</a></li> 
    
    
</ul>
    
     
</fieldset>


 <div id='displayMemberPanel'>
        <?php
          if(Session::get("STOCK_REQUEST_PAGE")!=null)
          {
             include_once(Session::get("STOCK_REQUEST_PAGE")) ;
          }
        ?>    
      
        
    </div>

    
    
</div>