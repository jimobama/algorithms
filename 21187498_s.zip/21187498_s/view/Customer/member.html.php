<?php

//check if the user is an administrator 

    if(Session::get(IS_ADMINISTRATOR)==true)
     {
         require_once("ControlPanel.html.php");
     }
   else
   {
     // redirect the user to cart page
       @header("Location:".URL."");
       exit();
   }
    
 
?>