
<?php
$catItemNumber=(Session::get(CURRENT_CATEGORY_TO_EDIT)!="")?Session::get(CURRENT_CATEGORY_TO_EDIT):null;//category number 

$itemImage="public/image/item_default.jpg";

  if(Session::get("UPLOAD_ITEM_IMAGE")!=null)
  {
    if(file_exists(Session::get("UPLOAD_ITEM_IMAGE"))) 
    {
      $itemImage= Session::get("UPLOAD_ITEM_IMAGE"); 
       
    }
        
  }
 Session::delete("UPLOAD_ITEM_IMAGE"); 
  
 //print_r(Session::get("ADD_ITEM_ERROR"));
  if(Session::get("ADD_ITEM_ERROR")!="")  
  {
      $errorM =Session::get("ADD_ITEM_ERROR");
     
      if($errorM[1]!="")
      {
        $object=trim($errorM[0]);
        if($object=="item_image" || $object=="category_number")
        {
          $addErrr="<span ".ERROR_STYLE." >".$errorM[1]."</span>";
        }
       else if($object=="item_name")
       {
          $itemname_error ="<span ".ERROR_STYLE." >".$errorM[1]."</span>";
       }
      else if($object=="add_success")
      {
          $item_success="<span ".STYLE_SUCCESSFUL.">".$errorM[1]."</span>";
      }
      }
  }
  Session::delete("ADD_ITEM_ERROR");
?>
<div id='addItems-div'>
    <?php
      if(isset($item_success))
      {
          echo $item_success;
      }
    
      
      
  //Item amending start here
      
     
    if(!isset($stock) || !is_object($stock))
    {
        require_once("model/Stock.php");
        $stock=new Stock_Model();
    }
     
    $itemNumberEdit= Session::get(CURRENT_ITEM_TO_EDIT);//get item number
    if($stock->isItemNumberExists($itemNumberEdit))
     {
        //carry out operation with item number and get item object from the number
        $item=$stock->find($itemNumberEdit,Item::BYNUMBER);
        if($item==null || !is_object($item))//make sure is an item object
            $item=new Item();
        
        //get the item require values
        $itemImage=ITEM_IMAGES.$item->getPhoto();
        $catItemNumber=$item->getCategoryNumber();
        Session::set("ITEM_NAME",$item->getName());
        Session::set("ITEM_PRICE",$item->getCurrentPrice());
        Session::set("ITEM_STOCKNUMBER",$item->getStockNumber());
        Session::set("ITEM_DESC",$item->getDescription());
     }
      
   //end here
     Session::delete(CURRENT_ITEM_TO_EDIT); 
      
    ?>
    
   <form onSubmit='return addItemValidator();' action='<?php echo URL."?url=stock/xhsAddItem" ?>' method='post' enctype="multipart/form-data">
        <div>
             
            <span>
              <img src='<?php echo $itemImage;?>'  alt='Item Image' width='150'  height='150'/>                
            </span>
            <span><input type='file' name='itemImage' value='Browse Item Image' /></span>
           <div><?php if(isset($addErrr)){echo $addErrr;} ?></div>
            <span><label>Select  Category</label>
                <select class='combo' name='itemCategory' id='itemCategory'>
                    <option value=''>Select here...</option>
                  <?php
                  Session::delete(UPLOAD_ITEM_IMAGE);
                $categories=$stock->getCategories();
                foreach($categories as $category)
                {
                    $catname=$category->getName();
                    $catnumber=$category->getNumber();
                    $defaultSelected="";
                    if($catnumber==$catItemNumber)
                    {
                      $defaultSelected="selected"  ; 
                    }
                    echo "<option value='$catnumber' $defaultSelected >$catname</option>";
                    
                }
             ?>
                </select>
            </span>
            <?php if(isset($itemname_error)){echo $itemname_error;} ?>
            <span>
                
                <label>Item Name:</label>
                <input type='text'  id='txtItemName' class='text' value='<?php if(Session::get("ITEM_NAME")!=""){echo Session::get("ITEM_NAME");Session::delete("ITEM_NAME");} ?>' name='txtItemName' />
                
            </span>
            
            
            <span>
                <label>Item Price(£):</label>
                <input type='text' id='txtItemPrice' class='text' value='<?php if(Session::get("ITEM_PRICE")!=""){echo Session::get("ITEM_PRICE");Session::delete("ITEM_PRICE");} ?>' name='txtItemPrice' />
                
            </span>
            
             <span>
                <label>Number of items :</label>
                <input id='txtItemStockNumber' type='text' class='text' value='<?php if(Session::get("ITEM_STOCKNUMBER")!=""){echo Session::get("ITEM_STOCKNUMBER");Session::delete("ITEM_STOCKNUMBER");} ?>' name='txtItemStockNumber' />
                
            </span>
            
             <span><label>Item Description:</label></span>
             <span>
               
                <textarea  class='textarea' id='txtItemDesc'  name='txtItemDesc' ><?php if(Session::get("ITEM_DESC")!=""){echo Session::get("ITEM_DESC");Session::delete("ITEM_DESC");} ?></textarea>
                
            </span>
            
             <span>
               
                <input type='submit' class='button' value='Add Item' name='btnAddNewItem' />
                <?php
                if(isset($itemNumberEdit) && $stock->isItemNumberExists($itemNumberEdit))
                {
                    echo ("<input type='hidden' class='text' value='$itemNumberEdit' name='txtItemNumberToEdit' />");
                 echo(" <input type='submit' class='button' value='Update Item Details' name='btnUpdateItem' />");
                 
                }
                ?>
                
            </span>
            
            
            
            
            
            
        </div>
       
    </form>
        
    
</div>