<?php
 //print_r(Session::get("ADD_ADDRESS_ERROR"));
 $addressError="";
 if(Session::get("ADD_ADDRESS_ERROR")!="")
 {
     $add_address_errr=Session::get("ADD_ADDRESS_ERROR");
     if($add_address_errr[0]!="") 
     {
         $addressError="<div ".ERROR_STYLE.">".$add_address_errr[1]."</div>";
     }
 }
 Session::delete("ADD_ADDRESS_ERROR");
 
?>

<form id='formshippingaddress' action='<?php echo URL."?url=member/xhsAddShippingAddress"; ?>'  method='post' onSubmit="return  addShippingAddress();">
    <?php echo $addressError;  ?>
                 <span>
                    <label> Receiver's full name:</label>
                    <input class='text'  type="text"  id="txtSFullname" name="txtSFullname" value='<?php if(Session::get("SHIP_FULLNAME")!=""){echo Session::get("SHIP_FULLNAME"); Session::delete("SHIP_FULLNAME");}  ?>'>
                </span>
               
                 <span>
                    <label>Address 1(House number/name)</label>
                    <input class='text'  type="text" name="txtSAddress1" id="txtSAddress1" value='<?php if(Session::get("SHIP_ADDRESS1")!=""){echo Session::get("SHIP_ADDRESS1"); Session::delete("SHIP_ADDRESS1");}  ?>'>
                </span>
                <span>
                    <label>Address 2(Street name)</label>
                    <input class='text' type="text"  id="txtSAddress2" name="txtSAddress2" value='<?php if(Session::get("SHIP_ADDRESS2")!=""){echo Session::get("SHIP_ADDRESS2"); Session::delete("SHIP_ADDRESS2");}  ?>'>
                </span>
                 <span>
                    <label>Postcode/Zip code</label>
                    <input class='text'  type="text" id="txtSPostcode" name="txtSPostcode" value='<?php if(Session::get("SHIP_POSTCODE")!=""){echo Session::get("SHIP_POSTCODE"); Session::delete("SHIP_POSTCODE");}   ?>'>
                </span>
     <span>
                    <label>Country:</label>
                    <input class='text'  type="text" id="txtSCountry" name="txtSCountry" value='<?php if(Session::get("SHIP_COUNTRY")!=""){echo Session::get("SHIP_COUNTRY"); Session::delete("SHIP_COUNTRY");} ?>'>
                </span>
                 <span>
                    <label>State/Region:</label>
                    <input  class='text' type="text" id="txtSState" name="txtSState" value='<?php if(Session::get("SHIP_STATE")!=""){echo Session::get("SHIP_STATE"); Session::delete("SHIP_STATE");}  ?>'>
                </span>
                 <span>
                    <label>Town/County</label>
                    <input  class='text' type="text" id="txtPSTown" name="txtPSTown" value='<?php if(Session::get("SHIP_TOWN")!=""){echo Session::get("SHIP_TOWN"); Session::delete("SHIP_TOWN");}  ?>'>
                </span>
                
                 <span>
                   
                    <input class='button' type="submit" name="btnAddShipAddress" value='Add Address'>
                </span>
            </form>