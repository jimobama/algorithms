<?php
   $oldclient="";
   $newclient="";
   If(Session::get(CLIENT_SWITCH)==true)
   {
       $oldCleint_1="<style>#login_wrapper{display:none;}#new-account-wrapper{display:block;}</style>";
       
        $newclient="checked";
      echo $oldCleint_1;
   }
  else
   {
      $oldclient="checked";
      $newCleint_2=" <style>#new-account-wrapper{display:none;}#login_wrapper{display:block;}</style>";
      echo $newCleint_2;
     
   }
  
   
   
 
 if(Session::get(CLIENT_ERROR)!="")
 {
    $clientError=Session::get(CLIENT_ERROR);
    $client_error_message=isset($clientError[1])?$clientError[1]:null;
    $client_element= isset($clientError[0])?$clientError[0]:null;
    $email_err="";
    $firstname_err="";
    $lastname_err="";
    $phone_err="";
    $password_err="";
    $mismatched_err="";
    $successfully="";
    $style=" style='border:1px solid #FF0000;background-color:#FFFFCC;padding:4px;margin:4px;text-align:center;' ";
    $style1=" style='border:1px solid #0000FF;background-color:#FFFFCC;padding:4px;margin:4px;text-align:center;' ";
   
    if($client_element=="email")
    {
       $email_err ="<div $style >$client_error_message</div>";
    }
    else if($client_element=="firstname")
    {
       $firstname_err="<div $style >$client_error_message</div>"  ;
    }
   else if($client_element=="lastname")
   {
        $lastname_err="<div $style >$client_error_message</div>"  ;
   }
  else if($client_element=="phone")
  {
     $phone_err="<div $style >$client_error_message</div>"  ; 
  }
  else if($client_element=="password")
  {
     $password_err="<div $style >$client_error_message</div>"  ;   
  }
  else if($client_element=="mismatched")
  {
      $mismatched_err ="<div $style >$client_error_message</div>" ;
  }
  else if($client_element=="term")     
  {      
       $successfully ="<div $style >$client_error_message</div>" ;    
  }
 else if($client_element=="create_success"){
       $successfully ="<div $style1 >$client_error_message</div>" ; 
 }
 else if($client_element=="customer_login")
 {
     $login ="<div $style >$client_error_message</div>" ;   
 }    
 
 Session::delete(CLIENT_ERROR);   
   
    
 }
?>
<div class='control'>
<div id='new_customer' >
    <div id='oldClient'>
   
    <div id='createNewAccount'>
        
        <form action="<?php echo URL ?>?url=guest/xhsLogIn" method='post' onSubmit='return userLogin();'   >
            <fieldset class='line-border'>
                <legend class='line'><a href='<?php echo URL ?>?url=guest/xhsSwitch' ><input <?php echo $oldclient; ?>  type='checkbox' class='checkbox'   />Log In</a></legend>
                <div id='login_wrapper'>
                    <span>  <?php if(isset($login)   ){echo $login;} ?></span>
                <span>
                    <label class='label'>Email Address: </label>
                    <input type='text' class='text' name='txtLEmail'  id='txtLEmail'/>
                </span>

                <span>
                    <label  class='label' >Password </label>
                    <input type='password' class='text' name='txtLPassword' id='txtLPassword' />
                </span>

                 <span>
                      <input type='submit' class='button' name='btnLogin' value='Log In' />
                </span>
                </div>
            </fieldset>
        </form>

    </div>
</div>
      <div id='newClient' >

    <div id='createNewAccount' >
        <form action='<?php echo URL ?>?url=guest/xhsCreateAccount' method='post' onSubmit='return createAccount();'>
            <fieldset class='line-border' >
                <legend class='line'><a href='<?php echo URL ?>?url=guest/xhsSwitch'><input <?php echo $newclient; ?> type='checkbox' class='checkbox'   />New Account</a></legend>
                <div id='new-account-wrapper'>
                    <?php if(isset($successfully)){echo $successfully;} ?>
                <span>
                    <?php if(isset($email_err)){echo $email_err;} ?>
                    <label class='label'>Email Address: </label>
                    <input type='text' class='text' id='txtCEmail' name='txtCEmail' value='<?php echo  Session::get(V_EMAIL);Session::delete(V_EMAIL); ?>' />
                </span>

                <span><?php if(isset($firstname_err)){echo  $firstname_err;} ?>
                    <label  class='label' >First Name: </label>
                    <input type='text' class='text' value='<?php echo Session::get("v_firstname"); Session::delete("v_firstname");?>' name='txtCFirstName' id='txtCFirstName' />
                </span>

                <span><?php if(isset($lastname_err)){echo   $lastname_err;} ?>
                    <label class='label' >Last Name: </label>
                    <input type='text'  value='<?php echo Session::get("v_lastname");Session::delete("v_lastname"); ?>' class='text' name='txtCLastName' id='txtCLastName' />
                </span>

                <span><?php if(isset($phone_err)){echo   $phone_err;} ?>
                    <label class='label' >Mobile Phone </label>
                    <input type='text' class='text' value ='<?php echo Session::get("v_phone"); Session::delete("v_phone"); ?>' name='txtCMobilePhone' id='txtCMobilePhone' />
                </span>
                
                <span><?php if(isset($password_err)){echo   $password_err;} ?>
                    <label class='label' >Password </label>
                    <input type='password' class='text' name='txtCPassword' id='txtCPassword' />
                </span>

                <span><?php if(isset($mismatched_err)){echo   $mismatched_err;} ?>
                    <label class='label' >Re-Type Password</label>
                    <input type='password' class='text' name='txtCRPassword' id='txtCRPassword'/>
                </span>
                <span>
                    <label class='label' ><input  id='terms' type='checkbox' value='agree' name='terms' <?php if(Session::get("v_term")!=""){echo "checked";Session::delete("v_term"); }?> />I have read the <a href='#'>Terms & Conditions</a> and agree to it</label>
                </span>
                <span>
                   <input type='submit' class='button' name='btnCreateAccount' value='Create Account' />
                </span>
                </div>
            </fieldset>
        </form>

    </div>
    
      </div>

</div>
    
</div>