
<?php
 if(Session::get(LOGIN))
 {
     require_once("member.html.php");
 }
else
{
 
  require_once("guest.html.php");  
}
?>