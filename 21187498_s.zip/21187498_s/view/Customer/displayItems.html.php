<?php
$displayarray = (Session::get("CAT_DISPLAY_ERROR") != "") ? Session::get("CAT_DISPLAY_ERROR") : null;

if ($displayarray != null) {
    if (isset($displayarray[0]))
        $displayError = "<span  " . ERROR_STYLE . ">" . $displayarray[1] . "</span>";
}

Session::delete("CAT_DISPLAY_ERROR");

?>

<div id='displayItem'>
<?php if (isset($displayError) && !empty($displayError)) {
    echo $displayError;
} ?>
    <form action='<?php echo URL . "?url=stock/xhsDisplayItems" ?>' method='post' onSubmit='return displayItemValidator();'>
        <span><label>Select  Category</label>
            <select class='combo' name='itemCategoryListDisplay' id='itemCategoryListDisplay'>
                <option value=''>All category...</option>
<?php
$categories = $stock->getCategories();
foreach ($categories as $category) {
    $name = $category->getName();
    $number = $category->getNumber();
    echo "<option value='$number'>$name</option>";
}
?>
            </select>
        </span>
        <span><input type='submit' class='button' value='Display' name='btnDisplayItems' /></span>
    </form>

    <div id='itemDisplayed'>
        <?php
        if(Session::get("DELETE_REPORT")!="")
        {
            $errorArray3=Session::get("DELETE_REPORT");
            $errMessage=$errorArray3[1];
            
            echo "<span ".ERROR_STYLE." >".$errMessage."</span>";
        }
        Session::delete("DELETE_REPORT");
        
        ?>
        <table><tr><th width='13%'>Item Thumb</th> <th>Item Name</th><th width='10%'>N<u>o</u>. of Stock</th><th width='10%'>Item Left</th><th width='10%'>Price(£)</th><th colspan='2'>#</th></tr>
        
        <?php
          $cateNumber=(Session::get(CURRENT_CATEGORY_TO_DISPLAY)!="")?Session::get(CURRENT_CATEGORY_TO_DISPLAY):null;
          $items= $stock->find($cateNumber,  ItemCategory::CATEGORY);
          if($items==null)
              $items=new ArrayIterator(Array());
          
           while($items->valid())
           {
               $item=$items->current();
               if($item==null){
                   $item=new Item();
                   continue;
               }
               $photo=ITEM_IMAGES.$item->getPhoto();
               $name=$item->getName();
               $price= number_format($item->getCurrentPrice(),2);
               $nStock=$item->getStockNumber();
               $stockLeft=$item->getStockLeft();
               $itemID= $item->getNumber();
               $editLink=URL."?url=stock/xhsEditItem/&itemNumber=$itemID";
               $deleteLink=URL."?url=stock/xhsDeleteItem/&itemNumber=$itemID";
               echo ("<tr>
                   <td><img src='$photo' width='40' height='40'  alt='Item image'/></td>
                   <td>$name</td>
                   <td>$nStock</td>
                   <td> $stockLeft</td>
                   <td>£$price</td>
                   <td><a href='$editLink' class= 'buttonLink' >Edit</a></td>
                   <td><a class='buttonLink' href='$deleteLink'>Del</a></td>

                 </tr>");
               
               
               $items->next();
           }
        ?>
        
        
        </table>
    

    </div>

</div>