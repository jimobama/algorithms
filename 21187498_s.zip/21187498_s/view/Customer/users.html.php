<?php

if(is_object($this->model))
{
  
    echo"<h1>All User Account</h1>";
    //get all the customer in the file
    $customers=$this->model->getCustomers();
    
    if($customers==null)
        $customers=new ArrayIterator(Array());
    echo "<div id='users'><table><tr><th>User Name</th> <th>Email Address</th><th width='10%' colspan='1'></th></tr>";
    while($customers->valid())
    {
        $customer=$customers->current();
        if($customer==null)
        {
            $customer=new TCustomer();
            continue;
        }
        $name= ucwords(strtolower($customer->getFirstName()." ".$customer->getLastName()));
        $email=ucwords($customer->getEmail());
        $id=$customer->getClientID();
            $assign="<a href='".URL."?url=member/xhsAssignAdministrator/&amp;id=$id' class='buttonLink'>Assign Administrator</a>";
        if($this->model->isAdministrator($email))
        {
          $assign="<a href='".URL."?url=member/xhsRemoveAdministrator/&amp;id=$id' class='buttonLink'>Remove Administrator</a>";  
        }
        
        echo("<tr>
            
              <td>$name</td>
               <td>$email</td>
                <td>$assign</td>                                

            </tr>");
        $customers->next();
    }
   echo "</table></div>"; 
    
    
    
}
?>
