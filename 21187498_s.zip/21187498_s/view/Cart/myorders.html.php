<?php
//only login member can see this area
if(Session::get(LOGIN)!=true)
{
    header("Location:".URL."?url=guest");
    exit();
}
if (!isset($account) || !is_object($account)) {
    include_once("model/Account.php");
    $account = new UserAccount();
}

$customer = $account->getCustomer(Session::get(LOGIN_EMAIL));
if ($customer == null)
    $customer = new TCustomer();


if(Session::get(CURRENT_ORDER_NUMBER)!="")
{
    $orderNumber=Session::get(CURRENT_ORDER_NUMBER);
  echo "<h2 ".STYLE_SUCCESSFUL." >Your order has be place with the order number $orderNumber </h2>";  
}
Session::delete(CURRENT_ORDER_NUMBER);
//display all the user orders items
    
    $orders = $account->getCustomerOrders($customer->getClientID());
    $nOrder=$orders->count();
    //start the loop
    echo "<h2> TOTAL ORDERS(<label style='color:red;margin:2px;'>$nOrder<label>) MADE</h2>";
    echo "<div id='myorders'><table>";
    echo"<tr><th></th><th>Order Number</th><th>Item Name</th><th>N<u>o</u> Of Items</th><th>Price(£)</th><th>Total Price</th><th>Date Ordered</th><th>Order Status</th><th></th></tr>";
    foreach($orders as $order)
    {      
     
      if($order==null){
          $order=new TOrderItem ();
          continue;
      }
      if(!isset($this->model) || !is_object($this->model))
      {
          require_once("model/Stock.php");
          $this->model=new Stock_Model();
      }
      $item =$this->model->find($order->getItemNumber(),Item::BYNUMBER);
      if($item==null)
          $item=new Item();
        
     $itemName=$item->getName();
     $photo=ITEM_IMAGES.$item->getPhoto();
     $numberOfItemsOrders=$order->getNumberOfItems();
     $ItemOrderNumber=$order->getOrderNumber();
     $price=number_format($order->getPrice(),2);
     $totalPrice=number_format($order->getTotalPrice(),2);
     $date=Date("jS M,Y",$order->getDate());
     $status="Pending...";
      $cancel="<a href='".URL."?url=cart/xhsCancelOrder/&amp;orderID=$ItemOrderNumber' class='buttonLink' >Cancel</a>";
     if($order->getStatus()==true)
     {
         $status="Shipped";
         $cancel="<a class='buttonLink' href='#'>return</a>";
     }
     echo("<tr>
         <td><input type='checkbox' name='checkID'/></td>        
         <td> $ItemOrderNumber</td>
         <td> $itemName</td>
         <td>$numberOfItemsOrders</td>
         <td>£$price</td>
         <td>£$totalPrice</td>
         <td>$date</td>
         <td>$status</td>
          <td>$cancel</td>
         
         </tr> ");
        
        
    }//end the loop orders
    echo "</table></div>"; 
    





?>
