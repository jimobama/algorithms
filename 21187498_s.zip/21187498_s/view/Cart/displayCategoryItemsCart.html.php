<?php

//print_r($SwitchPanel);
include("view/cart_menu.html");
$items = new ArrayIterator(Array());
if (is_object($this->model)) {


    if (isset($SwitchPanel) && !empty($SwitchPanel)) {
        $cartNumber = $SwitchPanel[1];
        //check if the category number exist
        if ($this->model->isCategoryIDExists($cartNumber) >= 0) {
            $category = $this->model->getCategory($cartNumber);
            //$catname = strtolower($category->getName());
            $items = $this->model->getItemsInCategory($cartNumber);
            //$itemCounts = $items->count();
        }//end the category number is valid
        else {
            //search for items
            $criteria = $SwitchPanel[1];

            $items = $this->model->find($criteria, ItemCategory::KEYWORDS);
            if ($items->count() <= 0) {
                $items = $this->model->find($criteria, Item::BYNAME);
                if (!is_object($items))
                    $items = new ArrayIterator(Array());
                if ($items->count() <= 0) {

                    $item = $this->model->find($criteria, Item::BYNUMBER);
                    $items->append($item);
                }
            }
        }

        //***********************
        if (!isset($items) || !is_object($items))
            $items = new ArrayIterator(Array());
        $nItems = 0;
        if ($items->count() > 0)
            ; {
            $nItems = (int) $items->count();
        }
        echo "<h2>Products Catalogue Show Board</h2>";


        echo "<div id='category-items-displays'><ul>";
        foreach ($items as $item) {
            if ($item == null) {
                continue;
            }
            $itemName = $item->getName();

            $price = number_format($item->getCurrentPrice(), 2);

            $stock_left = $item->getStockLeft();
            $photo = ITEM_IMAGES . $item->getPhoto();
            $item_number = $item->getNumber();
            $header_link = URL . "?url=cart/xhsAddToBasket/";

            echo "<li><a href='" . URL . "?url=cart/xhsShowItemProfile/&itemID=$item_number'><div><form action='$header_link' method='post'>";
            echo " <span><label class='item-name'> $itemName </label><input type='hidden' name='txtItemNumber' value='$item_number' /></span>";
            echo "<img src='$photo' alt='Item Image' width='94' height='98'  />";
            echo"<div class='item_details'>";
            echo("

                    <span><label class='item-price'> £$price </label></span>
                    <span><label class='item-stock-left'>Items in stock ($stock_left)</label></span> 
                     <span><input  class='text' type='text' name='txtNoOfItems' value='1' /></span>  
                    <span><input type='submit' class='buttonLink' value='Add to trolley'/></span>

               ");

            echo"</form></div>";
            echo "</div></a></li>";
        }

        echo "</div></ul>";

        //*********************
    }
}

include("view/cart_menu.html");
?>
