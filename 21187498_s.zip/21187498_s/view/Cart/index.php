<?php

//check if the CART_SWITCH_PANEL session exist

echo "<div id='displayCart-div'>";
if(Session::get("CART_SWITCH_PANEL")!="")
{
    $SwitchPanel=Session::get("CART_SWITCH_PANEL");
    //check if there is file to display with the number
    if(isset($SwitchPanel[1]))
    {
         $page=$SwitchPanel[0];         
         include_once($page);     
        
    }
   
   
}

echo "</div>";



?>

