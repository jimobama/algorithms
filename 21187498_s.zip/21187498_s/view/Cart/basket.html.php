<?php

include("view/cart_menu.html");
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$basket = (Session::get(CART_BASKET)) ? Session::get(CART_BASKET) : null;
if ($basket == null)
    $basket = new ArrayIterator(Array());
//display  all items 
$totalAmountOfItemsInBasket = 0.0;

//check if the Basket operation feedback is set
if (Session::get("BASKET_OPERATIONS_FEEDBACK") != "") {
    $Feedback = Session::get("BASKET_OPERATIONS_FEEDBACK");

    $errorMessage = isset($Feedback[1]) ? $Feedback[1] : null;
    echo "<div " . ERROR_STYLE . " >" . ucfirst(trim($errorMessage)) . "</div>";
}

//unset
Session::delete("BASKET_OPERATIONS_FEEDBACK");


if ($basket->count() <= 0) {
    echo"<h2>Your trolley is empty</h2>";
} else {
    echo"<div id='basket'><table width='100%'><tr><thead><th width='15%'>Item Thumb</th><th>Item Name</th><th  width='10%'>Price(£)</th><th width='10%'>N<u>o</u> Of Items</th><th  width='10%'>Total</th><th colspan='2' width='10%'>#</th></thead></tr>";
    foreach ($basket as $strOrderItem) {
        $orderItemBasket = unserialize($strOrderItem);
        $price = number_format($orderItemBasket->getPrice(), 2);
        $total = number_format($orderItemBasket->getTotalPrice(), 2);
        $nItems = $orderItemBasket->getNumberOfItems();
        $number = $orderItemBasket->getItemNumber();
        $item = $this->model->find($number, Item::BYNUMBER);
        if($item==null || !is_object($item))
        {
            $item=new Item();
            Session::delete(CART_BASKET);
            continue;
        }
        $photo = ITEM_IMAGES . $item->getPhoto();
        $itemName = $item->getName();
        $totalAmountOfItemsInBasket +=(double) $orderItemBasket->getTotalPrice();
        echo"<tr><form action='" . URL . "?url=cart/xhsAmendBasketItem' method='post'><td><input type='hidden' value='$number' name='txtItemNumber'/>
            <a href='" . URL . "?url=cart/xhsShowItemProfile/&itemID=$number'><img src='$photo' width='50' height='50' alt='Item Image'  /></a></td>";
        echo("<td><a href='" . URL . "?url=cart/xhsShowItemProfile/&itemID=$number'>$itemName</a></td><td>£$price</td><td><input type='text' class='text' value='$nItems'  name='txtNItems' /></td><td>£$total</td><td>
        <input type='submit' width='20'  value ='update' height='20' name='btnUpdateItemInBasket' >
            
</td><td>
  <input type='submit'  value='del' width='20' height='20'  name='btnDeleteItemFromBasket'>       

</td>");
        echo"</form></tr>";
    }


    echo"<tr><thead><th colspan='2'></th><td colspan='5'>Total Amount: £$totalAmountOfItemsInBasket</th></thead></tr>";



    echo"</table><a href='".URL."?url=cart/xhsDeleteAllItemsFromBasket' class='buttonLink'>Remove All Basket Items</a></div>";
}
?>
