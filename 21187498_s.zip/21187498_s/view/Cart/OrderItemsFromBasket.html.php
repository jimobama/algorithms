<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderItemsFromBasket
 *
 * @author jimobama
 */

         


include("basket.html.php");
//include("shippingAddress.html.php");
?>

<div id="orderItemsStepOne">
    <fieldset  class='line-border'>
        <legend class='line'> Your Shipping Addresses         
        </legend>
        <div id='addressBoard'>
            <?php
            if (Session::get(LOGIN) == true) {
                if (!isset($account) || !is_object($account)) {
                    require_once("model/Account.php");
                    $account = new UserAccount();
                }
                $addresses = $account->getAddresses(Session::get(LOGIN_EMAIL));
                //create a list of the shiping address
                //active Selected address
                 $active_address_id=(Session::get(ACTIVE_SHIPPING_ADDRESS)!="")?Session::get(ACTIVE_SHIPPING_ADDRESS):null;
                echo "<ul id='addressDispay-ul'>";
                while ($addresses->valid()) {
                    $address = $addresses->current();
                    $adressNumber=$address->getAddressID();
                    $style="";
                  
                    if(trim($active_address_id)==trim($adressNumber))
                    { 
                       
                         $style="style ='background-color:rgba(187,187,187,0.2);box-shadow:0px 0px 3px #000;' ";
                    }
                    echo"<li $style id='$adressNumber' ><div id='addressDispay-div'>";

                    echo"<span><strong>" . $address->getFullName() . "</strong></span>";
                    echo"<span>" . $address->getAddress1() . ",</span>";
                    echo"<span>" . $address->getAddress2() . ",</span>";
                    echo"<span>" . $address->getCounty() . ",</span>";
                    echo"<span>" . $address->getState() . ",</span>";
                    echo"<span>" . $address->getCountry() . ".</span>";
                    echo"<span><strong>" . strtoupper($address->getPostcode()) . "</strong></span>";
                    echo ("<span class='address-ui-operations'>
                        <a class='buttonLink' href='".URL."?url=member/xhsSelectAddressForOrder/&add=$adressNumber'><img width='30' height='30' src='public/image/select.jpg' alt='Del' /></a>
                        <a class='buttonLink' href='".URL."?url=member/xhsDeleteAddressForOrder/&add=$adressNumber'><img width='30' height='30' src='public/image/delete.png' alt='Del' /></a>
                        
                    </span>");
                    echo"</div></li>";
                    $addresses->next();
                }

                echo "</ul>";
            } else {
                echo "<h3 " . ERROR_STYLE . ">You are required to login to see your shipping addresses, if have already!</h3>";
            }
            
            
            
           
            ?>



        </div>

    </fieldset>
   
    <fieldset class='line-border'>
        <legend class='line'>Add Shipping Address</legend> 
        <!-- The form objects start here-->
        <div id='OrderShippingAddressMainDiv'>
            <?php require("view/Customer/addShippingAddress.html.php"); ?>           
        </div>
    </fieldset>
</div>
