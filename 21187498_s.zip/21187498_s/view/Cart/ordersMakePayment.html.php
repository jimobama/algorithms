<?php
$errorArrayPayment = (Session::get("ORDER_BY_PAYMENT") != "") ? Session::get("ORDER_BY_PAYMENT") : null;
if ($errorArrayPayment != null) {
    $message = isset($errorArrayPayment[1]) ? $errorArrayPayment[1] : null;
    if ($message != null) {
        $message = ucfirst(trim($message));
        echo "<div " . ERROR_STYLE . " >$message </div>";
    }
}//display the payment error message
Session::delete("ORDER_BY_PAYMENT");

$basket = (Session::get(CART_BASKET) != "") ? Session::get(CART_BASKET) : null;
if ($basket == null)
    $basket = new ArrayIterator(Array());

$cou=0;
$totalPrice = 0.0;

$html = "<div id='orderItemTable-div'><table><tr><th>Item Image</th><th>Item Name</th><th>Amount(£)</th><th>No Of Items</th><th>Total</th></tr>";
foreach ($basket as $strOrderItem) {

    $itemOrder = unserialize($strOrderItem);
    $totalPrice +=(double) $itemOrder->getTotalPrice();
    $item = $this->model->find($itemOrder->getItemNumber(), ITEM::BYNUMBER);
    $photo = ITEM_IMAGES . $item->getPhoto();
    $itemname = $item->getName();
    $itemOrderPrice = number_format($itemOrder->getPrice(), 2);
    $item_desc = $item->getDescription();
    $total = number_format($itemOrder->getTotalPrice(), 2);
    $numberItems = $itemOrder->getNumberOfItems();
   
    $html.=("<tr>
            <td width='15%'> 
            <img src='$photo' width='80' height='53' />
            </td>
            <td>
           $itemname
            </td>
            <td>£$itemOrderPrice</td>
            <td>$numberItems</td>
            <td>£$total</td>
            
          </tr>
           <tr><td colspan='5'>
           <h3>Item Description</h3>
           <span>$item_desc</span>
           </td></tr> 
            ");
 

}//end while


$html.= "</table></div>";
?>

<div id='finalOrder-div'>



    <div id='divMakePayment'>


        <fieldset class='line-border'>
            <legend class='line'>Credit/Debit Card Details</legend>
            <div class='form'>
                <form action='<?php echo URL . "?url=cart/xhsMakePaymentForItems" ?>' method='post' onSubmit='return  makePayment();'>
                    <div>
                    <span><label>Name On Card:</label>
                        <input value='<?php echo Session::get("CARD_NAME");Session::delete("CARD_NAME") ?>' class='text' type='text' name='txtNameOnCard' id='txtNameOnCard'/></span>
                    <span><label>Card Number:</label>
                        <input value='<?php echo Session::get("CARD_NUMBER");Session::delete("CARD_NUMBER") ?>' class='text' type='text'  id='txtCardNumber'  name='txtCardNumber' /></span>   
                    <span><label>Expire date:</label>                 
                        <input class='text' value='<?php echo Session::get("CARD_EXPIRING_DATE");Session::delete("CARD_EXPIRING_DATE") ?>'  type='text' id='txtExpiredate'  name='txtExpiredate'  placeholder='[mm/yyyy]' /></span>                
                    <span><label>Security Number:</label><input value='<?php echo Session::get("CARD_SECURITY_NUMBER");Session::delete("CARD_SECURITY_NUMBER") ?>'  id='txtSecurityNumber' class='text' type='text' name='txtSecurityNumber' /></span>
                    <span><label>Total Amount:</label><input readonly value='£<?php if (isset($totalPrice)) echo number_format($totalPrice, 2); ?>' class='text' type='text' id='txtTotalAmount' name='txtTotalAmount' /></span>

                    <span><label></label><input  value='Order Items(when you make payment)' class='button' type='submit' id='btnOrderItems' name='btnOrderItems' /></span>
                    </div>
                </form>
            </div>
        </fieldset>


    </div>


    <div id='selected-address'>
<?php
$address_ID = (Session::get("ORDER_ADDRESS_ID") != "") ? Session::get("ORDER_ADDRESS_ID") : null;
if ($address_ID != null)
    ; {
    require_once("model/Account.php");
    $account = new UserAccount();
    if ($account->isAddressExists($address_ID)) {
        $address = $account->getAddress($address_ID);
        // print_r($address);
        echo "<h3>Order will be ship to the below address</h3>";
        echo "<span><strong>" . $address->getFullName() . "</strong></span>";
        echo "<span>" . $address->getAddress1() . "</span>";
        echo "<span>" . $address->getAddress2() . "</span>";
        echo "<span>" . $address->getCounty() . "</span>";
        echo "<span>" . $address->getState() . "</span>";
        echo "<span>" . $address->getCountry() . "</span>";
        echo "<span><strong>" . $address->getPostcode() . "</strong></span>";
        echo"<span><a href='".URL."?url=cart/xhsChangeShippingAddress/' class='buttonLink' >Change Shipping Address</a></stron>";
    }
}
?>



    </div>



</div>

<?php if (isset($html)) {
    echo $html;
} ?>