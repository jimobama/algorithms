<?php

include("view/cart_menu.html");
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


if (isset($SwitchPanel) || !empty($SwitchPanel)) {

    echo "<div id='itemDivProfile' >";
    echo "<h2>ITEM PROFILE SUMMARY / DESCRIPTION</h2>";
    //let get the item from the array the second position of $SwitchPanel

    $itemNumber = $SwitchPanel[1];
    $item = $this->model->find($itemNumber, Item::BYNUMBER);
    if ($item == null)
        $item = new Item();

    $itemName = $item->getName();
    $stock_left = $item->getStockLeft();
    $item_number = $item->getNumber();
    $price = number_format($item->getCurrentPrice(), 2);
    $photo = ITEM_IMAGES . $item->getPhoto();
    $desc = $item->getDescription();
    $header_link = URL . "?url=cart/xhsAddToBasket/";

    echo "<div id='ItemDesc'><form action='$header_link' method='post' > <img src='$photo' style='width:320px;height:300px;'/>";

    echo "<div id='inforDesc'>  

                    <span><label class='item-name'> $itemName </label><input type='hidden' name='txtItemNumber' value='$item_number' /></span>
                    <span><label class='item-price'> £$price </label></span>
                    <span><label class='item-stock-left'>N<u>o</u> in stock($stock_left)</label></span> 
                     <span><input  class='text' type='text' name='txtNoOfItems' value='1' /></span>  
                    <span><input type='submit' class='buttonLink' value='Add to trolley'/></span>


      </div>";
    echo "</div>";
    echo "<div id='descDiv'>  $desc </div>";

    echo "</form></div>";
}//end if

include("view/cart_menu.html");
?>

