<?php

define("URL","http://localhost/21187498_s/");
define("DATA_PATH","data/");
define("ITEM_IMAGES","public/ItemImages/");
?>
