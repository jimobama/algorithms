<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
define("VAT",20);
define("LOGIN", "app_login");
//Server processed values constants fields
define("S_SALARY", "s_salary");
define("S_EMAIL", "s_email");
define("S_OVERDRAFT", "s_overdraft");
define("LAST_ERROR", "last_error");
define("BALANCE", "balance");
define("ADD_TRANSACTIONS_OPEN", "add_transaction_open");
define("SWITCH_TOGGLE", "switch_toggle");
define("SWITCH_ERROR", "switch_error");
define("BASKET_COOKIES","cookiesBasket");

//transactions

define("TITLE", "title");
define("PRICE", "price");
define("DESC", "desc");
define("CASHFLOW", "cashflow");
define("CATEGORY", "category");
define("RADIO_IN", "radio_in");
define("RADIO_OUT", "radio_out");
define("TRANSACTION_LIST_OBJECT", "transaction_list");
define("TABLE_TRANSACTIONS", "table_transaction");
define("CLIENT_SWITCH", "client_switch");
define("CLIENT_ERROR", "error_client");
define("V_EMAIL", "v_email");
define("LOGIN_EMAIL", "login_email");
define("ACTIVE_SHIPPING_ADDRESS","active_shipping_address_number");
define("CURRENT_CATEGORY_TO_EDIT","category_number_to_edit");
define("CURRENT_ITEM_TO_EDIT","item_number_to_edit");
define("CURRENT_CATEGORY_TO_DISPLAY","category_number_items_to_display");
define("UNIVERSAL_REQUEST_ERROR","universal_error");
define("IS_ADMINISTRATOR","isAdministrator");
//PAGE CONSTANTS FLAGS
define("OPEN_TRANSACTIONS_DIV", "open_div_flag");
define("BALANCE_LEFT", "bal_left");

define("CART_BASKET", "basket_cart");
define("PREVIOUS_REQUEST_URL", "previous_request_url");
define("CURRENT_ORDER_NUMBER","current_order_number");
//this function copy upload files to destinations
define("ERROR_STYLE", " style='border:1px solid #FF0000;background-color:#FFFFCC;padding:4px;margin:4px;text-align:center;' ");
define("STYLE_SUCCESSFUL"," style='border:1px solid #85A3E0;background-color:#EBEBFF;padding:4px;margin:4px;text-align:center;' ");

function uploadImages($file_name, $temLocation, $destination) {
    $basename = $file_name;

    if (move_uploaded_file($temLocation, $destination . $basename)) {
        return true;
    } else {
        return false;
    }
}




//end upload function
?>
